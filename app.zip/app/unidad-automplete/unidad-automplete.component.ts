import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators ,FormControl ,FormArray , AbstractControl } from '@angular/forms';
import { UnidadService } from '../service/unidad/unidad.service';

@Component({
  selector: 'app-unidad-automplete',
  templateUrl: './unidad-automplete.component.html',
  styleUrls: ['./unidad-automplete.component.css']
})
export class UnidadAutompleteComponent implements OnInit {
  selectedUnidad: any;
  unidad: any[];
  @Output() emitEvent:EventEmitter<any> = new EventEmitter<any>();
  form : FormGroup;

  constructor(private unidadService: UnidadService,
              private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.getUnidad();
    this.form = this.formBuilder.group({
        UnidadNegocio: [null,  Validators.required]
    });
  }

  /*Metodo consumidor para traer Unidades o Kit de negocio*/
  getUnidad(): void {
    this.unidadService.getUnidades()
        .subscribe(unidad => {
          //console.log("Unidad de negocio");
          //console.log(unidad);
          this.unidad = unidad
        });
  }

  getUnidadSelected(): void{
    this.emitEvent.emit(this.selectedUnidad);
  }

}

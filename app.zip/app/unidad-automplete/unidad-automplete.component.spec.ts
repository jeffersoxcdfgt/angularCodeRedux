import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UnidadAutompleteComponent } from './unidad-automplete.component';

describe('UnidadAutompleteComponent', () => {
  let component: UnidadAutompleteComponent;
  let fixture: ComponentFixture<UnidadAutompleteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UnidadAutompleteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UnidadAutompleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

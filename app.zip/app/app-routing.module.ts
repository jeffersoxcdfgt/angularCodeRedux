import { NgModule } from '@angular/core';
import { RouterModule, Routes, PreloadAllModules } from '@angular/router';

import { LoginComponent } from './login/login.component';
import { LoginRecoveryComponent } from './login-recovery/login-recovery.component';
import { AssignNewPasswordComponent } from './assign-new-password/assign-new-password.component';
import { MenuCrudComponent } from './pages/menu-crud/menu-crud.component';
import { UsuariosCrudComponent } from './pages/usuarios-crud/usuarios-crud.component';
import { ClientesCrudComponent } from './pages/clientes-crud/clientes-crud.component';
import { PerfilesCrudComponent } from './pages/perfiles-crud/perfiles-crud.component';
import { RolesCrudComponent } from './pages/roles-crud/roles-crud.component';
import { PermisosCrudComponent } from './pages/permisos-crud/permisos-crud.component';
import { HomeComponent } from './pages/home/home.component';
import { PortafolioEspecificoComponent } from './pages/portafolio-especifico/portafolio-especifico.component';
import { DetallePortafolioEspecificoComponent } from './pages/detalle-portafolio-especifico/detalle-portafolio-especifico.component';

import { MenuListComponent } from './pages/menu-list/menu-list.component';
import { MenuDisplayComponent } from './pages/menu-display/menu-display.component';
import { TipoUsuarioComponent } from './pages/tipo-usuario/tipo-usuario.component';
import { PortafolioGeneralComponent } from './pages/portafolio-general/portafolio-general.component';
import { SideBarComponent } from './side-bar/side-bar.component';
import { ResumenCotizacionComponent } from './pages/resumen-cotizacion/resumen-cotizacion.component';
import { RolAutocompleteComponent } from './rol-autocomplete/rol-autocomplete.component';
import { MultiselectComponent } from './multiselect/multiselect.component';
import { SideBar2Component } from './side-bar2/side-bar2.component';
import { ReadMoreComponent } from './read-more/read-more.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { CanDeactivateGuardService } from './service/can-deactivate-guard/can-deactivate-guard.service';
import { AuthGuardService } from './service/auth-guard/auth-guard.service';
import { SelectivePreloadingStrategyService } from './service/selective-preloading-strategy/selective-preloading-strategy.service';
import { ListaCotizacionesComponent } from './pages/lista-cotizaciones/lista-cotizaciones.component';
import { ParametrizacionFechasComponent } from './pages/parametrizacion-fechas/parametrizacion-fechas.component';
import { ControlesCrudComponent } from './pages/controles-crud/controles-crud.component';
import { FichaTecnicaComponent } from './pages/ficha-tecnica/ficha-tecnica.component';
import { ListActividadesComponent } from './pages/list-actividades/list-actividades.component';
import { PagesComponent } from './pages/pages.component';

const routes: Routes = [
  {
    path:'', component: PagesComponent, 
    children: [
      { path: 'Home-inicio', component: HomeComponent, canActivate: [AuthGuardService] },
      { path: 'Portafolio-general', component: PortafolioGeneralComponent, canActivate: [AuthGuardService] },
      { path: 'Portafolio-general/:id', component: PortafolioGeneralComponent, canActivate: [AuthGuardService] },
      { path: 'Resumen-cotizacion', component: ResumenCotizacionComponent, canActivate: [AuthGuardService] },
      { path: 'Resumen-cotizacion/:id/edit', component: ResumenCotizacionComponent, canActivate: [AuthGuardService] },
      { path: 'Menu-crud', component: MenuCrudComponent, canActivate: [AuthGuardService] },
      { path: 'Usuarios-crud', component: UsuariosCrudComponent, canActivate: [AuthGuardService] },
      { path: 'Clientes-crud', component: ClientesCrudComponent, canActivate: [AuthGuardService] },
      { path: 'Perfiles-crud', component: PerfilesCrudComponent, canActivate: [AuthGuardService] },
      { path: 'Roles-crud', component: RolesCrudComponent, canActivate: [AuthGuardService] },
      { path: 'Permisos-crud', component: PermisosCrudComponent, canActivate: [AuthGuardService] },
      { path: 'Portafolio-especifico', component: PortafolioEspecificoComponent, canActivate: [AuthGuardService] },
      { path: 'Detalle-Portafolio-especifico/:id', component: DetallePortafolioEspecificoComponent, canActivate: [AuthGuardService] },
      { path: 'Menu-list', component: MenuListComponent, canActivate: [AuthGuardService] },
      { path: 'Menu-display', component: MenuDisplayComponent, canActivate: [AuthGuardService] },
      { path: 'Tipo-usuario', component: TipoUsuarioComponent, canActivate: [AuthGuardService] },
      { path: 'Lista-cotizaciones', component: ListaCotizacionesComponent, canActivate: [AuthGuardService] },
      { path: 'Parametrizacion-fechas', component: ParametrizacionFechasComponent, canActivate: [AuthGuardService] },
      { path: 'Controles-crud', component: ControlesCrudComponent, canActivate: [AuthGuardService] },
      { path: 'ficha-tecnica', component: FichaTecnicaComponent, canActivate: [AuthGuardService] },
      { path: 'List-actividades', component: ListActividadesComponent, canActivate: [AuthGuardService] },
      { path: 'ficha-tecnica/:ot', component: FichaTecnicaComponent, canActivate: [AuthGuardService] },
      { path: 'Parametrizacion-fechas/:ot', component: ParametrizacionFechasComponent, canActivate: [AuthGuardService] }
    ]
  },
  { path: 'login',component: LoginComponent },
  { path: 'login-recovery', component: LoginRecoveryComponent },
  { path: 'assign-new-password', component: AssignNewPasswordComponent },  
  { path: 'Side-bar', component: SideBarComponent, canActivate: [AuthGuardService] },
  { path: 'Rol-autocomplete', component: RolAutocompleteComponent, canActivate: [AuthGuardService] },
  { path: 'Multi-select', component: MultiselectComponent, canActivate: [AuthGuardService] },
  { path: 'Side-bar2', component: SideBar2Component, canActivate: [AuthGuardService] },
  { path: 'Read-more', component: ReadMoreComponent, canActivate: [AuthGuardService] },  
  { path: '**', component: NotFoundComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
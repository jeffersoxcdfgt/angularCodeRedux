import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TipocomprasAutocompleteComponent } from './tipocompras-autocomplete.component';

describe('TipocomprasAutocompleteComponent', () => {
  let component: TipocomprasAutocompleteComponent;
  let fixture: ComponentFixture<TipocomprasAutocompleteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TipocomprasAutocompleteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TipocomprasAutocompleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

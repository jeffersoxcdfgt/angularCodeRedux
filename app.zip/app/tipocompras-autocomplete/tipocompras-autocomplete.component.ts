import { Component, OnInit ,ViewEncapsulation , Directive} from '@angular/core';
import { NgSelectModule } from '@ng-select/ng-select';
import { FormControl ,FormGroup, FormBuilder, Validators,FormsModule  } from '@angular/forms';
import { TipocomprasService } from '../service/tipocompras/tipocompras.service';
import { Validation } from '../validation/validation';
import { ValidationService } from '../service/validation/validation.service';
import { Tipocompra } from '../class/tipocompra';
import { TIPOCOMPRA } from '../mocks/mock-tipocompra';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/map';
import { Filtroportafolio } from '../class/filtro-portafolio';
import { FILTROPORTAFOLIO , FIRST } from '../mocks/mock-filtro';

@Component({
  selector: 'app-tipocompras-autocomplete',
  templateUrl: './tipocompras-autocomplete.component.html',
  styleUrls: ['./tipocompras-autocomplete.component.css']
})

@Directive({ selector: '[appTipoComprasTag]' })
export class TipocomprasAutocompleteComponent implements OnInit {

  tiposcompras: Tipocompra[];
  selectedTipoCompras = [];

  constructor(private formBuilder: FormBuilder,
              private tipocomprasService: TipocomprasService ,
              private validationService :ValidationService) { }

  ngOnInit() {
    this.getTipoCompras();
  }

  /*Metodo consumidor trae los tipos de compras*/
  getTipoCompras(): void {
     this.tipocomprasService.getTipoCompras()
     .subscribe(tiposcompras => {
       this.tiposcompras = tiposcompras;
     });
  }

  /*Setea el tipo de compra*/
  getTipoCompraList(){
      if(this.selectedTipoCompras !=null){
        //FILTROPORTAFOLIO[FIRST].id_tipocompra = this.selectedTipoCompras.id;
      }
  }

  reset(){
      //this.selectedTipoCompras  =null;
  }

}

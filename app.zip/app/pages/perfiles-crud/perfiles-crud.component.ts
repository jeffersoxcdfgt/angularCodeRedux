import { Component, OnInit ,Input ,TemplateRef , ViewChild , ElementRef ,OnChanges, SimpleChanges } from '@angular/core';
import { FormGroup, FormBuilder, Validators ,FormControl ,FormArray , AbstractControl } from '@angular/forms';
import { Perfil } from '../../class/perfil';
import { PerfilesService } from '../../service/perfiles/perfiles.service';
import { Validation } from '../../validation/validation';
import { ValidationService } from '../../service/validation/validation.service';
import { Controles , Menus , Permisos } from '../../class/combosperfil';
import { NgSelectModule } from '@ng-select/ng-select';
import { Transform } from '../../class/transform';
import { Observable } from 'rxjs/Observable';
import { OrderPipe } from 'ngx-order-pipe';
import { Saveperfil } from '../../class/save_perfil';
import { SAVEPERFIL , FIRSTSAVE } from '../../mocks/mock-saveperfil';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { AuthService }  from '../../service/auth/auth.service';
import { Router,NavigationExtras } from '@angular/router';
import { catchError, map, tap } from 'rxjs/operators';
import { MenuEstadoService } from '../../service/menu-estado/menu-estado.service';
import { MatDialog } from '@angular/material';
import { AlertsComponent } from '../../utils/alerts/alerts.component';

class OptPages {
  id: number;
  value: string;
  label : string;
  selected : string;
};

const enum  OPCIONES {
    MENSAJE = 0,
    MENUS    =1,
    PERMISOS =2
}

const enum  INDICE {
    PRIMERO = 0,
}

@Component({
  selector: 'app-perfiles-crud',
  templateUrl: './perfiles-crud.component.html',
  styleUrls: ['../../../assets/css/main.css',
              './perfiles-crud.component.css']
  })

export class PerfilesCrudComponent implements OnInit {
  perfiles: any[];
  display='none';
  idDelete:string;
  OpNameValue = 'add';
  data: Perfil;
  form: FormGroup;
  menus: Observable<Menus[]>;
  permisos: Observable<Permisos[]>;
  controles : Observable<Controles[]>;
  indexmenu:number;
  selectedMenus  = [];
  selectedPermisos =[];
  selectedControles =[];
  order: string = 'id';
  reverse: boolean = true;
  nombre='';
  public modalRef: BsModalRef;
  template: TemplateRef<any>
  mensaje_error = '';
  id_edit:string;
  mensaje_confirmacion = 'Desea borrar el registro ?';
  p:any;

  selectedRangePage: OptPages[] = [
    { id: 1, value: '10'  , label:'10',   selected : 'selected' },
    { id: 2, value: '20' , label:'20',  selected : ''},
    { id: 3, value: '30' , label:'30',  selected : '' }
  ];
  perpageitem: number = 10;
  idx: any;
  constructor(private formBuilder: FormBuilder,
              private perfilesService: PerfilesService,
              private validationService :ValidationService,
              private orderPipe: OrderPipe,
              private modalService: BsModalService,
              private authService: AuthService,
              private router: Router,
              private menuEstadoService: MenuEstadoService,
              public dialog: MatDialog) { }

  /*Llamada a metodo de consumo de perfiles*/
  ngOnInit() {
    this.perfiles = this.orderPipe.transform(this.perfiles, 'id');
    this.setPerfiles();
    this.getPerfiles();
    this.getListCombos();
    this.form = this.formBuilder.group({
        perfil: [null, Validators.required , this.validSpaceBlank,this.validCaracteres],
        parametrizacion: this.formBuilder.array([this.createItem()]),
    })
  }

  get perfil(): FormArray { return this.form.get('perfil') as FormArray; }
  get parametrizacion(): FormArray { return this.form.get('parametrizacion') as FormArray; }

  /*Ordenar usuarios*/
  setOrder(value: string) {
    if (this.order === value) {
      this.reverse = !this.reverse;
    }
    this.order = value;
  }

  /*Lista todos los combos*/
  getListCombos():void {
    this.perfilesService.getListCombos()
    .subscribe(
          combos => {
              this.menus = combos['menus'] ;
              this.permisos = combos['permisos'];
        });
  }

  /*Setea los controles*/
  getControles(id:number):void{
      if(this.selectedMenus[id]['controles']!=null){
        //this.controles = this.selectedMenus[id]['controles'];
        this.selectedControles[id] = this.selectedMenus[id]['controles'];
      }
  }

  /*Lista los perfiles buscados*/
  searchPerfiles(term :string):void{
    console.log(term);
    this.perfilesService.searchPerfiles(term)
    .subscribe(perfiles =>{
        this.perfiles = perfiles;
    });
  }

  /*Crea control dinamicamente*/
  createItem(): FormGroup {
      return this.formBuilder.group({
        menu: [null, Validators.required , this.validSpaceBlank],
        permiso: [null , Validators.required , this.validSpaceBlank],
        control: [null],
      });
  }

  //Valida que existan espacios en blanco
  validSpaceBlank(control: AbstractControl) {
      var pattern = /^\s+$/;
      return Observable.of(pattern.test(control.value)).pipe(
        map(result => result ? { invalid: true } : null)
      );
  }

  //Valida dimension
  validCaracteres(control: AbstractControl) {
      var pattern = /^\s{1,70}$/;
      return Observable.of(!pattern.test(control.value)).pipe(
        map(result => result ? { invalid: true } : null)
      );
  }

  //Agrega filas de parametrizacion
  addRow(): void {
    const control = <FormArray>this.form.controls['parametrizacion'];
    control.push(this.createItem());
  }

  // Elimina filas de parametrizacion
  removeRow(i: number) {
     const control = <FormArray>this.form.controls['parametrizacion'];
     this.selectedMenus.splice(i,1);
     this.selectedPermisos.splice(i,1);
     this.selectedControles.splice(i,1);
     control.removeAt(i);
  }

  //Metodo para consumir el Editar
  opEdit(id :string , op :string) : void {
      console.log('Entro '+id);
      this.animateScrollTop("30%");//$("#SubTitleTask").position().top
      this.perfilesService.getPerfilEdit(id)
          .subscribe(data=> {
              console.log(data);
              this.OpNameValue=op;
              let control = <FormArray>this.form.controls['parametrizacion'];
              while (control.length !== 0) {
                  control.removeAt(0)
              }
              this.nombre=data.nombre;
              this.id_edit=id;
              for(let i=0; i<data.menus.length;i++){
                control.push(this.createItem());
                this.selectedMenus[i]=data.menus[i];
                this.selectedPermisos[i]=data.menus[i].permisos;
                this.selectedControles[i]=data.menus[i].controles;
              }

          });
  }

  /*Metodo usado para setear Perfiles*/
  setPerfiles(): void {
   this.perfilesService.setPerfiles()
       .subscribe(data=> this.data = data);
  }

  getPerfiles(): void {
    this.perfilesService.getPerfiles()
    .subscribe(perfiles => {
            this.perfiles = perfiles;
    });
  }

  /*Metodo accion para agregar perfiles*/
  add(template: TemplateRef<any>): void {
      SAVEPERFIL[FIRSTSAVE].menus = [];
      console.log(this.selectedMenus);
      console.log(this.selectedPermisos);
      console.log(this.selectedControles);

      SAVEPERFIL[FIRSTSAVE].nombre = this.nombre;
      for(var i =0 ; i < Object.keys(this.selectedMenus).length ; i++){
          console.log(i);
          this.selectedMenus[i]['controles']=this.selectedControles[i];
          this.selectedMenus[i]['permisos']=this.selectedPermisos[i];
          SAVEPERFIL[FIRSTSAVE].menus.push(this.selectedMenus[i]);
      }
      console.log(SAVEPERFIL);

      if(this.OpNameValue=='edit'){
        SAVEPERFIL[FIRSTSAVE].id=this.id_edit;
        this.perfilesService.updatePerfil(SAVEPERFIL[FIRSTSAVE])
          .subscribe(perfil => {
             if(perfil.hasOwnProperty('mensaje')){
                  if(perfil.mensaje!=''){
                    this.mensaje_error =perfil.mensaje;
                    this.mensajeNotificacion(this.mensaje_error);
                    //this.openModal(template);
                    return;
                  }
              }
              var index = this.perfiles.findIndex(obj => obj.id== perfil.id);
              this.perfiles[index] = perfil;
              this.mensaje_error ='Perfil editado satisfactoriamente.';
              this.mensajeNotificacion(this.mensaje_error);
              //this.openModal(template);
              this.form.reset();
              this.OpNameValue='add';
        });
        return;
      }

      this.perfilesService.addPerfil(SAVEPERFIL[FIRSTSAVE])
          .subscribe(perfil => {
            if(perfil.hasOwnProperty('mensaje')){
                 if(perfil.mensaje!=''){
                   this.mensaje_error =perfil.mensaje;
                   this.mensajeNotificacion(this.mensaje_error);
                   //this.openModal(template);
                   return;
                 }
             }
            this.perfiles.push(perfil);
            this.form.reset();
            this.mensaje_error ='Perfil agregado satisfactoriamente.';
            this.mensajeNotificacion(this.mensaje_error);
            //this.openModal(template);
            this.OpNameValue='add';
      });
  }

  /*Metodo accion para borrar roles*/
  //delete(id: string , template: TemplateRef<any>): void {
    delete(id: string): void {
      this.perfilesService.deletePerfil( { id } as Perfil ).
         subscribe( perfil => {
            if(perfil.hasOwnProperty("mensaje")){ // true
             this.mensaje_confirmacion ="Error: Perfil no se puede eliminar porque se encuentra asociado a un usuario";
             this.mensajeNotificacion(this.mensaje_confirmacion);
             //this.display='block';
           }
           else{
               var index = this.perfiles.findIndex(obj => obj.id==id);
               this.perfiles.splice(index,1);
           }
         });
         this.display='none';
  }

  /*Metodo accion para editar perfiles*/
  save( perfil : Perfil): void {
     this.data = perfil;
     this.OpNameValue ='edit';
  }
  /*Metodo abre dialogo de confirmacion de borrado*/
  openModalDelete(id:string){
      //this.display='block';
      //this.mensaje_confirmacion  = 'Desea borrar el registro ?';
      this.idDelete=id;
      this.mensajeEliminacion('Desea borrar el registro ?');
  }

  /*Metodo cierra dialogo de confirmacion de borrado*/
  onCloseHandledDelete(){
       this.display='none';
  }

  /*Selecccion tipo de operacion*/
  /*typeOperation (objeto: any): void {
     (typeof objeto === 'string' && this.add())  || (typeof objeto === 'object' && this.save(objeto))
  }*/

   //Limpia elementos del array
   clearData()  {
      for (let key of Object.keys(this.data)) {
        eval(  "this.data." +key+"=''");
      }
   }

   /*Se inician metodos de validacion*/
   isFieldValid(field: string) {
   return !this.form.get(field).valid && this.form.get(field).touched;
   }

   /**Envia datos de usuarios*/
   displayFieldCss(field: string) {
   return {
     'has-error': this.isFieldValid(field),
     'has-feedback': this.isFieldValid(field)
    };
   }

   /*Se inician metodos de validacion*/
   isFieldValidArray(field: string , i: number) {
   return !this.form.get(['parametrizacion', i, field]).valid && this.form.get(['parametrizacion', i, field]).touched;
   }

   /**Envia datos de usuarios*/
   displayFieldCssArray(field: string , i: number) {
   return {
     'has-error': this.isFieldValidArray(field ,i),
     'has-feedback': this.isFieldValidArray(field,i)
    };
   }

   /*Envia datos*/
   onSubmit(template: TemplateRef<any>) {
     if (this.form.valid) {
       this.add(template);
     } else {
       this.mensaje_error="Los campos marcados con asterisco son obligatorios";
       this.mensajeNotificacion(this.mensaje_error);
       //this.openModal(template);
       this.validateAllFormFields(this.form);
     }
   }

   /*Open modal en usuarios*/
   public openModal(template: TemplateRef<any>) {
     this.modalRef = this.modalService.show(template);
   }

   /*Valida campos de formulario*/
   validateAllFormFields(formGroup: FormGroup) {
     Object.keys(formGroup.controls).forEach(field => {
     //console.log(field);
     const control = formGroup.get(field);
     if (control instanceof FormControl) {
       control.markAsTouched({ onlySelf: true });
     } else if (control instanceof FormGroup) {
       this.validateAllFormFields(control);
     }
   });
   }

    /*Limpia formulario*/
     reset() {
       this.form.reset();
       this.OpNameValue  = 'add';
    }

    public logout(){
      this.authService.logout();
      this.menuEstadoService.setMenuEstado(false);
      $('#totalizado').html('0');
      let redirect = this.authService.redirectUrl ? this.authService.redirectUrl : '/login';
      let navigationExtras: NavigationExtras = {
        queryParamsHandling: 'preserve',
        preserveFragment: true
      };
      // Redirect the user
      this.router.navigate([redirect], navigationExtras);
    }

    onChangePages(newValue){
      this.perpageitem = newValue;
    }

    animateScrollTop(px) {
      $('html, body').animate({
        scrollTop: px
      }, 'slow');
    }

    mensajeNotificacion(mensaje: string) {
      const dialogo = this.modalConfirmacion('AVISO', mensaje, 'Aceptar', false);
      dialogo.componentInstance.confirmacionCallback.subscribe(resultado => {
        dialogo.close();
      })
    }

    mensajeEliminacion(mensaje: string) {
      const dialogo = this.modalConfirmacion('AVISO', mensaje, 'Aceptar');
      dialogo.componentInstance.confirmacionCallback.subscribe(resultado => {
        this.delete(this.idDelete);
        dialogo.close();
      })
    }

    modalConfirmacion(titulo: string, mensaje: string, etiquetaConfirmacion: string, verCancelar = true, mData = null) {
      let data = {
        titulo: titulo,
        mensaje: mensaje,
        etiquetaConfirmacion: etiquetaConfirmacion,
        verCancelar: verCancelar,
      }
      return this.dialog.open(AlertsComponent, { data: data });
    }
}

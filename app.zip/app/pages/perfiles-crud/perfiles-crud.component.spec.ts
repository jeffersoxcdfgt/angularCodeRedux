import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PerfilesCrudComponent } from './perfiles-crud.component';

describe('PerfilesCrudComponent', () => {
  let component: PerfilesCrudComponent;
  let fixture: ComponentFixture<PerfilesCrudComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PerfilesCrudComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PerfilesCrudComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

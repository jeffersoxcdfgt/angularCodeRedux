import { Component, OnInit ,Input ,TemplateRef , ViewChild , ElementRef ,OnChanges, SimpleChanges } from '@angular/core';
import { FormGroup, FormBuilder, Validators ,FormControl ,FormArray , AbstractControl } from '@angular/forms';
import { CLIENTE } from '../../mocks/mock-cliente';
import { Cliente } from '../../class/cliente';
import { USUARIO  } from '../../mocks/mock-usuario';
import { Usuario  } from '../../class/usuario';
import { UsuarioService } from '../../service/usuario/usuario.service';
import { Validation } from '../../validation/validation';
import { ValidationService } from '../../service/validation/validation.service';
import { ClienteService } from '../../service/cliente/cliente.service';
import { OtAutocompleteService } from '../../service/ot-autocomplete/ot-autocomplete.service';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/map';
import { PerfilesService } from '../../service/perfiles/perfiles.service';
import { Perfil } from '../../class/perfil';
import { PERFIL } from '../../mocks/mock-perfil';
import { Tipousuario } from '../../class/tipo-usuario';
import { TipoUsuarioService } from '../../service/tipo-usuario/tipo-usuario.service';
import { OrderPipe } from 'ngx-order-pipe';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { AuthService }  from '../../service/auth/auth.service';
import { Router,NavigationExtras } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';
import { MenuEstadoService } from '../../service/menu-estado/menu-estado.service';
import { AlertsComponent } from '../../utils/alerts/alerts.component';
import { MatDialog } from '@angular/material';

class OptPages {
  id: number;
  value: string;
  label : string;
  selected : string;
};

@Component({
  selector: 'app-usuarios-crud',
  templateUrl: './usuarios-crud.component.html',
  styleUrls: ['../../../assets/css/main.css',
              './usuarios-crud.component.css'],
  providers: [UsuarioService]
})


export class UsuariosCrudComponent implements OnInit {
   clientes: Cliente[];
   selectedClientes = [];
   ots: any[];
   selectedOts = [];
   perfiles: Perfil[];
   selectedPerfiles = [];
   tipousuarios: Tipousuario[];
   selectedTipousuario = [];
   usuarios: Usuario[];
   display='none';
   idDelete:string;
   OpNameValue = 'add';
   form: FormGroup;
   data: any;
   isReadOnly=true;
   searchTerm : FormControl = new FormControl();
   order: string = 'id';
   reverse: boolean = true;
   public modalRef: BsModalRef;
   template: TemplateRef<any>
   mensaje_error:string;
   p:any;
   ChktodasOts:boolean = false;

   selectedRangePage: OptPages[] = [
    { id: 1, value: '10'  , label:'10',   selected : 'selected' },
    { id: 2, value: '20' , label:'20',  selected : ''},
    { id: 3, value: '30' , label:'30',  selected : '' }
  ];
  perpageitem: number = 10;
  idx: any;

   constructor(private formBuilder: FormBuilder,
              private usuarioService: UsuarioService,
              private validationService :ValidationService,
              private clienteService: ClienteService,
              private otAutocompleteService: OtAutocompleteService,
              private perfilesService: PerfilesService,
              private tipoUsuarioService: TipoUsuarioService,
              private orderPipe: OrderPipe,
              private modalService: BsModalService,
              private authService: AuthService,
              private router: Router,
              private menuEstadoService: MenuEstadoService,
              public dialog: MatDialog
            ) {
  }

  ngOnInit() {
      this.usuarios = this.orderPipe.transform(this.usuarios, 'id');
      this.setUsuarios();
      this.getUsuarios();
      //this.getClientes();

      this.Changeot();
      this.getPerfiles();
      this.getTipousuarios();
      this.form = this.formBuilder.group({
      cedula: [null,  Validators.required,this.validOnlyNumber],
      name: [null, Validators.required , this.validSpaceBlank],
      primerapellido: [null, Validators.required,this.validSpaceBlank],
      email: [null, [Validators.required, Validators.email]],
      telefonomovil: [null, Validators.minLength(0) , this.validOnlyPhoneNumber],
      usuario_dominio: [null],
      tipousuario: [null, [Validators.required]],
      perfil: [null, [Validators.required]],
      ot: [null, [Validators.required]],
      todas_ots: [null],
    });
  }


  //Valida datos numericos
  validOnlyNumber(control: AbstractControl) {
      var pattern = /^\d{1,20}$/;
      return Observable.of(!pattern.test(control.value)).pipe(
        map(result => result ? { invalid: true } : null)
      );
  }

  //Valida datos numericos telefonicos
  validOnlyPhoneNumber(control: AbstractControl) {
      var pattern = /^(\s*|\d+)$/;
      return Observable.of(!pattern.test(control.value)).pipe(
        map(result => result ? { invalid: true } : null)
      );
  }

  //Valida no permite espacios en blanco
  validSpaceBlank(control: AbstractControl) {
      var pattern = /^\s+$/;
      return Observable.of(pattern.test(control.value)).pipe(
        map(result => result ? { invalid: true } : null)
      );
  }

  /*Open modal en usuarios*/
  public openModal(template: TemplateRef<any>) {
    this.mensajeNotificacion(this.mensaje_error);
    // this.modalRef = this.modalService.show(template);
  }

  /*Ordenar usuarios*/
  setOrder(value: string) {
    if (this.order === value) {
      this.reverse = !this.reverse;
    }
    this.order = value;
  }

  selectedTipoUsarioFunc() : void{
     if(this.data.tipo_usuario.nombre.toUpperCase() == 'INTERNO'){
       this.isReadOnly=false;
     }
     else if(this.data.tipo_usuario.nombre.toUpperCase() == 'EXTERNO'){
       this.isReadOnly=true;
       this.data.usuario_dominio = "";
     }
  }

 /*Metodo consumidor para traer perfiles*/
 getPerfiles(): void {
    this.perfilesService.getPerfiles()
    .subscribe(perfiles => this.perfiles = perfiles);
  }

  /*Metodo consumidor para traer tipousuarios*/
  getTipousuarios(): void {
    this.tipoUsuarioService.getTipousuarios()
    .subscribe(tipousuarios => this.tipousuarios = tipousuarios);
  }

  /*Metodo usado para setear usuarios*/
  setUsuarios(): void {
   this.usuarioService.setUsuarios()
       .subscribe(data=> this.data = data);
  }

  getUsuarios(): void {
    this.usuarioService.getUsuarios()
    .subscribe(usuarios =>{
         this.usuarios = usuarios;
       });
  }

  /*Metodo accion para agregar o editar usuarios*/
  add(): void {
      if(this.OpNameValue  === 'edit'){

        console.log("Usuarios list");
        console.log(this.data);
        console.log("Usuarios list");

        this.usuarioService.updateUsuario(this.data)
          .subscribe(usuario => {
            if (usuario.mensaje !== "") {
                this.mensaje_error =usuario.mensaje;
                this.openModal(this.template);
                return;
            }
            var index = this.usuarios.findIndex(obj => obj.id== usuario.id);
            this.usuarios[index] = usuario;
            this.mensaje_error ='Usuario editado satisfactoriamente.';
            this.OpNameValue  = 'add';
            this.openModal(this.template);
            this.form.reset();
        });
        return;
      }

      this.usuarioService.addUsuario(this.data)
        .subscribe(usuario => {
          if (usuario.mensaje !== "") {
              //alert(usuario.mensaje);
              this.mensaje_error =usuario.mensaje;
              this.openModal(this.template);
              return;
          }
          this.usuarios.push(usuario);
          this.usuarios = this.orderPipe.transform(this.usuarios, 'id');
          this.mensaje_error ='Usuario agregado satisfactoriamente.';
          this.form.reset();
          this.openModal(this.template);
      });
  }

  /*Metodo accion para borrar usuarios*/
  delete(id: string): void {
     this.usuarioService.deleteUsuario( { id } as Usuario ).
         subscribe( usuario => {
           this.getUsuarios();
         });
     this.display = 'none';
   }

   /*Metodo accion para editar  usuarios*/
   save( usuario : Usuario): void {

      this.data = Object.assign({},usuario);
      this.data.ot.length = 0;
      this.OpNameValue ='edit';
      this.mensaje_error = 'Usuario editado satisfactoriamente.';

      if(this.data.tipo_usuario.toUpperCase() == "INTERNO"){
        this.isReadOnly=false;
      }
      else if(this.data.tipo_usuario.toUpperCase() == 'EXTERNO'){
        this.isReadOnly=true;
      }

      if(this.data.tipo_usuario.toUpperCase() == "INTERNO"){
        this.isReadOnly=false;
      }
      else if(this.data.tipo_usuario.toUpperCase() == 'EXTERNO'){
        this.isReadOnly=true;
      }

      if(this.data.todas_ots == "1"){
        this.ChktodasOts=true;
        this.data.todas_ots = true;
      }
      else{
        this.ChktodasOts=false;
        this.data.todas_ots = false;
      }

      for (let i = 0; i < usuario.clientes.length; i++) {
            for(let y = 0 ; y < usuario.clientes[i].ots.length; y++ ){
              var otlist = {
                 ot:usuario.clientes[i].ots[y],
                 cliente_desc:usuario.clientes[i].nombre +'-'+usuario.clientes[i].ots[y],
                 cliente_nit:usuario.clientes[i].nit
              };
              this.data.ot.push(otlist);
            }
      }
   }

   /*Metodo abre dialogo de confirmacion de borrado*/
   openModalDelete(id:string){
       //this.display='block';
       this.idDelete=id;
       this.mensajeEliminacion('Desea cambiar el estado del usuario?');
   }

   /*Metodo cierra dialogo de confirmacion de borrado*/
   onCloseHandledDelete(){
        this.display='none';
   }

   /*Selecccion tipo de operacion*/
   typeOperation (objeto: any , template: TemplateRef<any>): void {
      this.template=template;
      (typeof objeto === 'string' && this.add())  || (typeof objeto === 'object' && this.save(objeto))
      this.animateScrollTop("30%");
   }

    //Limpia elementos del array
  clearData()  {
       for (let key of Object.keys(this.data)) {
         eval(  "this.data." +key+"=''");
       }
  }

  /*Se inician metodos de validacion*/
  isFieldValid(field: string) {
  return !this.form.get(field).valid && this.form.get(field).touched;
  }

  /*Se inician metodos de validacion para campo telefono movil*/
  isFielPhoneNumberValid(field: string) {
    if (this.form.get(field).value == null) {
      return false;
    } else {
      return !this.form.get(field).valid && this.form.get(field).touched;
    }
  }

  /**Envia datos de usuarios*/
  displayFieldCss(field: string) {
  return {
    'has-error': this.isFieldValid(field),
    'has-feedback': this.isFieldValid(field)
   };
  }

  /*Envia datos*/
  onSubmit(template: TemplateRef<any> ) {
    if (this.form.valid) {
        if(this.OpNameValue  === 'edit'){
          this.add();
          return;
        }
        this.typeOperation(this.OpNameValue ,template);
    } else {
      this.validateAllFormFields(this.form);
    }
  }

  /*Valida campos de formulario*/
  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
    const control = formGroup.get(field);
    if (control instanceof FormControl) {
      control.markAsTouched({ onlySelf: true });
    } else if (control instanceof FormGroup) {
      this.validateAllFormFields(control);
    }
  });
  }

  /*Limpia formulario*/
  reset() {
    this.form.reset();
    this.OpNameValue  = 'add';

  }
  Changecliente(){
  }

  /**Trae la lista de ots , asociadas al listado de clientes seleccionado*/
  Changeot(){
    this.searchTerm.valueChanges
      .subscribe(data => {
          this.usuarioService.getOtsClientes( this.data.clientes )
              .subscribe(ots => {
                 this.ots = ots;
                 this.ots.forEach(function (value) {
                     value.cliente_desc = value.cliente_desc+"-"+value.ot;
                 });
          });
      });
  }

  /*Lista los usuarios buscados*/
  searchUsuarios(term :string):void {
    this.usuarioService.searchUsuarios(term)
    .subscribe(usuarios =>{
        this.usuarios = usuarios;
        console.log(this.usuarios);
    });
  }

  public logout(){
    this.authService.logout();
    this.menuEstadoService.setMenuEstado(false);
    $('#totalizado').html('0');
    let redirect = this.authService.redirectUrl ? this.authService.redirectUrl : '/login';
    let navigationExtras: NavigationExtras = {
      queryParamsHandling: 'preserve',
      preserveFragment: true
    };
    // Redirect the user
    this.router.navigate([redirect], navigationExtras);
  }

  onChangePages(newValue){
    this.perpageitem = newValue;
  }

  animateScrollTop(px) {
    $('html, body').animate({
      scrollTop: px
    }, 'slow');
  }

  mensajeNotificacion(mensaje: string) {
    const dialogo = this.modalConfirmacion('AVISO', mensaje, 'Aceptar', false);
    dialogo.componentInstance.confirmacionCallback.subscribe(resultado => {
      dialogo.close();
    })
  }

  mensajeEliminacion(mensaje: string) {
    const dialogo = this.modalConfirmacion('AVISO', mensaje, 'Aceptar');
    dialogo.componentInstance.confirmacionCallback.subscribe(resultado => {
      this.delete(this.idDelete);
      dialogo.close();
    })
  }

  modalConfirmacion(titulo: string, mensaje: string, etiquetaConfirmacion: string, verCancelar = true) {
    let data = {
      titulo: titulo,
      mensaje: mensaje,
      etiquetaConfirmacion: etiquetaConfirmacion,
      verCancelar: verCancelar,
    }
    return this.dialog.open(AlertsComponent, { data: data });
  }
}

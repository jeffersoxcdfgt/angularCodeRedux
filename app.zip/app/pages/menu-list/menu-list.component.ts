import { Component, OnInit , ViewEncapsulation } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MenuListService } from '../../service/menu-list/menu-list.service';
import 'rxjs/add/operator/map';

@Component({
  selector: 'app-menu-list',
  templateUrl: './menu-list.component.html',
  styleUrls: ['./menu-list.component.css'],
  providers: [MenuListService],
})
export class MenuListComponent implements OnInit {

   public list: any[];

  /*public list = [
    {
      title: 'Computers',
      url: '/api/Computers',
      children: [
        {
            title: 'Laptops',
            url: '/api/Laptops',
            children: [
                {
                  title: 'Ultrabooks',
                  url: '/api/Ultrabooks',
                  children: []
                },
                {
                  title: 'Macbooks',
                  url: '/api/Macbooks',
                  children: []
              },
           ]
      },
      {
        title: 'Desktops',
        url: '/api/Desktops',
        children: []
      },
      {
        title: 'Tablets',
        url: '/api/Tablets',
        children: [
          {
            title: 'Apple',
            url: '/api/Apple',
            children: []
          },
          {
            title: 'Android',
            url: '/api/Android',
            children: []
          },
        ]
      }
    ]
    },
    {
      title: 'Printers',
      url: '/api/Printers',
      children: []
    }
  ];*/

  constructor(private menuListService: MenuListService)
  { }

  ngOnInit() {
     this.getListMenu();
  }

  /* GET Se invoca el servicio para consumir las opciones de menu*/
  getListMenu(): void {
    this.menuListService.getListMenu()
        .subscribe(
            list => {
              this.list = list
              console.log('Valor retornado :'+JSON.stringify(this.list));
      });
  }

}

import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators ,FormControl} from '@angular/forms';
import { COTIZACION  } from '../../mocks/mock-cotizacion';
import { Cotizacion } from '../../class/cotizacion';
import { ListaCotizacionesService } from '../../service/lista-cotizaciones/lista-cotizaciones.service';
import { Validation } from '../../validation/validation';
import { ValidationService } from '../../service/validation/validation.service';
import { AuthService }  from '../../service/auth/auth.service';
import { Router,NavigationExtras } from '@angular/router';
import { MenuEstadoService } from '../../service/menu-estado/menu-estado.service';

@Component({
  selector: 'app-lista-cotizaciones',
  templateUrl: './lista-cotizaciones.component.html',
  styleUrls: ['../../../assets/css/main.css',
              './lista-cotizaciones.component.css']
})
export class ListaCotizacionesComponent implements OnInit {

  cotizacion: Cotizacion;
  cotizaciones: Cotizacion[];
  p:any;

  constructor(private formBuilder: FormBuilder,
              private listaCotizacionesService: ListaCotizacionesService,
              private validationService :ValidationService,
              private authService: AuthService,
              private router: Router,
              private menuEstadoService: MenuEstadoService) { }

  ngOnInit() {
    this.setCotizaciones();
    this.getCotizaciones();
  }


  /*Metodo usado para setear cotizaciones*/
  setCotizaciones(): void {
   this.listaCotizacionesService.setCotizaciones()
       .subscribe(cotizacion=> this.cotizacion = cotizacion);
  }

  /*Metodo consumidor para traer cotizaciones*/
  getCotizaciones(): void {
    this.listaCotizacionesService.getListaCotizaciones()
    .subscribe(cotizaciones =>{
        this.cotizaciones = cotizaciones;
    });
  }

  /*Lista las cotizaciones buscadas*/
  searchCotizaciones(term :string):void{
    this.listaCotizacionesService.searchCotizaciones(term)
    .subscribe(cotizaciones =>{
        this.cotizaciones = cotizaciones;
    });
  }

  public logout(){
    this.authService.logout();
    this.menuEstadoService.setMenuEstado(false);
    this.authService.KillToken()
        .subscribe(tokens => { }
    );

    $('#totalizado').html('0');
    let redirect = this.authService.redirectUrl ? this.authService.redirectUrl : '/login';
    let navigationExtras: NavigationExtras = {
      queryParamsHandling: 'preserve',
      preserveFragment: true
    };
    // Redirect the user
    this.router.navigate([redirect], navigationExtras);
  }

}

import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core';
import { Location } from '@angular/common';
import { SearchFichaTecnica } from '../../class/searchFichaTecnica';
import { DetalleFichaTecnica } from '../../class/detalleFichaTecnica';
import { Subject } from 'rxjs/Subject';
import { ListaDesplegableComponent } from '../../lista-desplegable/lista-desplegable.component';
import { SearchFichaTecnicaService } from '../../service/ficha-tecnica/search-ficha-tecnica.service';
import { FormBuilder, FormGroup, AbstractControl, FormControl } from '@angular/forms';
import { FichaTecnica } from '../../class/ficha-tecnica';
import { OrderPipe } from 'ngx-order-pipe';
import { FichaTecnicaService } from '../../service/ficha-tecnica/ficha-tecnica.service';
import { DetalleFicha } from '../../class/ficha-detalle';
import { TipoFacturacion } from '../../class/tipoFacturacion';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';

import { map  } from 'rxjs/operators';
import { Observable } from 'rxjs/Observable';
import { ot_display } from '../../class/ot_display';
//import { useAnimation } from '@angular/core/src/animation/dsl'
import { DetalleFechas } from '../../class/detalle_fechas';
import { PageChangedEvent } from 'ngx-bootstrap/pagination';
import { Paginate } from '../../class/paginate';
import { AuthService } from '../../service/auth/auth.service';
import { Router, NavigationExtras, ActivatedRoute } from '@angular/router';
import { MisSolicitudes } from '../../class/mis-solicitudes';
import { Usuario } from '../../class/usuario';
import { CONTROLESEGURIDAD } from '../../mocks/mock-control-seguridad';
import { ControlesSeguridad } from '../../class/controles_seguridad';
import { ControlSeguridadService } from '../../service/control-seguridad/control-seguridad.service';
import { getPathToSend } from '../../utils/utils';
import { MatDialog } from '@angular/material';
import { AlertsComponent } from '../../utils/alerts/alerts.component';
import { SpinerCargandoComponent } from '../../utils/spiner-cargando/spiner-cargando.component';

@Component({
  selector: 'app-ficha-tecnica',
  templateUrl: './ficha-tecnica.component.html',
  styleUrls: ['../../../assets/css/main.css', './ficha-tecnica.component.css']
})
export class FichaTecnicaComponent implements OnInit {
  @ViewChild('ctrClientes') ctrClientes: ListaDesplegableComponent;
  @ViewChild('ctrOts') ctrOts: ListaDesplegableComponent;
  @ViewChild('ctrUnidad') ctrUnidad: ListaDesplegableComponent;
  @ViewChild('ctrCategorias') ctrCategorias: ListaDesplegableComponent;
  @ViewChild('ctrFacturacion') ctrFacturacion: ListaDesplegableComponent;
  @ViewChild('ctrCargos') ctrCargos: ListaDesplegableComponent;
  @ViewChild('ctrAprobadores') ctrAprobadores: ListaDesplegableComponent;
  @ViewChild('ctrAno') ctrAno: ListaDesplegableComponent;
  dataAll: any[];
  clientesList: any[];
  unidadItem = [];
  AllUnidadItem = [];
  clientesItem = [];
  otItem = [];
  categoriaItem = [];
  cargoItem = [];
  cargoCiudadesItem = [];
  tipoFacturaItem = [];
  aprobadoreItem = [];
  clienteSelected = [];
  usuariosAprobadores = [];
  usuarioIdModel: string;
  btnAprobar: Boolean = false;
  respMensaje: any;
  //valueFechaInicial: any;
  //valueFechaFinal: any;

  nitCliente: string;
  clientes: any[];
  ots: any[];
  cargos: any[];
  factura: any[];
  unidad: any[];
  categoria: any[];
  ot: string;
  txtNit: string;
  txtCupo: string;
  idAprobador: string;
  txtPresupuesto: string;
  txtObservaciones: string;
  lblHistoricoObservaciones: string = "";
  cuposDisponibles: number;
  searchFichaTecnica: SearchFichaTecnica;
  detalleFichaTecnica: DetalleFichaTecnica[];
  dtOptions: any = {};
  accion: string;
  dtTrigger: Subject<any> = new Subject<any>();
  resp: any;
  selectedFechaInicial  = [];
  checkedAll: boolean;
  showAlert: boolean = false;
  typeAlert: string;
  classEnvioAprobar: string = 'fade';
  estadoEnvioAprobar: string;
  mensajeEnvioAprobar: string;

  /* Inicio table como las demas paginas */
  fichasNew: FichaTecnica;
  fichas: FichaTecnica;
  detalleFicha: DetalleFicha[]= [];//FichaTecnica["detalle"];
  detalleFichaEdit: DetalleFicha[];
  addLineFicha: DetalleFicha;
  dataDetalle: any; //FichaTecnica["detalle"];
  form: FormGroup;
  idDelete: string;
  cargando: boolean = true;
  OpNameValue = 'add';
  ot_cliente: ot_display;
  idRowDetalle: string;
  indexDetalle: Number;
  idFicha: number;
  showBoundaryLinks = true;
  totalItems: number;
  itemsPerPage: string;
  returnedArray: string[];

  imagenSubir: File;
  imagenTemp: string;
  pathsend :string;
  controlesseguridad : ControlesSeguridad;
  listcontroleseguridad :ControlesSeguridad[];

  /*Inicio datatable */
  public data: any[];
  public filterQuery = "";
  public rowsOnPage = 5;
  public sortBy = "email";
  public sortOrder = "asc";
  /*Fin datatable */
/*Inicio para la modal*/
modalRef: BsModalRef;
tituloModal: string;
textoModal: string;
showBtnAceptarModal: boolean=false;
displayerrorshow='none';
/*Fin para la modal*/
deleteRowDetalle: DetalleFicha;
mensajes: string;

/*Inicio para detalle fechas */
detalleFechas: DetalleFechas[] = [];
/**fin detalle fecha */
order: string = 'id';
reverse: boolean = true;
p:any;
ano: any[];
fecha = new Date();
selectedAno: number = 0;
showLoad: boolean = false;
idx: any;
mostrarErrorCategoria: boolean = false;
mostrarErrorCargo: boolean = false;
mostrarErrorTipoFactura: boolean = false;
mostrarErrorPresupuesto: boolean = false;
  constructor(
    private formBuilder: FormBuilder,
    private searchFichaTecnicaService: SearchFichaTecnicaService,
    private fichaTecnicaService: FichaTecnicaService,
    private orderPipe: OrderPipe,
    private modalService: BsModalService,
    private authService: AuthService,
    private location: Location,
    private router: Router,
    private _router: ActivatedRoute,
    private controlSeguridadService :ControlSeguridadService,
    public dialog: MatDialog,
  ) {
    this.ano = [
      {id: this.fecha.getFullYear()-4, value: this.fecha.getFullYear()-4},
      {id: this.fecha.getFullYear()-3, value: this.fecha.getFullYear()-3},
      {id: this.fecha.getFullYear()-2, value: this.fecha.getFullYear()-2},
      {id: this.fecha.getFullYear()-1, value: this.fecha.getFullYear()-1},
      {id: this.fecha.getFullYear(), value: this.fecha.getFullYear()},
      {id: this.fecha.getFullYear()+1, value: this.fecha.getFullYear()+1},
      {id: this.fecha.getFullYear()+2, value: this.fecha.getFullYear()+2},
      {id: this.fecha.getFullYear()+3, value: this.fecha.getFullYear()+3},
      {id: this.fecha.getFullYear()+4, value: this.fecha.getFullYear()+4}];

    this.getDataAll();
    this.pathsend=getPathToSend(router.parseUrl(location.path()));
    this.fichas = new FichaTecnica;
    this.fichas.img_cliente = "assets/images/logos_clientes/logo_default.png";
  }

  getDataAll(){
    this.fichaTecnicaService.getData()
      .subscribe(resp => {
        this.clientesItem = resp.clientes;
        this.AllUnidadItem = resp.unidad;
        this.unidadItem = this.onlyUnique(resp.unidad.map( val => ({ID: val.ID, NOMBRE: val.NOMBRE })), 'ID');
        this.otItem = resp.ot;
        this.categoriaItem = resp.categorias;
       // this.cargoItem = resp.cargos;
        this.tipoFacturaItem = resp.tipo_facturas;
        let ottemp = this._router.snapshot.paramMap.get('ot');
        this.findFicha(this._router.snapshot.paramMap.get('ot'));
      });
  }

  ngOnInit() {
    this.setControlesSeguridad();
    this.getControlesSeguridad();

    this.ctrAno.selectedItem = this.ano.find(x => x.id == this.fecha.getFullYear());
    this.fichas = this.orderPipe.transform(this.fichas, 'id');
  }

   //Find fichas
   private findFicha(ot){

    if(ot != null){
      let searchDatos = {
        'ot' : ot,
        'id_categoria' : null,
        'id_cargo' : null,
        'id_tipo_factura' : null
      }
      this.ctrOts.selectedItem = this.otItem.find(x => x.ID_OT == ot);
      this.ctrClientes.selectedItem = this.clientesItem.find(x=> x.NIT == this.ctrOts.selectedItem["ID_CLIENTE"]);
      this.ctrUnidad.selectedItem = this.AllUnidadItem.find(x=> x.OT == ot);
      this.txtNit = this.ctrOts.selectedItem["ID_CLIENTE"];
      //this.idFicha = ot;

      this.ctrCargos.selectedItem = [];
      this.controles(ot);

      this.fichaTecnicaService.getFichas(searchDatos)
        .subscribe((fichas: FichaTecnica) => {

          if(fichas.mensaje == ""){
            let img_cliente = (this.fichas.img_cliente!=null && this.fichas.img_cliente !="")?this.fichas.img_cliente:"assets/images/logos_clientes/logo_default.png";
            this.accion = "edit";
            this.fichas = fichas;
            this.detalleFicha = fichas.detalle;
            this.idFicha = fichas.id;
            this.fichas.img_cliente = (fichas.img_cliente!=null && fichas.img_cliente !="")?fichas.img_cliente: img_cliente;

            this.cargando = false;
          }
          else{
            this.idFicha = null;
            this.accion = "";
            this.textoModal = fichas.mensaje;
            this.tituloModal = 'No existe';
            //this.openModal(templateModal);
          }
        });
    }
  }

  //Valida no permite espacios en blanco
  validSpaceBlank(control: AbstractControl) {
    var pattern = /^\s+$/;
    return Observable.of(pattern.test(control.value)).pipe(
      map(result => result ? { invalid: true } : null)
    );
  }

  setClietes(rowsCliente: any[]):void{
    this.clientes = rowsCliente;
  }

  setCargos(rows: any[]):void{
    this.cargos = rows;
  }

  setFacturas(rows: TipoFacturacion[]):void{
    this.factura = rows;
  }

  ngAfterViewInit(): void {
    this.dtTrigger.next();
  }


  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }

  searchFicha():void{
    this.searchFichaTecnicaService.getFicha(this.ctrOts.selectedItem["ID_OT"])
      .map((resultado)=>{
        return this.searchFichaTecnica
      })
      .subscribe(searchFichaTecnica => {
          this.searchFichaTecnica = <SearchFichaTecnica>searchFichaTecnica,
          this.detalleFichaTecnica = <DetalleFichaTecnica[]>searchFichaTecnica.datos.detalle,
          this.dtTrigger.next()
        })

  }

  private extractData(searchFichaTecnica: SearchFichaTecnica) {
    const body = searchFichaTecnica;
    return body.datos || {};
  }

  /*Metodo consumidor para traer las fichas*/
  getFichas(templateModal): void {
    //this.cargando = true;
    if(this.ctrOts.selectedItem["ID_OT"] != null){
      let searchDatos = {
        'ot' : this.ctrOts.selectedItem["ID_OT"],
        'id_categoria' : (this.ctrCategorias.selectedItem != null)?this.ctrCategorias.selectedItem.map(x => x.GRUPO).toString():null,
        'id_cargo' : (this.ctrCargos.selectedItem != null)?this.ctrCargos.selectedItem.map(x => x.COD_CARGO).toString():null,
        'id_tipo_factura': (this.ctrFacturacion.selectedItem != [] && this.ctrFacturacion.selectedItem != null)?this.ctrFacturacion.selectedItem['ID']:null,
        'ano': (this.ctrAno.selectedItem != null)?this.ctrAno.selectedItem['id']:null
        //'fecha_inicial': this.valueFechaFinal,
        //'fecha_final': this.valueFechaFinal
      }
      this.fichaTecnicaService.getFichas(searchDatos)//this.ctrOts.selectedItem["ID_OT"]
        .subscribe((fichas: FichaTecnica) => {
          if(fichas.id != null){
            this.fichas.id = fichas.id;
            this.idFicha = fichas.id;
            this.fichas = fichas;
            this.fichas.ot = this.ctrOts.selectedItem["ID_OT"];
            this.fichas.id_cliente = this.ctrClientes.selectedItem["NIT"];
          }

          if(fichas.mensaje == ""){
            let img_cliente = (this.fichas.img_cliente!=null && this.fichas.img_cliente !="")?this.fichas.img_cliente:"assets/images/logos_clientes/logo_default.png";
            this.accion = "edit";
            this.fichas = fichas;
            this.fichas.id = fichas.id;
            this.detalleFicha = fichas.detalle;
            this.idFicha = fichas.id;
            this.fichas.img_cliente = (fichas.img_cliente!=null && fichas.img_cliente !="")?fichas.img_cliente: img_cliente;
            //this.ctrUnidad.selectedItem =  this.unidadItem.find(x=>x.ID === fichas.id_unidad);
            //this.totalItems = fichas.detalle.total;
            //this.itemsPerPage = fichas.detalle.per_page;
            //console.log(fichas.detalle.total);
            this.cargando = false;
            this.lblHistoricoObservaciones = fichas.observaciones;
          }
          else{
            /*this.idFicha = null;
            this.accion = "";
            this.textoModal = fichas.mensaje;
            this.tituloModal = 'No existe';
            this.openModal(templateModal);*/
            const dialogo = this.modalConfirmacion('No existe', fichas.mensaje, 'Aceptar',false);
            dialogo.componentInstance.confirmacionCallback.subscribe(resultado=>{
              dialogo.close();
            })
          }
        });
    }else{
      this.mensajeNotificacion('Debe seleccionar una OT');
    }
  }

  /*Metodo accion para editar clientes*/
  editarDetalleFicha(templateModal, detalleFicha : DetalleFicha, index: number): void {
    if(this.rowProcesado(templateModal, detalleFicha))
    {
      return;
    }
    this.accion="edit";
    this.idRowDetalle = detalleFicha["ID"].toString();
    this.indexDetalle = this.onIndexOf(detalleFicha);
    this.ctrCategorias.closeSelect = true;
    this.ctrCategorias.multiple = false;
    this.ctrCategorias.selectedItem = this.categoriaItem.find(o=>o.GRUPO === detalleFicha.ID_CATEGORIA);
    this.ctrCategorias.disabled = true;
    this.ctrCargos.closeSelect = true;
    this.ctrCargos.multiple = false;
    this.ctrCargos.selectedItem = this.cargoItem.find(o => o.COD_CARGO  === detalleFicha.ID_CARGO);
    this.ctrFacturacion.closeSelect = true;
    this.ctrFacturacion.multiple = false;
    this.ctrFacturacion.selectedItem = this.tipoFacturaItem.find(o => o.ID  === detalleFicha.ID_TIPO_FACTURA);

    this.txtCupo = detalleFicha["CUPO"].toString();
    this.txtPresupuesto = detalleFicha["PRESUPUESTO"];
 }

 getFechas(templateModal, detalleFicha : DetalleFicha): void {
  this.fichaTecnicaService.getFechas(detalleFicha.ID)
    .subscribe((fecha: DetalleFechas[]) =>{
      this.detalleFechas = fecha;
      templateModal.show();
    });

 }

 deleteFicha(templateModal){
  // this.closeModal();
   this.tituloModal = "";
   this.textoModal = "";
  this.cargando = true;
  //this.showBtnAceptarModal = false;
  //this.childOt.ot = this.ots.filter(o=> !!this.childCliente.customers.find(x => x.nit == o.clientes.nit) );

  let deleteTemp = this.detalleFicha.filter(x=>x.ESTADO != 3 && x.CHECKED == true);
  let deleteTem = 0;
  deleteTemp.forEach(element => {
    if(element.ID == 0){
      deleteTem = this.detalleFicha.indexOf(element);
      this.detalleFicha.splice(deleteTem, 1);
    }
  });
  if (this.detalleFicha.length > 0)
  {
    let ids = this.detalleFicha.filter(o=>o.CHECKED == true ).map(x=>x.ID);
    if(ids.length > 0 ){ //!= null
      this.fichaTecnicaService.deleteLineFicha(ids.toString())
        .subscribe((resp: any) => {
            this.detalleFicha = resp.length > 0 ? resp : [];
            this.textoModal = this.fichaTecnicaService.mensaje;
            this.tituloModal = (this.fichaTecnicaService.typeMessage)?'Eliminado':'Error';
            this.openModal(templateModal);
            /*if(this.fichaTecnicaService.typeMessage && resp.length > 0){
              this.getFichas(templateModal);
            }*/
            this.showBtnAceptarModal = false;
            this.cargando = false;
            this.showLoad = false;
        });
    }
    else{
      this.tituloModal = 'Eliminado';
      this.textoModal = 'Registros eliminados correctamente';
      //this.modalConfirmacion(this.tituloModal,this.textoModal,'Aceptar');
      this.openModal(templateModal);
    }
  }
  else{
    this.tituloModal = 'Eliminado';
    this.textoModal = 'Registros eliminados correctamente';
    //this.modalConfirmacion(this.tituloModal,this.textoModal,'Aceptar');
    this.openModal(templateModal);
  }

 }

 deleteLine(templateModal):void{
    let rows = this.detalleFicha.find(x=>x.CHECKED === true);
    if(rows === undefined){
      this.tituloModal = 'Advertencia';
      this.textoModal = 'No hay registros seleccionados para eliminar';
      this.openModal(templateModal);

    }
    else{
      this.tituloModal = 'Advertencia';
      this.textoModal = '¿Está seguro que desea eliminar el registro?';
      this.openModal(templateModal, true);
    }
    //this.modalConfirmacion(this.tituloModal,this.textoModal,'Aceptar');
 }

  change(detFicha: DetalleFicha, templateModal?, index?){
    this.checkedAll =false;
    if(this.rowProcesado(templateModal, detFicha))
    {
      detFicha.CHECKED = false;
      return;
    }
    if(detFicha.PROCESADO != null && detFicha.PROCESADO.toString() == "111"){
      detFicha.CHECKED = false;
      this.tituloModal= "Advertencia";
      this.textoModal = "El registro no puede ser eliminado porque ya supero la fecha de cancelación";
      this.modalConfirmacion(this.tituloModal,this.textoModal,'Aceptar');
      //this.openModal(templateModal);
    }
    else if(detFicha.ESTADO == 2 || detFicha.ESTADO == 7){
      this.detalleFicha.find(x=>x.ID_CARGO === detFicha.ID_CARGO && x.ID_CATEGORIA === detFicha.ID_CATEGORIA && x.ID_FRECUENCIA === detFicha.ID_FRECUENCIA && x.ID_TIPO_FACTURA === detFicha.ID_TIPO_FACTURA ).CHECKED = !detFicha.CHECKED;
    }
    else{
      this.detalleFicha.find(x=>x.ID === detFicha.ID).CHECKED = !detFicha.CHECKED;
    }

  }

  selectAll(selectItems): void{
    this.detalleFicha.filter(r=>r.PROCESADO != 1).map(f=>f.CHECKED = selectItems.checked);
  }

  selectImage(archivo: File){
    if(!archivo){
      this.imagenSubir = null;
      return;
    }

    if(archivo.type.indexOf('image') < 0){
      //return "El archivo seleccionado no es una imagen";
      this.imagenSubir = null;
      return;
    }

    this.imagenSubir = archivo;
    let reader = new FileReader();
    let urlImagenTemp = reader.readAsDataURL(archivo);
    reader.onloadend = () => this.imagenTemp = reader.result;
  }

  saveFicha(templateModal){
    this.fichas.id_unidad = this.ctrUnidad.selectedItem["ID"];
    this.fichas.desc_unidad = this.ctrUnidad.selectedItem["NOMBRE"];
    this.fichas.estado = 1;
    this.fichas.id_cliente = this.ctrClientes.selectedItem["NIT"];
    this.fichas.desc_cliente = this.ctrClientes.selectedItem["NOMBRE"];
    this.fichas.ot = this.ctrOts.selectedItem["ID_OT"];
    //this.fichas.ciudades = [];
    //this.fichas.detalle = [];
    if(this.detalleFicha != null){
      //this.fichas.detalle = this.detalleFicha.filter(w=>w.estado >= 2);
      this.fichas.detalle = this.detalleFicha.filter(w=>w.ESTADO == 7 || w.ESTADO == 8);
      //this.fichas.ciudades = this.cargoCiudadesItem;
    }
    if(this.ctrOts.selectedItem["ID_OT"] != null){
      if(this.fichas.id != null && this.fichas.id.toString() != ""){
        this.accion = "edit";
        this.idFicha = this.fichas.id;
        this.editFicha(templateModal);
      }
      else{
        this.idFicha = null;
        this.accion = "";
        this.createFicha(templateModal);
      }
    }

  }

  createFicha(templateModal){
    //this.fichas.ciudades = [];
    this.fichaTecnicaService.addFicha(this.fichas)
      .subscribe(ficha =>{
        if(ficha.mensaje === ""){
          this.textoModal = "Los registros fueron guardados correctamente";
          this.tituloModal = "Guardado";
          this.fichas = ficha;
          this.detalleFicha = ficha.detalle;
          this.idFicha = ficha.id;
        }
        else{
          this.textoModal = ficha.mensaje;
          this.tituloModal = "Error";
        }
        this.openModal(templateModal);
      });

  }

  editFicha(templateModal){
      this.fichaTecnicaService.updateDetalleFicha(this.fichas)
          .subscribe(ficha =>{
            if(ficha.mensaje === ""){
              this.textoModal = "Los registros fueron editados correctamente";
              this.tituloModal = "Modificado";
              this.fichas = ficha;
              this.detalleFicha = ficha.detalle;
              this.idFicha = ficha.id;
            }
            else{
              this.textoModal = ficha.mensaje;
              this.tituloModal = "Error";
            }
            this.openModal(templateModal);
          });
  }

  rowProcesado(templateModal, rowDetalle: DetalleFicha){
    if(rowDetalle != null && (rowDetalle.ESTADO == 11 || rowDetalle.ESTADO == 3)){
      this.textoModal = 'Registro no puede ser modificado';
      this.tituloModal = 'Advertencia';
      this.openModal(templateModal);
      return true;
    }
  }

  openModal(template, eliminar?: boolean) {
    this.accion = "";
    this.showBtnAceptarModal = false;
    if(eliminar){
      this.showBtnAceptarModal = true;
      this.accion = "delete";
    }
    template.show();
  }

  closeModal(){
    this.accion = "";
    this.showBtnAceptarModal = false;
    this.modalRef.hide();
  }

  /*Valida campos de formulario*/
  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
    const control = formGroup.get(field);
    if (control instanceof FormControl) {
      control.markAsTouched({ onlySelf: true });
    } else if (control instanceof FormGroup) {
      this.validateAllFormFields(control);
    }
  });
  }

  pageChanged(event: PageChangedEvent): void {
    this.cargando = true;
    if(this.ot != null){
      this.fichaTecnicaService.getDetalleFichas(this.ot+'?page='+event.page)
        .subscribe((paginate: Paginate) => {
            this.detalleFicha = paginate.data;
            this.totalItems = paginate.total;
            this.itemsPerPage = paginate.per_page;
            this.cargando = false;

        });
    }
  }

  public logout(){
    this.authService.logout();
    $('#totalizado').html('0');
    let redirect = this.authService.redirectUrl ? this.authService.redirectUrl : '/login';
    let navigationExtras: NavigationExtras = {
      queryParamsHandling: 'preserve',
      preserveFragment: true
    };
    // Redirect the user
    this.router.navigate([redirect], navigationExtras);
  }


  public cargandoImagen(event){
		this.fichaTecnicaService.postFileImagen(<File>event.target.files[0], this.txtNit).subscribe(
			response => {
        let c=response["file"];
        this.fichas.img_cliente = response["file"];
			},
			error => {
				console.log(<any>error);
			}
		);
  }

  public clienteChange(event){
    this.ctrOts.selectedItem = [];
    this.ctrCargos.items = [];
    this.clearFiters();
    //this.fichas = null;
    this.detalleFicha = [];
    if(event == null){
      this.ctrClientes.selectedItem = [];
      this.txtNit = "";
      this.ctrOts.items = this.otItem;
      this.ctrUnidad.items = this.unidadItem;
      this.ctrUnidad.selectedItem = [];
    }
    else{
      this.txtNit = event.NIT;
      this.ctrOts.items = this.otItem.filter(x=>x.ID_CLIENTE == event.NIT);
      this.ctrUnidad.items = this.unidadItem.filter(x=>x.ID = event.NEGOCIO);
    }

  }

  public otChange(event){
    this.detalleFicha = [];
    this.ctrCargos.items = [];
    this.idFicha = null;
    this.clearFiters();
    if(event == null){
      this.ctrClientes.selectedItem = [];
      this.ctrClientes.items = this.clientesItem;
      this.ctrUnidad.selectedItem = [];
      this.ctrUnidad.items = this.unidadItem;
      this.txtNit = "";
      this.ctrCargos.items = this.cargoItem;
    }
    else{
      this.ctrClientes.selectedItem = this.clientesItem.find(x=>x.NIT == event.ID_CLIENTE);
      //this.ctrUnidad.items = this.unidadItem.filter(x=> !!this.clientesItem.find(o=>o.NEGOCIO == x.ID) );
      this.ctrUnidad.selectedItem = this.AllUnidadItem.find(x=> x.OT == event.ID_OT);
      this.txtNit = event.ID_CLIENTE;
      this.idFicha = event.ID_OT;
      this.ctrCargos.selectedItem = [];
      this.controles(event.ID_OT);
    }
  }

  public unidadChange(event){
    if(event == null){
      this.ctrClientes.selectedItem = [];
      this.ctrClientes.items = this.clientesItem;
      this.txtNit = "";
      this.ctrOts.selectedItem = [];
      this.ctrOts.items = this.otItem;
    }
    else{
      let listClientes = this.clientesItem.filter(x=>x.NEGOCIO == event.ID);
      this.ctrClientes.items = listClientes;
      this.ctrClientes.selectedItem = [];
      this.txtNit = "";
      if(listClientes.length == 1){
        this.ctrClientes.selectedItem = listClientes[0];
        this.txtNit = listClientes[0].NIT;
      }

    }
  }

  public cargoChange(event){
    if(event != null && event.length == 1 ){
      this.txtCupo = event[0].CUPOS_APROBADOS;
    }
    else{
      this.txtCupo = "";
    }
    //this.ctrUnidad.items = this.unidadItem.filter(x=> !!this.clientesItem.find(o=>o.NEGOCIO == x.ID) );
    //this.fichas.ciudades = this.cargoCiudadesItem.filter(x => !!this.ctrCargos.selectedItem.cargoItem.find )
  }

  public aprobadorChange(event){
    if(event != null && event != undefined ){
      this.idAprobador = event.id;
    }
    else{
      this.idAprobador = "";
    }
  }

  public controles(ot){
    this.ctrCargos.loadingList = true;
    this.fichaTecnicaService.getFichaCargos(ot)
    .subscribe(resp => {
      this.cargoItem = resp.cargos;
      this.ctrCargos.items  = resp.cargos;
      //this.cargoCiudadesItem = resp.cargos_detalle;
      this.ctrCargos.loadingList = false;
    });
  }

  addRow1(templateModal) {
    if(this.validControls()){
      return;
    };
   let _id_cargo, _cargo, _id_categoria, _categoria, _items, _id_facturacion, _facturacion, _id_frecuencia, _frecuencia;
   let detalleOld;
   this.mensajes = "";
   if(this.accion === "edit" && this.idRowDetalle != null && this.idRowDetalle != ""){
     _id_cargo = this.ctrCargos.selectedItem["LINEA_CARGO"];
     _cargo = this.ctrCargos.selectedItem['DESC_CARGO'];
     _id_categoria = this.ctrCategorias.selectedItem['GRUPO'];
     _categoria =  this.ctrCategorias.selectedItem['DESCRIPTION'];
     _id_facturacion = this.ctrFacturacion.selectedItem['ID'];
     _facturacion = this.ctrFacturacion.selectedItem['VALUE'];
     _id_frecuencia = 30;
     _frecuencia = 'Compra por demanda';

     if(this.idRowDetalle == "0" && this.indexDetalle != null){
        detalleOld = this.detalleFicha[this.indexDetalle.toString()];
      }
      else{
        detalleOld = this.detalleFicha.filter(o=>o.ID.toString() === this.idRowDetalle);
      }
     if (_id_categoria != detalleOld.category_id || _id_cargo != detalleOld.cod_cargo || _id_frecuencia != detalleOld.id_frecuencia || _id_facturacion != detalleOld.id_tipo_factura ||this.txtPresupuesto != detalleOld.presupuesto){
       _items = this.detalleFicha.filter(d=>d.ID_CATEGORIA === _id_categoria && d.ID_CARGO === _id_cargo && d.ID_FRECUENCIA === _id_frecuencia && d.ID_TIPO_FACTURA === _id_facturacion);
       if (_items.length>0){
           this.mensajes = this.mensajes + " "+_categoria + " - " + _cargo + " - " + _facturacion + " - " + _frecuencia;
           this.textoModal = "<p>Los siguientes datos no fueron agregados a la grilla porque la combinación <b>categoría, cargo, tipo facturación y frecuencia</b>, ya se encuentra registrada.</p><hr />"+ this.mensajes;
           this.tituloModal = 'Error';
           this.openModal(templateModal);
           return;
       }
     }

     if(this.idRowDetalle == "0" && this.indexDetalle != null){
        this.detalleFicha.filter(d=>d.ID_CATEGORIA === detalleOld.id_categoria && d.ID_CARGO === detalleOld.id_cargo
                              && d.ID_FRECUENCIA === detalleOld.id_frecuencia && d.ID_TIPO_FACTURA === detalleOld.id_tipo_factura)
                        .map(resp=>{
                          resp.ID_CARGO = _id_cargo;
                          resp.CARGO = _cargo;
                          resp.ID_CATEGORIA = _id_categoria;
                          resp.CATEGORIA = _categoria;
                          resp.PRESUPUESTO = this.txtPresupuesto;
                          resp.ID_FRECUENCIA = _id_frecuencia;
                          resp.CUPO = this.ctrCargos.selectedItem['CUPOS_CONTRATADOS'];
                          resp.CUPO_DISPONIBLE = this.ctrCargos.selectedItem['CUPOS_DISPONIBLES'];
                          resp.ID_TIPO_FACTURA = this.ctrFacturacion.selectedItem['ID'];
                          resp.TIPO_FACTURA = this.ctrFacturacion.selectedItem['VALUE'];
                          resp.ESTADO = 8;
                        });
      }
      else{
        this.detalleFicha.filter(w=>w.ID.toString() === this.idRowDetalle).map(resp=>{
                                                        resp.ID_CARGO = _id_cargo;
                                                        resp.CARGO = _cargo;
                                                        resp.ID_CATEGORIA = _id_categoria;
                                                        resp.CATEGORIA = _categoria;
                                                        resp.PRESUPUESTO = this.txtPresupuesto;
                                                        resp.ID_FRECUENCIA = _id_frecuencia;
                                                        resp.CUPO = this.ctrCargos.selectedItem['CUPOS_CONTRATADOS'];
                                                        resp.CUPO_DISPONIBLE = this.ctrCargos.selectedItem['CUPOS_DISPONIBLES'];
                                                        resp.ID_TIPO_FACTURA = this.ctrFacturacion.selectedItem['ID'];
                                                        resp.TIPO_FACTURA = this.ctrFacturacion.selectedItem['VALUE'];
                                                        resp.ESTADO = 8;
                                                      });
      }


       this.ctrCategorias.closeSelect = false;
       this.ctrCategorias.multiple = true;
       this.ctrCategorias.disabled = false;
       this.ctrCargos.closeSelect = false;
       this.ctrCargos.multiple = true;
       this.ctrFacturacion.closeSelect = false;
       this.ctrFacturacion.multiple = true;
   }
   else{
     for(var i=0; i <= this.ctrCategorias.selectedItem.length - 1; i++){
       for(var j=0; j<=this.ctrCargos.selectedItem.length - 1; j++){

         _id_cargo = this.ctrCargos.selectedItem[j]['COD_CARGO']
         _cargo = this.ctrCargos.selectedItem[j]['DESC_CARGO'];
         _id_categoria = this.ctrCategorias.selectedItem[i]['GRUPO'];
         _categoria =  this.ctrCategorias.selectedItem[i]['DESCRIPTION'];

         _id_facturacion = this.ctrFacturacion.selectedItem['ID'];
         _facturacion = this.ctrFacturacion.selectedItem['VALUE'];
         _id_frecuencia = 30;
         _frecuencia = 'Compra por demanda';

         _items = (this.detalleFicha != null && this.detalleFicha.length >0)? this.detalleFicha.filter(d=>d.ID_CATEGORIA === _id_categoria && d.ID_CARGO == _id_cargo && d.ID_TIPO_FACTURA == _id_facturacion && d.ID_FRECUENCIA == _id_frecuencia):0;
         if (_items.length>0){
           this.mensajes = this.mensajes + " "+_categoria + " - " + _cargo + " - " + _facturacion + " - " + _frecuencia;
         }
         else{
           let item = {
            ID: 0,
            ID_FICHA: this.idFicha,
             ot: this.ctrOts.selectedItem['ID_OT'],
             ID_CATEGORIA: _id_categoria,
             CATEGORIA: _categoria,
             ID_CARGO: _id_cargo,
             CARGO: _cargo,
             CUPO: this.ctrCargos.selectedItem[j]['CUPOS_CONTRATADOS'],
             CUPO_DISPONIBLE: this.ctrCargos.selectedItem[j]['CUPOS_APROBADOS'] - this.ctrCargos.selectedItem[j]['CUPOS_CONTRATADOS'],
             ID_TIPO_FACTURA: _id_facturacion, //this.ctrFacturacion.selectedItem['ID'],
             TIPO_FACTURA: _facturacion, //this.ctrFacturacion.selectedItem['VALUE'],
             PRESUPUESTO: this.txtPresupuesto,
             ESTADO: 7,
             ENERO: '',
             FEBRERO: '',
             MARZO: '',
             ABRIL: '',
             MAYO: '',
             JUNIO: '',
             JULIO: '',
             AGOSTO: '',
             SEPTIEMBRE: '',
             OCTUBRE: '',
             NOVIEMBRE: '',
             DICIEMBRE: '',
             PROCESADO: 0,
             CHECKED: false,
             ID_FRECUENCIA: 30,
             FRECUENCIA: 'Compra por demanda',
             ANO: null
           };
           this.detalleFicha[(this.detalleFicha != null)?this.detalleFicha.length: 0] = item;
         }
       }
     }


   }
   this.ctrCategorias.selectedItem = [];
     this.ctrCargos.selectedItem = [];
     this.ctrFacturacion.selectedItem = [];
     this.txtPresupuesto = null;
     this.txtCupo = "";
   if (this.mensajes != null && this.mensajes != ""){
     this.textoModal = "<p>Los siguientes datos no fueron agregados a la grilla porque la combinación <b>categoría, cargo, tipo facturación y frecuencia</b>, ya se encuentra registrada.</p><hr />"+ this.mensajes;
     this.tituloModal = 'Error';
     this.openModal(templateModal);
   }
   //this.accion = "";
   this.idRowDetalle = "";
 }

  cleanData(){
    this.accion = "";
    this.fichas = null;
    this.detalleFicha = [];
    this.idFicha = null;
  }

  public enviarAprobar(templateModalUsuarioAprueba: any){
    this.typeAlert = 'success';
    this.showAlert = false;
    let solicitar = new MisSolicitudes;
    if(this.fichas.id != undefined && this.fichas.id != null){
      solicitar.ID_PROCESO = this.fichas.id.toString();
      solicitar.OT = this.fichas.ot;
      solicitar.ID_CLIENTE = this.fichas.id_cliente;
      solicitar.ID_TIPO_SOLICITUD = "6";
      solicitar.ID_ESTADO_SOLICITUD = "2";
      solicitar.ID_USUARIO_DES = this.idAprobador;
      const loading = this.lanzarLoading();
      this.fichaTecnicaService.sendAprobar(solicitar).subscribe(
        response => {
          loading.close();
          templateModalUsuarioAprueba.show();
          if(response.mensaje === ''){
            this.typeAlert = 'success';
            this.classEnvioAprobar = 'alert-success show';
            this.estadoEnvioAprobar = 'Enviada a aprobar.';
            this.mensajeEnvioAprobar = 'El proceso de envío a aprobación fue exitoso';
            this.detalleFicha = response.detalle
          }
          else{
            this.typeAlert = 'warning';
            this.classEnvioAprobar = 'alert-warning show';
            this.estadoEnvioAprobar = 'Error';
            this.mensajeEnvioAprobar = response.mensaje;
          }
          this.showAlert = true;
        },
        error => {
          loading.close();
          //notificar error
        }
      );
    }
  }

  public selectAprobador2(templateModal, templateModal2){
    this.btnAprobar = true;
    this.classEnvioAprobar = 'fade';
    this.estadoEnvioAprobar = '';
    this.mensajeEnvioAprobar = '';
    if(this.detalleFicha != null){
      let itemsWithoutSave = this.detalleFicha.filter(w=>w.ESTADO == 7 || w.ESTADO == 8);
      if(itemsWithoutSave.length > 0){
        this.textoModal = "Existen líneas de monto sin guardar.";
        this.tituloModal = 'Advertencia';
        this.openModal(templateModal2);
        return;
      }

      itemsWithoutSave = this.detalleFicha.filter(w=>w.ESTADO == 10);
      if(itemsWithoutSave.length <= 0){
        this.textoModal = "No existen líneas de monto para enviar a probar.";
        this.tituloModal = 'Advertencia';
        this.openModal(templateModal2);
        return;
      }
    }
    if(this.fichas.ot != null && this.fichas.ot != undefined)
    {
      this.ctrAprobadores.selectedItem = [];
      this.fichaTecnicaService.getAprobadores2(this.fichas.ot).subscribe(
        resp => {
          if(resp.mensaje == '')
          {
            this.aprobadoreItem = resp.usuarios;
            this.openModal(templateModal);
          }
          else{
            this.textoModal = "Error: "+ this.mensajes;
            this.tituloModal = 'Usuarios Aprobadores 2';
            this.openModal(templateModal);
          }
          this.btnAprobar = false;
        }
      );
    }
    else{
        this.textoModal = "No existe ot seleccionada";
        this.tituloModal = 'Error';
        this.openModal(templateModal);
    }
  }

  public preAprobar(templateModal, templateModal2) {
    //Valida las lineas de monto rechazadas
    let itemsRechazados = this.detalleFicha.filter(x => !x.CHECKED && x.ESTADO == 10);
    if(itemsRechazados != null && itemsRechazados.length>0 && this.txtObservaciones == null || this.txtObservaciones == ""){
      this.textoModal = "Existen líneas de monto rechazadas, por favor inserte una observación";
      this.tituloModal = 'Rechazados';
      this.openModal(templateModal2);
    }
    else{
      this.textoModal = "Esta seguro que desea finalizar el proceso de aprobación?";
      this.tituloModal = 'Proceso de aprobación/rechazo de la ficha';
      this.openModal(templateModal);
    }
  }

  public aprobar(templateModal){
    if(this.fichas.ot != null && this.fichas.ot != undefined)
    {
      this.detalleFicha.map(x=>{
        if(x.CHECKED && (x.ESTADO == 10 || x.ESTADO == 2)){
          x.ESTADO = 3
        }
        if(!x.CHECKED && (x.ESTADO == 10 || x.ESTADO == 2)){
          x.ESTADO = 9;
        }
      });
      templateModal.hide();
      const loading = this.lanzarLoading();
      this.fichas.observaciones = this.lblHistoricoObservaciones + '<br />' + this.txtObservaciones;
      this.fichaTecnicaService.aprobarDetalleFicha(this.fichas).subscribe(
        resp => {
          loading.close();
          templateModal.show();
          if(resp.mensaje == '')
          {
            this.fichas.detalle = resp.detalle;
            this.detalleFicha  = resp.detalle;
            this.textoModal = "Proceso de aprobacion fue realizado correctamente";
            this.tituloModal = 'Aprobado';
            this.aprobadoreItem = resp.usuarios;
            this.lblHistoricoObservaciones = resp.observaciones;
            this.txtObservaciones = "";
            //this.openModal(templateModal);
          }
          else{
            this.textoModal = "Error: "+ this.mensajes;
            this.tituloModal = 'Usuarios Aprobadores 2';
            //this.openModal(templateModal);
          }
          this.btnAprobar = false;
        }
      );
    }
    else{
        this.textoModal = "No existe ot seleccionada";
        this.tituloModal = 'Error';
        //this.openModal(templateModal);
    }
    //this.closeModal()
  }

  /*Open Modal de los errores*/
  openModalSimple(){
    //this.displayerrorshow ='block';
    const dialogo = this.modalConfirmacion(this.tituloModal,this.textoModal,'Aceptar');
    dialogo.componentInstance.confirmacionCallback.subscribe(resultado=>{
      this.aprobar(null);
      dialogo.close();
    })
 }

 /*Cierra Modal de los errores*/
 CloseModalSimple(){
    this.displayerrorshow ='none';
 }
 abrirModal(){
   this.openModalSimple()
 }

 onIndexOf( newValue : DetalleFicha ) {
    return this.detalleFicha.indexOf(newValue);
  }

  /*Metodo usado para setear los controles de seguridad*/
 setControlesSeguridad(): void {
    this.controlSeguridadService.setSeguridadControles()
            .subscribe(data=> {
              this.controlesseguridad = data;
    });
  }

  /*Metodo consumidor para traer controle  de seguridad*/
 getControlesSeguridad(): void {
    this.controlSeguridadService.getSeguridadControles(this.pathsend)
      .subscribe(controleseguridad => {
           this.listcontroleseguridad = controleseguridad;
      });
  }

  setPermisos(filter:string){
    let data = Array.of(this.listcontroleseguridad);
    var booEstado;
    data.forEach(function (value) {
        if(value != undefined){
             booEstado = value.find(function(element) {
                return element.descripcion == filter ? true : false;
            });
        }
    })
    if(booEstado===false || booEstado==undefined ) return false;
    return true;
  }

  //Ir a Calculo de fechas
  goCalcularFecha(templateModal){
    if(this.ctrOts.selectedItem == null || this.ctrOts.selectedItem == undefined || this.ctrOts.selectedItem.length <= 0)
    {
      this.mensajeNotificacion('Debe seleccionar una OT');
    }
    else
      this.router.navigate(['./Parametrizacion-fechas/'+this.ctrOts.selectedItem["ID_OT"]])
  }

  /*Retorna datos unicos segun campo proporcionado*/
  onlyUnique(arraydata : Array<any> , field:string) : any[] {
    var unique = new Array();
    var resul = new Array();

    arraydata.forEach(function (value) {
         unique.push(value[field])
    });

   var uniqueFinal = unique.filter(function(elem, index, self) {
     return index === self.indexOf(elem);
   });

   uniqueFinal.forEach(function (datos) {
       var row = arraydata.find(function(element) {
             return element[field] ==  datos;
       });
       resul.push(row);
   });
   return resul;
 }

 mensajeNotificacion(mensaje: string){
  const dialogo = this.modalConfirmacion('AVISO', mensaje, 'Aceptar',false);
  dialogo.componentInstance.confirmacionCallback.subscribe(resultado=>{
    dialogo.close();
  })
 }

 modalConfirmacion(titulo: string, mensaje: string, etiquetaConfirmacion: string, verCancelar = true){
  let data = {
    titulo: titulo,
    mensaje: mensaje,
    etiquetaConfirmacion: etiquetaConfirmacion,
    verCancelar: verCancelar
  }
  return this.dialog.open(AlertsComponent,{data: data});
}
lanzarLoading(){
  return this.dialog.open(SpinerCargandoComponent,{data: [], disableClose: true});
}

clearFiters(){
  this.accion = "";
  this.ctrCategorias.selectedItem = [];
  this.ctrCargos.selectedItem = [];
  this.ctrFacturacion.selectedItem = [];
  this.txtPresupuesto = undefined;
  this.txtCupo = "";
}

  validControls(){
    this.mostrarErrorCategoria = (this.ctrCategorias.selectedItem.length == 0)?true:false;
    this.mostrarErrorCargo = (this.ctrCargos.selectedItem.length == 0)?true:false;
    this.mostrarErrorTipoFactura = (this.ctrFacturacion.selectedItem == null || this.ctrFacturacion.selectedItem.length == 0)? true : false;
    this.mostrarErrorPresupuesto = (this.txtPresupuesto == null)?true:false;

    return (this.mostrarErrorCategoria || this.mostrarErrorCargo || this.mostrarErrorTipoFactura || this.mostrarErrorPresupuesto)?true:false;
  }

}

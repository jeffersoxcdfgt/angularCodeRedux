import { Component, OnInit ,Input ,TemplateRef , ViewChild , ElementRef ,OnChanges, SimpleChanges } from '@angular/core';
import { NgSelectModule } from '@ng-select/ng-select';
import { FormGroup, FormBuilder, Validators ,FormControl} from '@angular/forms';
import { MENUS } from '../../mocks/mock-menu';
import { Menu } from '../../class/menu';
import { MenuService } from '../../service/menu/menu.service';
import { Validation } from '../../validation/validation';
import { ValidationService } from '../../service/validation/validation.service';
import { CONTROL } from '../../mocks/mock-control';
import { Control } from '../../class/control';
import { ControlesService } from '../../service/controles/controles.service';
import { OrderPipe } from 'ngx-order-pipe';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { AuthService }  from '../../service/auth/auth.service';
import { Router,NavigationExtras } from '@angular/router';
import { Estado } from '../../class/estados';
import { MenuEstadoService } from '../../service/menu-estado/menu-estado.service';
import { MatDialog } from '@angular/material';
import { AlertsComponent } from '../../utils/alerts/alerts.component';

class OptPages {
  id: number;
  value: string;
  label : string;
  selected : string;
};

@Component({
  selector: 'app-controles-crud',
  templateUrl: './controles-crud.component.html',
  styleUrls: [
      '../../../assets/css/main.css',
       './controles-crud.component.css']
})
export class ControlesCrudComponent implements OnInit {

  menus: Menu[];
  display='none';

  idDelete:string;
  OpNameValue = 'add';
  data: Menu;
  form: FormGroup;
  selectedMenus:Menu[];
  controles:Control[];
  control:Control;
  order: string = 'id';
  reverse: boolean = true;
  combos:any[];
  public modalRef: BsModalRef;
  template: TemplateRef<any>
  mensaje_error:string;
  listEstados:Estado[] = [
    { id: '1', nombre: 'Activo' },
    { id: '2', nombre: 'Inactivo' }
  ];
   selectedEstados = [];

   selectedRangePage: OptPages[] = [
    { id: 1, value: '10'  , label:'10',   selected : 'selected' },
    { id: 2, value: '20' , label:'20',  selected : ''},
    { id: 3, value: '30' , label:'30',  selected : '' }
  ];
  perpageitem: number = 10;

  p:any;
  idx: any;
  /*Llamada a metodo de consumo de menus*/
  constructor(private formBuilder: FormBuilder,
              private menuService: MenuService,
              private controlesService: ControlesService,
              private validationService :ValidationService,
              private orderPipe: OrderPipe,
              private modalService: BsModalService,
              private authService: AuthService,
              private router: Router,
              private menuEstadoService: MenuEstadoService,
              public dialog: MatDialog) { }

  ngOnInit() {
      this.controles = this.orderPipe.transform(this.controles, 'id');
      this.setMenus();
      this.getMenus();
      this.setControles();
      this.getListControles();
      this.form = this.formBuilder.group({
          descripcion: [null, Validators.required],
          menu: [null, Validators.required],
          estado: [null, Validators.required]
      });
  }

  /*Open modal en controles*/
  public openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);
  }

  /*Lista los controles buscados*/
  searchControles(term :string):void {
    this.controlesService.searchControl(term)
    .subscribe(controles =>{
        this.controles = controles;
    });
  }

  /*Ordenar controles*/
  setOrder(value: string) {
    if (this.order === value) {
      this.reverse = !this.reverse;
    }
    this.order = value;
  }

  /*Cambia el modelo*/
  modelChanged(newValue: any){
    let id_menu = newValue as Menu;
    this.control.id_menu = id_menu.id;
  }

  getListControles():void {
    this.controlesService.getClontroles()
    .subscribe(
          controles => {
            this.controles = controles;
        });
  }

  /*Metodo usado para setear Controles*/
  setControles(): void {
   this.controlesService.setControles()
       .subscribe(control=> this.control = control);
  }

  /*Metodo accion para editar controles*/
  save( control : Control): void {
     this.control = Object.assign({},control);
     this.OpNameValue ='edit';
     this.animateScrollTop("30%");
  }

  /*Selecccion tipo de operacion*/
  /*typeOperation (objeto: any): void {
     (typeof objeto === 'string' && this.add())  || (typeof objeto === 'object' && this.save(objeto))
  }*/

  /*Metodo usado para setear Menus*/
  setMenus(): void {
   this.menuService.setMenus()
       .subscribe(data=> this.data = data);
  }

  /*Metodo consumidor para traer menus*/
  getMenus(): void {
    this.menuService.getMenus()
    .subscribe(
         menus => {
             this.menus = menus;
        });
  }

  /*Se inician metodos de validacion*/
  isFieldValid(field: string) {
  return !this.form.get(field).valid && this.form.get(field).touched;
  }

  /**Envia datos de usuarios*/
  displayFieldCss(field: string) {
  return {
    'has-error': this.isFieldValid(field),
    'has-feedback': this.isFieldValid(field)
   };
  }

  /*Envia datos*/
  onSubmit(template: TemplateRef<any>) {
    if (this.form.valid) {
      this.add(template);
    } else {
      this.validateAllFormFields(this.form);
    }
  }

  /*Valida campos de formulario*/
  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
    const control = formGroup.get(field);
    if (control instanceof FormControl) {
      control.markAsTouched({ onlySelf: true });
    } else if (control instanceof FormGroup) {
      this.validateAllFormFields(control);
    }
  });
  }

  /*Limpia formulario*/
  reset() {
    this.form.reset();
    this.OpNameValue='add';
  }

  /*Metodo abre dialogo de confirmacion de borrado*/
  openModalDelete(id:string){
      //this.display='block';
      this.idDelete=id;
      this.mensajeEliminacion('Desea borrar el registro ?');
      
  }

  /*Metodo cierra dialogo de confirmacion de borrado*/
  onCloseHandledDelete(){
       this.display='none';
  }

  /*Metodo accion para agregar o editar controles*/
  add(template: TemplateRef<any>): void {
      if(this.OpNameValue  === 'edit'){
        console.log('Inicia el control');
        console.log(this.control);
        this.controlesService.updateControl(this.control)
          .subscribe(control => {
              var index = this.controles.findIndex(obj => obj.id== control.id);
              this.controles[index] = control;
              this.mensaje_error ='Control editado satisfactoriamente.';
              this.mensajeNotificacion(this.mensaje_error);
              //this.openModal(template);
              this.form.reset();
          });
        this.OpNameValue  = 'add';
        return;
      }

      this.controlesService.addControl(this.control)
        .subscribe(control => {
          this.controles.push(control);
          this.controles = this.orderPipe.transform(this.controles, 'id');
          this.mensaje_error ='Control agregado satisfactoriamente.';
          this.mensajeNotificacion(this.mensaje_error);
          //this.openModal(template);
          this.form.reset();
      });

   }

   /*Metodo accion para borrar controles*/
    delete(id: string): void {
      this.controlesService.deleteControl( { id } as Control ).
          subscribe( control => {
            var index = this.controles.findIndex(obj => obj.id==id);
            this.controles.splice(index,1);
          });
      this.display='none';
    }

    public logout(){
      this.authService.logout();
      this.menuEstadoService.setMenuEstado(false);
      $('#totalizado').html('0');
      let redirect = this.authService.redirectUrl ? this.authService.redirectUrl : '/login';
      let navigationExtras: NavigationExtras = {
        queryParamsHandling: 'preserve',
        preserveFragment: true
      };
      // Redirect the user
      this.router.navigate([redirect], navigationExtras);
    }

    onChangePages(newValue){
      this.perpageitem = newValue;
    }

    animateScrollTop(px) {
      $('html, body').animate({
        scrollTop: px
      }, 'slow');
    }

    mensajeNotificacion(mensaje: string) {
      const dialogo = this.modalConfirmacion('AVISO', mensaje, 'Aceptar', false);
      dialogo.componentInstance.confirmacionCallback.subscribe(resultado => {
        dialogo.close();
      })
    }
  
    mensajeEliminacion(mensaje: string) {
      const dialogo = this.modalConfirmacion('AVISO', mensaje, 'Aceptar');
      dialogo.componentInstance.confirmacionCallback.subscribe(resultado => {
        this.delete(this.idDelete);
        dialogo.close();
      })
    }
  
    modalConfirmacion(titulo: string, mensaje: string, etiquetaConfirmacion: string, verCancelar = true, mData = null) {
      let data = {
        titulo: titulo,
        mensaje: mensaje,
        etiquetaConfirmacion: etiquetaConfirmacion,
        verCancelar: verCancelar,
      }
      return this.dialog.open(AlertsComponent, { data: data });
    }
}

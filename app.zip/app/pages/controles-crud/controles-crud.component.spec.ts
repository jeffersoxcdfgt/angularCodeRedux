import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ControlesCrudComponent } from './controles-crud.component';

describe('ControlesCrudComponent', () => {
  let component: ControlesCrudComponent;
  let fixture: ComponentFixture<ControlesCrudComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ControlesCrudComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ControlesCrudComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

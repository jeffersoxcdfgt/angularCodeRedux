import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PortafolioGeneralComponent } from './portafolio-general.component';

describe('PortafolioGeneralComponent', () => {
  let component: PortafolioGeneralComponent;
  let fixture: ComponentFixture<PortafolioGeneralComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PortafolioGeneralComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PortafolioGeneralComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

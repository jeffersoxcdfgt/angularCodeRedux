import { Component, OnInit, Input, Pipe, PipeTransform, ViewEncapsulation, ViewChild } from '@angular/core';
import { Location , DatePipe } from '@angular/common';
import { NgSelectModule } from '@ng-select/ng-select';
import { FormControl, FormGroup, FormBuilder, Validators, FormsModule } from '@angular/forms';
import { Portafoliogeneral } from '../../class/portafolio-general';
import { PortafolioGeneralService } from '../../service/portafolio-general/portafolio-general.service';
import { Validation } from '../../validation/validation';
import { ValidationService } from '../../service/validation/validation.service';
import { Router, NavigationExtras, ActivatedRoute } from '@angular/router';
import { AuthService } from '../../service/auth/auth.service';
import * as $ from 'jquery';
import { RESUMENCOTIZACION, FIRST } from '../../mocks/mock-resumen-cotizacion';
import { ResumenCotizacion } from '../../class/resumen-cotizacion';
import { Filtroportafolio } from '../../class/filtro-portafolio';
import { FILTROPORTAFOLIO } from '../../mocks/mock-filtro';
import { Tipocompra } from '../../class/tipocompra';
import { TIPOCOMPRA } from '../../mocks/mock-tipocompra';
import { TipocomprasService } from '../../service/tipocompras/tipocompras.service';
//import { TipocomprasAutocompleteComponent } from '../tipocompras-autocomplete/tipocompras-autocomplete.component';
import { Categoria } from '../../class/categoria';
import { CATEGORIA } from '../../mocks/mock-categoria';
import { CategoriasService } from '../../service/categorias/categorias.service';
import { Subcategoria } from '../../class/subcategoria';
import { SUBCATEGORIA } from '../../mocks/mock-subcategoria';
import { SubcategoriasService } from '../../service/subcategorias/subcategorias.service';
import { DataCategoriasService } from '../../service/data-categorias/data-categorias.service';
import { FiltroCategoria } from '../../class/filtro_categoria';
import { MenuEstadoService } from '../../service/menu-estado/menu-estado.service';
import { PgEstadoService } from '../../service/pg-estado/pg-estado.service';
import { idLocale } from 'ngx-bootstrap';

import { CONTROLESEGURIDAD } from '../../mocks/mock-control-seguridad';
import { ControlesSeguridad } from '../../class/controles_seguridad';
import { ControlSeguridadService } from '../../service/control-seguridad/control-seguridad.service';
import { getPathToSend , getOperations } from '../../utils/utils';


class OptPages {
  id: number;
  value: string;
  label: string;
  selected: string;
};

@Component({
  selector: 'app-portafolio-general',
  templateUrl: './portafolio-general.component.html',
  styleUrls: [
    '../../../assets/css/main.css',
    '../../../assets/css/simple-sidebar.css',
    '../../../assets/css/shopping-cart/style.css',
    './portafolio-general.component.css']
})

export class PortafolioGeneralComponent implements OnInit {

  private _opened: boolean = false;
  portafoliogenerales: Portafoliogeneral[];
  resumencotizacion: ResumenCotizacion;
  typeorder = 'asc';
  display = 'none';
  dataporta: Portafoliogeneral;
  filtros: Filtroportafolio;
  tiposcompras: Tipocompra[];
  selectedTipoCompras = [];
  private imagenAmpliar: string;
  private descripcionImagenAmpliar: string;
  categorias: Categoria[];
  selectedCategorias = [];
  message: string;
  subcategorias: any[];
  selectedSubCategorias: any;
  listcategorias: any;
  p: any;
  newFiltros: any[];
  combosTipoCompras: any[];
  combosCategorias: any[];
  combosSubCategorias: any[];
  totalRegistros: any;
  registroInicialPagina: any;
  registroFinalPagina: any;
  public idUrl: string;
  toggleFilter: any;
  hiddenFilter: boolean;
  selectedRangePage: OptPages[] = [
    { id: 1, value: '30', label: '30', selected: 'selected' },
    { id: 2, value: '50', label: '50', selected: '' },
    { id: 3, value: '100', label: '100', selected: '' }
  ];
  perpageitem: number = 30;

  //Security variables
  pathsend :string;
  controlesseguridad : ControlesSeguridad;
  listcontroleseguridad :ControlesSeguridad[];
  //Security variables

  constructor(private portafolioGeneralService: PortafolioGeneralService,
    private validationService: ValidationService,
    private authService: AuthService,
    private router: Router,
    private tipocomprasService: TipocomprasService,
    private categoriasService: CategoriasService,
    private subcategoriasService: SubcategoriasService,
    private data: DataCategoriasService,
    private menuEstadoService: MenuEstadoService,
    private pgEstadoService: PgEstadoService,
    private route: ActivatedRoute,
    private controlSeguridadService :ControlSeguridadService,
    private location: Location
  ) {
    this.pathsend=getPathToSend(router.parseUrl(location.path()));
    this.dataporta = new Portafoliogeneral;
    this.idUrl = this.route.snapshot.paramMap.get('id');
  }

  ngOnInit() {
    $("#menu-toggle").click(function (e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });

    if (!this.pgEstadoService.getMenuPg() && !this.pgEstadoService.getMenuPgFilters()) {

      /*if(this.idUrl.includes('-')){
        this.idUrl = this.idUrl.replace(/-/gi, ' ');
      }*/
      if (this.idUrl && this.idUrl.includes('-')) {
      //if (this.idUrl) {
        let valor = this.idUrl.replace(/-/gi, ' ');//this.idUrl;
        valor = (valor.includes('&'))?valor.replace(/&/gi, '_'):valor;
        console.log("entro a go to market", valor);
        this.portafolioGeneralService.getFiltroPortafolio(null, null, null, valor.toString())
          .subscribe(portafoliogenerales => {
            this.portafoliogenerales = portafoliogenerales;
            this.totalRegistros = this.portafoliogenerales.length;
            this.p = 1;
          });
      }
      if (!this.idUrl) {
        this.getPortafoliogeneral();
      }


      this.getNewFilters();
      /* this.pgEstadoService.setMenuPg(true);
      this.pgEstadoService.setMenuPgFilters(true); */

    }
    else {
      this.portafoliogenerales = this.pgEstadoService.getListPg();
      this.newFiltros = this.pgEstadoService.getListPgFilters();
      this.setFiltros();
      this.pgEstadoService.setMenuPg(false);
      this.pgEstadoService.setMenuPgFilters(false);
    }
    this.p = 1;
    this.perpageitem = 30;

    this.setControlesSeguridad();
    this.getControlesSeguridad();
  }

  /*Metodo usado para setear los controles de seguridad*/
  setControlesSeguridad(): void {
     this.controlSeguridadService.setSeguridadControles()
        .subscribe(data=> {
         this.controlesseguridad = data;
     });
  }

  /*Metodo consumidor para traer controles  de seguridad*/
  getControlesSeguridad(): void {
    this.controlSeguridadService.getSeguridadControles(this.pathsend)
        .subscribe(controleseguridad => {
        this.listcontroleseguridad = controleseguridad;
      });
  }

  setPermisos(filter:string){
      let data = Array.of(this.listcontroleseguridad);
      var booEstado;
      data.forEach(function (value) {
          if(value != undefined){
               booEstado = value.find(function(element) {
                  return element.descripcion == filter ? true : false;
              });
          }
      })
      if(booEstado===false || booEstado==undefined ) return false;
      return true;
  }

  //Setea filtros
  setFiltros() {
    this.selectedTipoCompras = [];
    this.selectedCategorias = [];
    this.selectedSubCategorias = [];

    this.combosTipoCompras = this.onlyUnique(this.newFiltros, 'TIPO');
    this.combosCategorias = this.onlyUnique(this.newFiltros, 'GRUPO');
    this.combosSubCategorias = this.onlyUnique(this.newFiltros, 'SUB_GRUPO');
    //this.pgEstadoService.setMenuPgFilters(true);

    if (this.idUrl && (!this.idUrl.includes('-'))) {
      this.pgEstadoService.setMenuPgFilters(true);
      this.selectedTipoCompras = this.combosTipoCompras.filter(tipo => tipo.ID === this.idUrl);
      this.getNewTiposCompras();
      this.FiltroPortafolio();
    }
  }

  /*Nueva tabla de filtros*/
  getNewFilters(): void {
    this.portafolioGeneralService.getNewFilters()
      .subscribe(filtros => {
        this.newFiltros = filtros;
        this.pgEstadoService.setListPgFilters(filtros);
        this.setFiltros();
      });
  }

  /*Filtrado Modifica las categorias en el filtro , segun los tipos de compras seleccionados*/
  getNewTiposCompras(): void {
    this.selectedCategorias = this.newFiltros.filter(o => !!this.selectedTipoCompras.find(x => x.TIPO == o.TIPO));
  }

  /*Filtrado Modifica las subcategorias en el filtro , segun las categorias seleccionados*/
  getNewCategorias(): void {
    this.selectedSubCategorias = this.newFiltros.filter(o => !!this.selectedCategorias.find(x => x.GRUPO == o.GRUPO));
  }


  /*Retorna datos unicos segun campo proporcionado*/
  onlyUnique(arraydata: Array<any>, field: string): any[] {
    var unique = new Array();
    var resul = new Array();

    arraydata.forEach(function (value) {
      unique.push(value[field])
    });

    var uniqueFinal = unique.filter(function (elem, index, self) {
      return index === self.indexOf(elem);
    });

    uniqueFinal.forEach(function (datos) {
      var row = arraydata.find(function (element) {
        return element[field] == datos;
      });
      resul.push(row);
    });
    return resul;
  }

  /*Este metodo obtiene dinamicamente la descripcion y la imagen del producto seleccionado*/
  getImagenDescripcionProducto(portafoliogeneral: Portafoliogeneral): void {
    this.imagenAmpliar = portafoliogeneral.imagen;
    this.descripcionImagenAmpliar = portafoliogeneral.descripcion_corta;
  }

  /**Selcciones categorias*/
  setCategorias() {
    console.log('setCategorias()');
    this.subcategoriasService.getSubcategoria(this.selectedCategorias as FiltroCategoria[])
      .subscribe(subcategorias => {
        this.subcategorias = subcategorias;
        //console.log(this.subcategorias );
        this.selectedSubCategorias = this.subcategorias
      });
  }

  /*Metodo consumidor trae las categorias*/
  getCategorias(): void {
    this.categoriasService.getCategorias()
      .subscribe(categorias => {
        this.categorias = categorias;
      });
  }

  /*Metodo consumidor trae los tipos de compras*/
  getTipoCompras(): void {
    this.tipocomprasService.getTipoCompras()
      .subscribe(tiposcompras => {
        this.tiposcompras = tiposcompras;
      });
  }

  /*Configura filtros*/
  setFiltrosPortafolios(): void {
    this.portafolioGeneralService.setFiltrosPortafolios()
      .subscribe(filtros => {
        this.filtros = filtros
      });
  }

  /*Llamda de filtros*/
  FiltroPortafolio() {
    this.selectedTipoCompras.forEach(function (value) {
      FILTROPORTAFOLIO[FIRST].id_tipocompra += value.TIPO + ',';
    })

    this.selectedCategorias.forEach(function (value) {
      console.log(value);
      FILTROPORTAFOLIO[FIRST].id_categoria += value.GRUPO + ',';
    })

    this.selectedSubCategorias.forEach(function (value) {
      console.log(value);
      FILTROPORTAFOLIO[FIRST].id_subcategoria += value.SUB_GRUPO + ',';
    })

    console.log(FILTROPORTAFOLIO[FIRST].id_categoria);

    let id_tipocompra = FILTROPORTAFOLIO[FIRST].id_tipocompra;
    let id_categoria = FILTROPORTAFOLIO[FIRST].id_categoria;
    let id_subcategoria = FILTROPORTAFOLIO[FIRST].id_subcategoria;

    //this.portafolioGeneralService.getFiltroPortafolio(id_tipocompra, id_categoria, id_subcategoria, this.route.snapshot.paramMap.get('id'))
    this.portafolioGeneralService.getFiltroPortafolio(id_tipocompra, id_categoria, id_subcategoria, null)
      .subscribe(portafoliogenerales => {
        this.portafoliogenerales = portafoliogenerales;
        this.totalRegistros = this.portafoliogenerales.length;
        this.p = 1;

      });

    FILTROPORTAFOLIO[FIRST].id_tipocompra = "";
    FILTROPORTAFOLIO[FIRST].id_categoria = "";
    FILTROPORTAFOLIO[FIRST].id_subcategoria = "";
  }

  ResetFiltroPortafolio() {
    this.getPortafoliogeneral();
  }


  /*Metodo consumidor para traer portafolios generales*/
  getPortafoliogeneral(): void {
    this.portafolioGeneralService.getPortafoliogeneral()
      .subscribe(portafoliogenerales => {
        this.portafoliogenerales = portafoliogenerales;
        this.selectedTipoCompras = [];
        this.selectedCategorias = [];
        this.selectedSubCategorias = [];
        this.pgEstadoService.setListPg(portafoliogenerales);
        this.totalRegistros = this.portafoliogenerales.length;

      });
  }

  getTipoCompraList(): void {
    console.log('getTipoCompraList');
  }

  /*Addd element to shopping car*/
  addShoppingCar(idpro: string, portafoliogeneral: Portafoliogeneral) {
    if (!this.ifProductExist(portafoliogeneral)) {
      RESUMENCOTIZACION[FIRST].detalle.push(
        {
          'ID_ARTICULO': portafoliogeneral.id_articulo,
          'grupo': portafoliogeneral.grupo,
          'DESCRIPCION_CATEGORIA': portafoliogeneral.descripcion_categoria,
          'subgrupo': portafoliogeneral.subgrupo,
          'id': '',
          'id_segmento_3': portafoliogeneral.id_segmento_3,
          'ID_ORACLE': portafoliogeneral.id_oracle,
          'DES_ART_ORACLE': portafoliogeneral.des_art_oracle,
          'PRECIO_GLOBAL': portafoliogeneral.precio_global,
          'categoria_inv': portafoliogeneral.categoria_inv,
          'tipo': portafoliogeneral.tipo,
          'sexo': portafoliogeneral.sexo,
          'talla': portafoliogeneral.talla,
          'DESCRIPCION_CORTA': portafoliogeneral.descripcion_corta,
          'cuenta_costo_ext': portafoliogeneral.cuenta_costo_ext,
          'cuenta_costo_efi': portafoliogeneral.cuenta_costo_efi,
          'cuenta_costo_eym': portafoliogeneral.cuenta_costo_eym,
          'cuenta_costo_eze': portafoliogeneral.cuenta_costo_eze,
          'color': portafoliogeneral.color,
          'PRECION_VENTA': portafoliogeneral.precio_venta,
          'TIEMPO': portafoliogeneral.tiempo,
          'imagen': portafoliogeneral.imagen,
          'CANTIDAD': '1',
          'estado': '',
          'id_articulo_cambio': '',
          'id_articulo_nuevo': '',
          'observaciones': '',
          'id_cotizacion': '',
          'id_empresa': '',
          'id_usuario_modifica': '',
          'SUBTOTAL_VENTA_COT': portafoliogeneral.precio_venta,
          'SUBTOTAL_COSTO': portafoliogeneral.precio_global,
          'id_usuario_aprueba': '',
          'aprobacion': '',
          'cantidad_x_persona': '',
          'fecha_entrega': '',
          'TOTAL': '',
          'PORCENTAJE': portafoliogeneral.porcentaje_iva,
          'envio_aprobacion': '',
          'idfacturable': [],
          'idFrecuencia': [],
          'id_ciudad': [],
          'id_cargo': [],
          'cupos_aprobados': [],
          'ciudadesxcargo': []
        });
    }
    var datatotal = this.totalProductos();
    var offset = $('#' + idpro).parent().offset();
    $('#' + idpro).parent().clone().addClass('product-clone').css({
      'left': offset.left + 'px',
      'top': offset.top - $(window).scrollTop() + 'px',
      'width': $('#' + idpro).parent().width() + 'px',
      'height': $('#' + idpro).parent().height() + 'px'
    }).appendTo($('.product').parent());

    var cart = $('nav .navbar-right strong').offset();
    $('.product-clone').animate({ top: (cart.top - $(window).scrollTop()) + 'px', left: cart.left + 'px', 'height': '0px', 'width': '0px' }, 800, function () {
      $(this).remove();
      var price = parseInt($('nav .navbar-right').attr('data-price'));
      var productPrice = parseInt($(this).attr('data-price'));
      var cartPrice = (price + productPrice);
      $('nav .navbar-right strong').html('' + datatotal);
      $('nav .navbar-right').attr('data-price', datatotal);
    })
  }

  totalProductos(): string {
    let datos = RESUMENCOTIZACION[FIRST].detalle;
    let total = 0;

    datos.forEach(function (value) {
      total += Number(value.CANTIDAD);
    })
    console.log(total);
    return total.toString();
  }

  ifProductExist(portafoliogeneral: Portafoliogeneral): boolean {
    for (let i = 0; i < RESUMENCOTIZACION[FIRST].detalle.length; i++) {
      if (RESUMENCOTIZACION[FIRST].detalle[i].ID_ARTICULO == portafoliogeneral.id_articulo) {
        RESUMENCOTIZACION[FIRST].detalle[i].CANTIDAD = (parseFloat(RESUMENCOTIZACION[FIRST].detalle[i].CANTIDAD) + 1).toString();
        RESUMENCOTIZACION[FIRST].detalle[i].SUBTOTAL_VENTA_COT = (parseFloat(RESUMENCOTIZACION[FIRST].detalle[i].CANTIDAD) * parseFloat(RESUMENCOTIZACION[FIRST].detalle[i].PRECION_VENTA)).toString();
        RESUMENCOTIZACION[FIRST].detalle[i].SUBTOTAL_COSTO = (parseFloat(RESUMENCOTIZACION[FIRST].detalle[i].CANTIDAD) * parseFloat(RESUMENCOTIZACION[FIRST].detalle[i].PRECIO_GLOBAL)).toString();
        return true;
      }
    }
  }

  /*Order by  A-Z*/
  OrderByProductAZ() {
    if (this.typeorder == 'asc') {
      this.typeorder = 'des';
      this.portafoliogenerales.sort(function (obj1, obj2) {
        // Ascending:
          return obj1.descripcion_corta == null ?  ''.localeCompare(obj2.descripcion_corta == null ? '': obj2.descripcion_corta) : obj1.descripcion_corta.localeCompare(obj2.descripcion_corta == null ? '': obj2.descripcion_corta);
      });
    }
    else if (this.typeorder == 'des') {
      // Descending:
      this.ArrayReverse();
    }

  }
  /*Order by Price*/
  OrderByProductPrecio() {
    if (this.typeorder == 'asc') {
      this.typeorder = 'des';
      this.portafoliogenerales.sort(function (obj1, obj2) {
        // Ascending:
        return parseFloat(obj1.precio_venta) - parseFloat(obj2.precio_venta);
      });
    }
    else if (this.typeorder == 'des') {
      // Descending:
      this.ArrayReverse();
    }
  }

  /*Order by Time*/
  OrderByProductTime() {
    if (this.typeorder == 'asc') {
      this.typeorder = 'des';
      this.portafoliogenerales.sort(function (obj1, obj2) {
        // Ascending:
        return parseFloat(obj1.tiempo) - parseFloat(obj2.tiempo);
      });
    }
    else if (this.typeorder == 'des') {
      // Descending:
      this.ArrayReverse();
    }
  }

  //Reversiin array
  ArrayReverse() {
    this.portafoliogenerales.reverse();
    this.typeorder = 'asc';
  }

  //Open side bar
  private _toggleSidebar() {
    this._opened = !this._opened;
  }

  public logout() {
    this.authService.logout();
    this.menuEstadoService.setMenuEstado(false);
    this.authService.KillToken()
      .subscribe(tokens => { }
      );
    $('#totalizado').html('0');
    let redirect = this.authService.redirectUrl ? this.authService.redirectUrl : '/login';
    let navigationExtras: NavigationExtras = {
      queryParamsHandling: 'preserve',
      preserveFragment: true
    };
    // Redirect the user
    this.router.navigate([redirect], navigationExtras);
  }

  ngAfterViewInit() {
    $(document).ready(function () {
      $("#navmainmenu").show();
    });
  }

  /*Metodo abre dialogo*/
  openModalDelete(portafoliogeneral: Portafoliogeneral) {
    this.dataporta = portafoliogeneral;
    this.display = 'block';
  }

  /*Metodo cierra dialogo*/
  onCloseHandledDelete() {
    this.display = 'none';
  }

  /*Mueve paginador*/
  onChangePages(newValue) {
    this.perpageitem = newValue;
  }

  hideFiltros() { this.hiddenFilter === true ? this.hiddenFilter = false : this.hiddenFilter = true; }
}

import {
  Component,
  OnInit,
  TemplateRef,
  ContentChild,
  ContentChildren,
  QueryList,
  ViewChild,
} from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { LoginComponent } from '../../login/login.component';

const colaboradores = [
  { src: 'assets/images/Home/RECURSOS_PARA_COLABORADORES/Recurso.jpg', alt: 'aaa' },
  { src: 'assets/images/Home/RECURSOS_PARA_COLABORADORES/Dotacion_bodega.jpg', alt: 'aaa' },
  { src: 'assets/images/Home/RECURSOS_PARA_COLABORADORES/Recurso_7.jpg', alt: 'aaa' },
  { src: 'assets/images/Home/RECURSOS_PARA_COLABORADORES/Hombre_Overol.jpg', alt: 'aaa' },
  { src: 'assets/images/Home/RECURSOS_PARA_COLABORADORES/Dotaicion_en_punto_venta.jpg', alt: 'aaa' }
];

const incentivos = [
  { src: 'assets/images/Home/INCENTIVOS/CumplimientoMetas.jpg', alt: 'aaa' },
  { src: 'assets/images/Home/INCENTIVOS/Pago.jpg', alt: 'aaa' }
];

const servicios = [
  { src: 'assets/images/Home/SERVICIOS_ADMINSITRATIVOS/Portal.jpg', alt: 'aaa' },
  { src: 'assets/images/Home/SERVICIOS_ADMINSITRATIVOS/calculadora.jpg', alt: 'aaa' },
  { src: 'assets/images/Home/SERVICIOS_ADMINSITRATIVOS/compras_estadistica.jpg', alt: 'aaa' }
];

const logistica = [
  { src: 'assets/images/Home/LOGISTICA_EVENTOS/Gastos_Viaje3.jpg', alt: 'aaa' },
  { src: 'assets/images/Home/LOGISTICA_EVENTOS/Alquiler_salon.jpg', alt: 'aaa' },
  { src: 'assets/images/Home/LOGISTICA_EVENTOS/Refrigerios_Eventos2.jpg', alt: 'aaa' },
  { src: 'assets/images/Home/LOGISTICA_EVENTOS/Alquiler_Salon1.jpg', alt: 'aaa' },
  { src: 'assets/images/Home/LOGISTICA_EVENTOS/Refrigerios3.jpg', alt: 'aaa' },
  { src: 'assets/images/Home/LOGISTICA_EVENTOS/Video_Bean.jpg', alt: 'aaa' },
  { src: 'assets/images/Home/LOGISTICA_EVENTOS/Gastos_Viaje.jpg', alt: 'aaa' },
  { src: 'assets/images/Home/LOGISTICA_EVENTOS/Refrigerios_Eventos.jpg', alt: 'aaa' },
  { src: 'assets/images/Home/LOGISTICA_EVENTOS/Gastos_Viaje2.jpg', alt: 'aaa' },
]

const iconos = [
  {icono: 'glyphicon-time' , titulo: 'MIS ACTIVIDADES'},
  {icono: 'glyphicon-align-justify' , titulo: 'COMO VA TU PEDIDO'},
  {icono: 'glyphicon-usd' , titulo: 'COTIZACIONES'},
  {icono: 'glyphicon-calendar' , titulo: 'PLANEADOR'},
  {icono: 'glyphicon-gift' , titulo: 'KIT POR UNIDAD DE NEGOCIO'},
]

const footer = [
  {src: 'assets/images/Home/KITS/imagen1.jpg' ,titulo:'RETAIL', texto: 'Este es un texto de prueba, para ver como se comporta, determinar si  así se ve bien o se debe hacer algo adicional, además la leyenda que debería ir no se ha definido del todo.', href: '', param: 'RETAIL-'},
  {src: 'assets/images/Home/KITS/imagen2.jpg' ,titulo:'G2M', texto: 'Este es un texto de prueba, para ver como se comporta, determinar si  así se ve bien o se debe hacer algo adicional, además la leyenda que debería ir no se ha definido del todo.', href: '', param: 'GO-TO-MARKET'},
  {src: 'assets/images/Home/KITS/imagen3.jpg' ,titulo:'T&S', texto: 'Este es un texto de prueba, para ver como se comporta, determinar si  así se ve bien o se debe hacer algo adicional, además la leyenda que debería ir no se ha definido del todo.', href: '', param: 'TALENTO-&-SOLUCIONES'},
]


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})

export class HomeComponent implements OnInit {
  @ContentChild('last') lastChild: LoginComponent;
  @ViewChild(LoginComponent) child;

  constructor() { }

  colaboradores = colaboradores;
  incentivos = incentivos;
  servicios = servicios;
  logistica = logistica; 
  iconos = iconos;
  footer = footer; 

  ngOnInit() {
  }

  ngAfterViewInit() {
    $(document).ready(function () {
      $("#navmainmenu").show();
    });
  }

}

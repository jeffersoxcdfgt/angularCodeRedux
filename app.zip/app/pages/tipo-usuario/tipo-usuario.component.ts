import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators ,FormControl} from '@angular/forms';
import { Tipousuario } from '../../class/tipo-usuario';
import { TipoUsuarioService } from '../../service/tipo-usuario/tipo-usuario.service';
import { Validation } from '../../validation/validation';
import { ValidationService } from '../../service/validation/validation.service';
import { AlertsComponent } from '../../utils/alerts/alerts.component';
import { MatDialog } from '@angular/material';

@Component({
  selector: 'app-tipo-usuario',
  templateUrl: './tipo-usuario.component.html',
  styleUrls: [
          '../../../assets/css/main.css',
          './tipo-usuario.component.css']
})
export class TipoUsuarioComponent implements OnInit {

  tipousuarios: Tipousuario[];
  display='none';
  idDelete:string;
  OpNameValue = 'add';
  data: Tipousuario;
  form: FormGroup;
  p:any;

  constructor(private formBuilder: FormBuilder,
              private tipoUsuarioService: TipoUsuarioService,
              private validationService :ValidationService,
              public dialog: MatDialog) { }

  ngOnInit() {
    this.setTipousuarios();
    this.getTipousuarios();
    this.form = this.formBuilder.group({
      grupo: this.formBuilder.group({
        tipousuario: [null, Validators.required]
      })
    });
  }

  /*Metodo usado para setear tipousuario*/
  setTipousuarios(): void {
   this.tipoUsuarioService.setTipousuarios()
       .subscribe(data=> this.data = data);
  }

  /*Metodo consumidor para traer tipousuarios*/
  getTipousuarios(): void {
    this.tipoUsuarioService.getTipousuarios()
    .subscribe(tipousuarios => this.tipousuarios = tipousuarios);
  }

  /*Metodo accion para agregar tipousuarios*/
  add(): void {
      this.onSubmit();
      this.tipoUsuarioService.addTipousuario(this.data)
        .subscribe(tipousuario => {
            var index = this.tipousuarios.findIndex(obj => obj.id==this.data.id);
            (this.OpNameValue  === 'add' && this.tipousuarios.push(tipousuario))  || ( this.OpNameValue  === 'edit' && (this.tipousuarios[index] = tipousuario));
             this.OpNameValue='add';
      });
  }

  /*Metodo accion para borrar tipousuario*/
   delete(id: string): void {
     this.tipoUsuarioService.deleteTipousuario( { id } as Tipousuario ).
         subscribe( tipousuario => {
           var index = this.tipousuarios.findIndex(obj => obj.id==id);
           this.tipousuarios.splice(index,1);
         });
     this.display='none';
   }

   /*Metodo accion para editar tipousuarios*/
   save( tipousuario : Tipousuario): void {
      this.data = tipousuario;
      this.OpNameValue ='edit';
   }

   /*Metodo abre dialogo de confirmacion de borrado*/
   openModalDelete(id:string){
       //this.display='block';
       this.idDelete=id;
       this.mensajeEliminacion('Desea borrar el registro ?');
   }

   /*Metodo cierra dialogo de confirmacion de borrado*/
   onCloseHandledDelete(){
        this.display='none';
   }

   /*Selecccion tipo de operacion*/
   typeOperation (objeto: any): void {
      (typeof objeto === 'string' && this.add())  || (typeof objeto === 'object' && this.save(objeto))
   }

    //Limpia elementos del array
  clearData()  {
       for (let key of Object.keys(this.data)) {
         eval(  "this.data." +key+"=''");
       }
  }

  /*Se inician metodos de validacion*/
  isFieldValid(field: string) {
  return !this.form.get(field).valid && this.form.get(field).touched;
  }

  /**Envia datos de usuarios*/
  displayFieldCss(field: string) {
  return {
    'has-error': this.isFieldValid(field),
    'has-feedback': this.isFieldValid(field)
   };
  }

  /*Envia datos*/
  onSubmit() {
    console.log(this.form);
    if (this.form.valid) {
      console.log('form submitted');
    } else {
      this.validateAllFormFields(this.form);
    }
  }

  /*Valida campos de formulario*/
  validateAllFormFields(formGroup: FormGroup) {
  Object.keys(formGroup.controls).forEach(field => {
    console.log(field);
    const control = formGroup.get(field);
    if (control instanceof FormControl) {
      control.markAsTouched({ onlySelf: true });
    } else if (control instanceof FormGroup) {
      this.validateAllFormFields(control);
    }
  });
  }

  /*Limpia formulario*/
  reset() {
    this.form.reset();
  }

  mensajeNotificacion(mensaje: string) {
    const dialogo = this.modalConfirmacion('AVISO', mensaje, 'Aceptar', false);
    dialogo.componentInstance.confirmacionCallback.subscribe(resultado => {
      dialogo.close();
    })
  }

  mensajeEliminacion(mensaje: string) {
    const dialogo = this.modalConfirmacion('AVISO', mensaje, 'Aceptar');
    dialogo.componentInstance.confirmacionCallback.subscribe(resultado => {
      this.delete(this.idDelete);
      dialogo.close();
    })
  }

  modalConfirmacion(titulo: string, mensaje: string, etiquetaConfirmacion: string, verCancelar = true) {
    let data = {
      titulo: titulo,
      mensaje: mensaje,
      etiquetaConfirmacion: etiquetaConfirmacion,
      verCancelar: verCancelar,
    }
    return this.dialog.open(AlertsComponent, { data: data });
  }
}

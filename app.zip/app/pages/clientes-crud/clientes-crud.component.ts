import { Component, OnInit, Input, TemplateRef, ViewChild, ElementRef, OnChanges, SimpleChanges } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl, FormArray, AbstractControl } from '@angular/forms';
import { CLIENTE } from '../../mocks/mock-cliente';
import { Cliente } from '../../class/cliente';
import { ClienteService } from '../../service/cliente/cliente.service';
import { Validation } from '../../validation/validation';
import { ValidationService } from '../../service/validation/validation.service';
import { OrderPipe } from 'ngx-order-pipe';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { AuthService } from '../../service/auth/auth.service';
import { Router, NavigationExtras } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';
import { MenuEstadoService } from '../../service/menu-estado/menu-estado.service';
import { MatDialog } from '@angular/material';
import { AlertsComponent } from '../../utils/alerts/alerts.component';

@Component({
  selector: 'app-clientes-crud',
  templateUrl: './clientes-crud.component.html',
  styleUrls: ['../../../assets/css/main.css',
    './clientes-crud.component.css']
})

export class ClientesCrudComponent implements OnInit {
  clientes: Cliente[];
  display = 'none';
  idDelete: string;
  OpNameValue = 'add';
  data: Cliente;
  form: FormGroup;
  public modalRef: BsModalRef;
  template: TemplateRef<any>
  mensaje_error: string;
  order: string = 'id';
  reverse: boolean = true;
  p: any;

  constructor(private formBuilder: FormBuilder,
    private clienteService: ClienteService,
    private validationService: ValidationService,
    private orderPipe: OrderPipe,
    private modalService: BsModalService,
    private authService: AuthService,
    private router: Router,
    private menuEstadoService: MenuEstadoService,
    public dialog: MatDialog) { }

  /*Llamada a metodo de consumo de clientes*/
  ngOnInit() {
    this.clientes = this.orderPipe.transform(this.clientes, 'id');
    this.setClientes();
    this.getClientes();
    this.form = this.formBuilder.group({
      nombrecliente: [null, Validators.required, this.validSpaceBlank],
      datosusuarios: this.formBuilder.group({
        direccion: [null, Validators.required, this.validSpaceBlank],
        nit: [null, Validators.required, this.validSpaceBlank]
      })
    });
  }

  //Valida no permite espacios en blanco
  validSpaceBlank(control: AbstractControl) {
    var pattern = /^\s+$/;
    return Observable.of(pattern.test(control.value)).pipe(
      map(result => result ? { invalid: true } : null)
    );
  }

  /*Open modal en clientes*/
  public openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);
  }

  /*Lista los controles buscados*/
  searchClientes(term: string): void {
    this.clienteService.searchCliente(term)
      .subscribe(clientes => {
        this.clientes = clientes;
      });
  }

  /*Metodo usado para setear clientes*/
  setClientes(): void {
    this.clienteService.setClientes()
      .subscribe(data => this.data = data);
  }

  /*Metodo consumidor para traer clientes*/
  getClientes(): void {
    this.clienteService.getClientes()
      .subscribe(clientes => {
        this.clientes = clientes;
      });
  }

  /*Metodo accion para agregar clientes*/
  add(template: TemplateRef<any>): void {
    if (this.OpNameValue === 'edit') {
      this.clienteService.updateCliente(this.data)
        .subscribe(cliente => {
          var index = this.clientes.findIndex(obj => obj.id == cliente.id);
          this.clientes[index] = cliente;
          this.mensaje_error = 'Cliente editado satisfactoriamente.';
          //this.openModal(template);
          this.mensajeNotificacion(this.mensaje_error);
          this.form.reset();
        });
      this.OpNameValue = 'add';
      return;
    }

    this.clienteService.addCliente(this.data)
      .subscribe(cliente => {
        if (cliente.mensaje !== "") {
          this.mensaje_error = cliente.mensaje;
          this.mensajeNotificacion(this.mensaje_error);
          //this.openModal(template);
          return;
        }
        this.clientes.push(cliente);
        this.clientes = this.orderPipe.transform(this.clientes, 'id');
        this.mensaje_error = 'Cliente agregado satisfactoriamente.';
        this.mensajeNotificacion(this.mensaje_error);
        //this.openModal(template);
        this.form.reset();
      });
  }

  /*Metodo accion para borrar clientes*/
  delete(id: string): void {
    this.clienteService.deleteCliente({ id } as Cliente).
      subscribe(cliente => {
        var index = this.clientes.findIndex(obj => obj.id == id);
        this.clientes.splice(index, 1);
      });
    this.display = 'none';
  }

  /*Metodo accion para editar clientes*/
  save(cliente: Cliente): void {
    this.data = Object.assign({}, cliente);
    this.OpNameValue = 'edit';
  }

  /*Metodo abre dialogo de confirmacion de borrado*/
  openModalDelete(id: string) {
    //this.display='block';
    this.idDelete = id;
    this.mensajeEliminacion('Desea borrar el registro ?');
  }

  /*Metodo cierra dialogo de confirmacion de borrado*/
  onCloseHandledDelete() {
    this.display = 'none';
  }

  /*Selecccion tipo de operacion*/
  /*typeOperation (objeto: any): void {
     (typeof objeto === 'string' && this.add())  || (typeof objeto === 'object' && this.save(objeto))
  }*/

  //Limpia elementos del array
  clearData() {
    for (let key of Object.keys(this.data)) {
      eval("this.data." + key + "=''");
    }
  }

  /*Se inician metodos de validacion*/
  isFieldValid(field: string) {
    return !this.form.get(field).valid && this.form.get(field).touched;
  }

  /**Envia datos de usuarios*/
  displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
    };
  }

  /*Envia datos*/
  onSubmit(template: TemplateRef<any>) {
    if (this.form.valid) {
      this.add(template);
    } else {
      this.validateAllFormFields(this.form);
    }
  }

  /*Valida campos de formulario*/
  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  /*Limpia formulario*/
  reset() {
    this.form.reset();
    this.OpNameValue = 'add';
  }

  public logout() {
    this.authService.logout();
    this.menuEstadoService.setMenuEstado(false);
    $('#totalizado').html('0');
    let redirect = this.authService.redirectUrl ? this.authService.redirectUrl : '/login';
    let navigationExtras: NavigationExtras = {
      queryParamsHandling: 'preserve',
      preserveFragment: true
    };
    // Redirect the user
    this.router.navigate([redirect], navigationExtras);
  }

  mensajeNotificacion(mensaje: string) {
    const dialogo = this.modalConfirmacion('AVISO', mensaje, 'Aceptar', false);
    dialogo.componentInstance.confirmacionCallback.subscribe(resultado => {
      dialogo.close();
    })
  }

  mensajeEliminacion(mensaje: string) {
    const dialogo = this.modalConfirmacion('AVISO', mensaje, 'Aceptar');
    dialogo.componentInstance.confirmacionCallback.subscribe(resultado => {
      this.delete(this.idDelete);
      dialogo.close();
    })
  }

  modalConfirmacion(titulo: string, mensaje: string, etiquetaConfirmacion: string, verCancelar = true, mData = null) {
    let data = {
      titulo: titulo,
      mensaje: mensaje,
      etiquetaConfirmacion: etiquetaConfirmacion,
      verCancelar: verCancelar,
    }
    return this.dialog.open(AlertsComponent, { data: data });
  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ParametrizacionFechasComponent } from './parametrizacion-fechas.component';

describe('ParametrizacionFechasComponent', () => {
  let component: ParametrizacionFechasComponent;
  let fixture: ComponentFixture<ParametrizacionFechasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ParametrizacionFechasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ParametrizacionFechasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit , TemplateRef ,  OnChanges, SimpleChanges, SimpleChange , Input} from '@angular/core';
import { FormGroup, FormBuilder, Validators ,FormControl ,FormArray , AbstractControl } from '@angular/forms';
import { Location , DatePipe } from '@angular/common';
import { AuthService }  from '../../service/auth/auth.service';
import { Router,NavigationExtras, ActivatedRoute } from '@angular/router';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';
import { ParametrizacionFechas , FechasType } from '../../class/parametrizacion-fechas';
import { PARAMETRIZACIONFECHAS , FIRSTPARAMETRIZACION } from '../../mocks/mock-parametrizacion-fechas';
import { ParametrizacionFechasService }  from '../../service/parametrizacion-fechas/parametrizacion-fechas.service';
import { AlertasMails} from '../../class/alertasmails';
import { ListFicha  } from '../../class/listficha';
import { LISTFICHA  } from '../../mocks/mock-listficha';
import * as $ from 'jquery';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { FechasPlaneadas  } from '../../class/fechas_planeadas';
import { FECHASPLANEADAS  } from '../../mocks/mock-fechas-planeadas';
import { MenuEstadoService } from '../../service/menu-estado/menu-estado.service';
import { FichaTecnicaService } from '../../service/ficha-tecnica/ficha-tecnica.service';
import { Platform } from '@angular/cdk/platform';
import { DateTimeAdapter, OWL_DATE_TIME_LOCALE, OwlDateTimeIntl } from 'ng-pick-datetime';
import { NativeDateTimeAdapter } from 'ng-pick-datetime/date-time/adapter/native-date-time-adapter.class';
import { AlertsComponent } from '../../utils/alerts/alerts.component';
import { MatDialog } from '@angular/material';

import { CONTROLESEGURIDAD } from '../../mocks/mock-control-seguridad';
import { ControlesSeguridad } from '../../class/controles_seguridad';
import { ControlSeguridadService } from '../../service/control-seguridad/control-seguridad.service';
import { getPathToSend , getOperations } from '../../utils/utils';

import {
    OWL_DATE_TIME_FORMATS,
    OwlDateTimeComponent,
    OwlDateTimeFormats
} from 'ng-pick-datetime';
import * as _moment from 'moment';
import { Moment } from 'moment';
const moment = (_moment as any).default ? (_moment as any).default : _moment;

// here is the default text string
export class SpanishIntl extends OwlDateTimeIntl {
    /** A label for the up second button (used by screen readers).  */
    upSecondLabel = 'agrega un segundo';

    /** A label for the down second button (used by screen readers).  */
    downSecondLabel = 'menos un segundo';

    /** A label for the up minute button (used by screen readers).  */
    upMinuteLabel = 'agrega un minuto';

    /** A label for the down minute button (used by screen readers).  */
    downMinuteLabel = 'menos de un minuto';

    /** A label for the up hour button (used by screen readers).  */
    upHourLabel = 'agrega una hora';

    /** A label for the down hour button (used by screen readers).  */
    downHourLabel = 'menos de una hora';

    /** A label for the previous month button (used by screen readers). */
    prevMonthLabel = 'Mes anterior';

    /** A label for the next month button (used by screen readers). */
    nextMonthLabel = 'Proximo mes';

    /** A label for the previous year button (used by screen readers). */
    prevYearLabel = 'Año anterior';

    /** A label for the next year button (used by screen readers). */
    nextYearLabel = 'Proxima año';

    /** A label for the previous multi-year button (used by screen readers). */
    prevMultiYearLabel = '21 años anteriores';

    /** A label for the next multi-year button (used by screen readers). */
    nextMultiYearLabel = 'Proximos 21 años';

    /** A label for the 'switch to month view' button (used by screen readers). */
    switchToMonthViewLabel = 'Cambie a vista de mes';

    /** A label for the 'switch to year view' button (used by screen readers). */
    switchToMultiYearViewLabel = 'Escoja mes y año';

    /** A label for the cancel button */
    cancelBtnLabel = 'Cancelar';

    /** A label for the set button */
    setBtnLabel = 'Confirmar';

    /** A label for the range 'from' in picker info */
    rangeFromLabel = 'De';

    /** A label for the range 'to' in picker info */
    rangeToLabel = 'a';

    /** A label for the hour12 button (AM) */
    hour12AMLabel = 'AM';

    /** A label for the hour12 button (PM) */
    hour12PMLabel = 'PM';
}

class Fechas {
  date: Date;
};

@Component({
  selector: 'app-parametrizacion-fechas',
  templateUrl: './parametrizacion-fechas.component.html',
  styleUrls: ['../../../assets/css/main.css',
             './parametrizacion-fechas.component.css'],
  providers: [
                 // The locale would typically be provided on the root module of your application. We do it at
                 // the component level here, due to limitations of our example generation script.
                 {provide: OWL_DATE_TIME_LOCALE, useValue: 'sp'},
                 {provide: DateTimeAdapter, useClass: NativeDateTimeAdapter, deps: [OWL_DATE_TIME_LOCALE, Platform]},
                 {provide: OwlDateTimeIntl, useClass: SpanishIntl},
             ],
})
export class ParametrizacionFechasComponent implements OnChanges , OnInit {
  public minFechaEntrega = new Date();
  public arrayDate:Date[];
  listFechasIni: Array<Fechas>;
  listFechasFin: Array<Fechas>;

  form: FormGroup;
  display='none';
  data: ParametrizacionFechas;
  frecuencias:any[];
  selectedFrecuencia = [];
  combos:any[];
  combosClientes:any[]=[];
  combosOts:any[]=[];
  combosCategorias:any[];
  combosCargos:any[];
  listmails:any[];
  listFichas:ListFicha[];
  selectedItem:any
  order: string = 'id';
  reverse: boolean = true;
  selectedItemFicha : Array<ListFicha>;
  selectedCheckBox  = [];
  selectedAll : false;
  public modalRef: BsModalRef;
  template: TemplateRef<any>
  mensaje_error : string;
  booChecked = [];
  booSelectAll = false;
  private _opened: boolean = false;
  show   = [];
  ArrfechasPlaneadas : Array<FechasPlaneadas[]>;
  p:any;
  public selectedClientesPa = [];
  public selectedOtsPa = [];

  //Security variables
  pathsend :string;
  controlesseguridad : ControlesSeguridad;
  listcontroleseguridad :ControlesSeguridad[];
  //Security variables
  fechasArrayIni = [];
  fechasArrayFin = [];

  dataControls : any;
  banderaFilter: number = 0;

  constructor(private authService: AuthService,
              private router: Router,
              private formBuilder: FormBuilder,
              private sanitizer: DomSanitizer,
              private parametrizacionFechasService: ParametrizacionFechasService,
              private modalService: BsModalService,
              private menuEstadoService: MenuEstadoService,
              private _router: ActivatedRoute,
              private fichaTecnicaService: FichaTecnicaService,
              public dialog: MatDialog,
              private controlSeguridadService :ControlSeguridadService,
              private location: Location
            ){

              this.listFechasIni = new Array<Fechas>();
              this.listFechasFin = new Array<Fechas>();
              for (let i = 1; i < 100; i++) {
                let dateFec = {
                 date:new Date()
                 };
                 this.listFechasIni.push(dateFec);
                 this.listFechasFin.push(dateFec);
              }

              this.pathsend=getPathToSend(router.parseUrl(location.path()));
              /*let getOt = this._router.snapshot.paramMap.get('ot');
              if(getOt != null){
                this.findFicha(getOt);
              }*/
            }

  /*Constructor*/
  ngOnInit() {
    this.selectedItemFicha = new Array<ListFicha>();
    this.ArrfechasPlaneadas = new Array<FechasPlaneadas[]>();
    PARAMETRIZACIONFECHAS[FIRSTPARAMETRIZACION].fichas = new Array<ListFicha>();
    this.setParametrizacion();
    this.getFrecuencia();
    this.getCombos();
    this.getListMails();
    this.getListFichas();
    this.form = this.formBuilder.group({
        cliente: [null],
        ot: [null],
        categoria: [null , Validators.required],
        cargo: [null , Validators.required],
        frecuencia: [null ,Validators.required],
        dias_habiles : [null],
        dia_recepcion : [null,Validators.required,this.validOnlyNumber],
        dia_armado:[null,Validators.required,this.validOnlyNumber],
        dia_pedido:[null,Validators.required,this.validOnlyNumber],
        cancelacion: [null,Validators.required,this.validOnlyNumber],
        alerta_fecha: [null,Validators.required,this.validOnlyNumber],
        email: [null,Validators.required],
        fecha_entrega: [null],
        fechas_rango: this.formBuilder.array([this.createItem()]),
    })

    this.setControlesSeguridad();
    this.getControlesSeguridad();
  }

  /*Metodo usado para setear los controles de seguridad*/
  setControlesSeguridad(): void {
     this.controlSeguridadService.setSeguridadControles()
        .subscribe(data=> {
         this.controlesseguridad = data;
     });
  }

  /*Metodo consumidor para traer controles  de seguridad*/
  getControlesSeguridad(): void {
    this.controlSeguridadService.getSeguridadControles(this.pathsend)
        .subscribe(controleseguridad => {
        this.listcontroleseguridad = controleseguridad;
      });
  }

  setPermisos(filter:string){
      let data = Array.of(this.listcontroleseguridad);
      var booEstado;
      data.forEach(function (value) {
          if(value != undefined){
               booEstado = value.find(function(element) {
                  return element.descripcion == filter ? true : false;
              });
          }
      })
      if(booEstado===false || booEstado==undefined ) return false;
      return true;
  }

   get fechas_rango(): FormArray { return this.form.get('fechas_rango') as FormArray; }

  private _toggleSidebar() {
    this._opened = !this._opened;
  }

  filtrosDetailTypeScript(i : number , id_detail : number ){
    /*if($("#rowFichaTecnica"+i).hasClass("d-none")){
         $("#rowFichaTecnica"+i).removeClass();
         $("#iconFichaTecnica"+i).toggleClass("icon-detail-minus");
    }
    else{
        $("#rowFichaTecnica"+i).addClass("d-none");
        $("#iconFichaTecnica"+i).removeClass();
        $("#iconFichaTecnica"+i).toggleClass("icon-detail-plus");
    }*/
    if(this.show[i] == undefined || this.show[i] == false ){
        this.show[i] = true;
        this.parametrizacionFechasService.getFechasPlaneadas(id_detail)
        .subscribe(
              fechasPlaneadas => {
                if(fechasPlaneadas.length > 0 ){
                   this.ArrfechasPlaneadas[i] = fechasPlaneadas;
                  $("#iconFichaTecnica"+i).toggleClass("icon-detail-minus");
                }
        });
    }
    else if(this.show[i] == true){
      this.show[i] = false;
      $("#iconFichaTecnica"+i).removeClass();
      $("#iconFichaTecnica"+i).toggleClass("icon-detail-plus");

    }
  }

  /*Trae lista de fichas*/
  getListFichas(): void {
    this.parametrizacionFechasService.getListFichas()
    .subscribe(
          listFichas => {
          this.listFichas = listFichas;
    });
  }

  /*Trae los combos*/
  getCombos(): void {

    /* let ot = this._router.snapshot.paramMap.get('ot');
    if(ot == null){
        ot ="";
    } */
    let ot = "";
    let otUrl = this._router.snapshot.paramMap.get('ot');

    this.parametrizacionFechasService.getOtsForFicha(ot)
      .subscribe(data => {
          this.dataControls = data;
          let controlsOt = this.onlyUnique(data,'OT');
          //Clientes
          let misclientes = this.onlyUnique(data,'ID_CLIENTE');
          let dataCliente = misclientes.map( val => ({
               id_cliente: val.ID_CLIENTE,
               party_name: val.NOMBRE_CLIENTE
          }));
          this.combosClientes=dataCliente;
          //Clientes

          //Set el cliente
          /* if(ot!="") {
            this.selectedClientesPa = dataCliente.map( val => ({
                  id_cliente: val.id_cliente,
                  party_name: val.party_name
            }));
            this.selectedClientesPa =this.selectedClientesPa[0];
          } */
          //Set el cliente

          //Ots
          let misOts = this.onlyUnique(data,'OT');
          let dataOt = misOts.map( val => ({
               ot: val.OT
          }));
           this.combosOts=dataOt;
          //Ots

          //Set la Ot
          /* if(ot!="") {
            this.selectedOtsPa = dataOt.map( val => ({
                  ot: val.ot
            }));
            this.selectedOtsPa =this.selectedOtsPa[0];
          } */
          //Set la Ot

          //Asigno valores predeterminado en ot y cliente si viene datos por la url
          if(otUrl != null){
            this.banderaFilter = 1;
            let respp = controlsOt.filter(x => x.OT == otUrl);
            this.selectedOtsPa = respp.map( val => ({
              ot: val.OT
            }));
            this.selectedOtsPa =this.selectedOtsPa[0];
            this.setClienteOtNew(otUrl);
          }
          else{
            this.banderaFilter = 0;
            //Categoria
            let misCategorias = this.onlyUnique(data,'ID_CATEGORIA');
            let dataCategoria = misCategorias.map( val => ({
                id_categoria: val.ID_CATEGORIA,
                categoria_descripcion : val.DESCRIPCION_CATEGORIA
            }));
            this.combosCategorias = dataCategoria;
            //Categoria

            //Cargos
            let misCargos = this.onlyUnique(data,'COD_CARGO_CIUDAD');
            let dataCargos = misCargos.map( val => ({
                cod_cargo_ciudad: val.COD_CARGO_CIUDAD,
                cargo_descripcion : val.CARGO_CIUDAD
            }));
            this.combosCargos= dataCargos;
            //Cargos
          }

      });
  }

  /*Retorna datos unicos segun campo proporcionado*/
  onlyUnique(arraydata : Array<any> , field:string) : any[] {
     var unique = new Array();
     var resul = new Array();

     arraydata.forEach(function (value) {
          unique.push(value[field])
     });

    var uniqueFinal = unique.filter(function(elem, index, self) {
      return index === self.indexOf(elem);
    });

    uniqueFinal.forEach(function (datos) {
        var row = arraydata.find(function(element) {
              return element[field] ==  datos;
        });
        resul.push(row);
    });
    return resul;
  }

  /*Trae lista de emails*/
  getListMails(): void {
    this.parametrizacionFechasService.getListMails()
    .subscribe(
          listmails => {
          this.listmails = listmails;
    });
  }

  /*Lista las frecuencias*/
  getFrecuencia():void {
    this.parametrizacionFechasService.getFrecuencia()
    .subscribe(
          frecuencias => {
            this.frecuencias = frecuencias;
        });
  }

  /*Metodo usado para setear Perfiles*/
  setParametrizacion(): void {
   this.parametrizacionFechasService.setParametrizacion()
       .subscribe(data=> {
         this.data = data;
       });
  }

  createItem(): FormGroup {
      return this.formBuilder.group({
        fecha_inicial: [null, Validators.required],
        fecha_final: [null, Validators.required],
      });
  }

  //Valida datos numericos
  validOnlyNumber(control: AbstractControl) {
      var pattern = /^\d{1,20}$/;
      return Observable.of(!pattern.test(control.value)).pipe(
        map(result => result ? { invalid: true } : null)
      );
  }

  //Agrega filas de rangos de fechas
  addRow(): void {
    const control = <FormArray>this.form.controls['fechas_rango'];
    control.push(this.createItem());
  }

   // Elimina filas de rangos de fechas
   removeRow(i: number) {
    const control = <FormArray>this.form.controls['fechas_rango'];
    control.removeAt(i);
  }

  //Funcion de salida del sistema
  public logout(){
    this.authService.logout();
    this.menuEstadoService.setMenuEstado(false);
    $('#totalizado').html('0');
    let redirect = this.authService.redirectUrl ? this.authService.redirectUrl : '/login';
    let navigationExtras: NavigationExtras = {
      queryParamsHandling: 'preserve',
      preserveFragment: true
    };
    // Redirect the user
    this.router.navigate([redirect], navigationExtras);
  }

  /*Se inician metodos de validacion*/
  isFieldValid(field: string) {
  return !this.form.get(field).valid && this.form.get(field).touched;
  }

  /**Envia datos de usuarios*/
  displayFieldCss(field: string) {
  return {
    'has-error': this.isFieldValid(field),
    'has-feedback': this.isFieldValid(field)
   };
  }

  /*Se inician metodos de validacion*/
  isFieldValidArray(field: string , i: number) {
  return !this.form.get(['fechas_rango', i, field]).valid && this.form.get(['fechas_rango', i, field]).touched;
  }

  /**Envia datos de usuarios*/
  displayFieldCssArray(field: string , i: number) {
  return {
    'has-error': this.isFieldValidArray(field ,i),
    'has-feedback': this.isFieldValidArray(field,i)
   };
  }

  validateFechas() : boolean{
      let index =0;
      let booEstado = true;

      for (let obj in this.form.get('fechas_rango')){
         if(this.form.get(['fechas_rango', index, 'fecha_inicial'])!=null){
             let fechasData = new FechasType;
             fechasData.fecha_inicio =this.form.get(['fechas_rango', index, 'fecha_inicial']).value;
             fechasData.fecha_fin    =this.form.get(['fechas_rango', index, 'fecha_final']).value
             booEstado = (fechasData.fecha_inicio == null || fechasData.fecha_fin == null) ?  false : true;
             if(!booEstado) break;
          }
         index++;
     }
     return booEstado;
  }

  /*Envia datos*/
  onSubmit(template: TemplateRef<any>) {
    if(!this.validateFechas()){
        this.mensaje_error="Debe definir rangos de fecha , para poder planear las entregas";
        this.mensajeNotificacion(this.mensaje_error);
        //this.openModalMessage(template);
        return;
    }

    if (this.form.valid) {
      this.add(template);
    } else {
      this.validateAllFormFields(this.form);
    }
  }

  /*Setea la OT a buscar*/
  onFilter(newValue) {
    if(newValue.length == 0){
      return;
    }

    if(newValue!=null){
     this.setClienteOtNew(newValue['ot']);
     this.selectedItem = newValue;
   }

   this.banderaFilter = (this.banderaFilter === 0) ? 3 : this.banderaFilter;
 }

 setClienteOtNew(otData:string){
   this.selectedClientesPa = [];
   this.data.categoria = "";
   this.data.cargo = "";

   let newValue = {
      ot: otData,
   };

   if(newValue!=null){
     this.selectedItem = newValue;
     let respp = this.dataControls.filter(x => x.OT == newValue.ot);

     if (respp != undefined){
       this.selectedClientesPa = respp.map( val => ({
         id_cliente: val.ID_CLIENTE,
         party_name: val.NOMBRE_CLIENTE
       }));
       this.selectedClientesPa =this.selectedClientesPa[0];

     }
     this.combosCategorias = respp != undefined ? this.onlyUnique(respp,'ID_CATEGORIA').map( val => ({id_categoria: val.ID_CATEGORIA, categoria_descripcion : val.DESCRIPCION_CATEGORIA})): [];
     //Cargos
     this.combosCargos = respp != undefined ? this.onlyUnique(respp,'COD_CARGO_CIUDAD').map( val => ({cod_cargo_ciudad: val.COD_CARGO_CIUDAD, cargo_descripcion : val.CARGO_CIUDAD})): [];
   }
 }

 /**Busqueda por OT*/
 onSearch(template: TemplateRef<any>) {
   this.booChecked = [];
   this.selectedCheckBox  = [];
   this.ArrfechasPlaneadas = new Array<FechasPlaneadas[]>();
   this.show = [];

   if(this.selectedItem  != null){
     this.selectedItemFicha=new Array<ListFicha>();
     PARAMETRIZACIONFECHAS[FIRSTPARAMETRIZACION].fichas=new Array<ListFicha>();
       this.parametrizacionFechasService.getListFichasOt( this.selectedItem.ot )
         .subscribe(listfichas => {
               this.listFichas=listfichas as ListFicha[];
               if (this.data.categoria.length !== 0)
               {
                  const arrayCategory: any = this.data.categoria;
                  this.listFichas = this.listFichas.filter(o => !!arrayCategory.find( x => x['id_categoria'] === o['ID_CATEGORIA']));
               }
               if (this.data.cargo.length !== 0)
               {
                  const arrayCargo: any = this.data.cargo;
                  this.listFichas = this.listFichas.filter(o => !!arrayCargo.find( x => {
                    const id_cargo_ciudad: string = x['cod_cargo_ciudad'];
                    const id_cargo: string[] = id_cargo_ciudad.split('-');
                    return id_cargo[0] === o['ID_CARGO'];
                  }));
               }
        });
     }
     else{
       this.mensaje_error="Para poder buscar , defina por lo menos una OT";
       this.mensajeNotificacion(this.mensaje_error);
       //this.openModalMessage(template);
     }
 }
 /*Selecciona todos los checkbox*/
 onCheckAll( newValue , template: TemplateRef<any>) {
     //this.selectedAll = newValue;
     this.selectedItemFicha = new Array<ListFicha>();

     if(newValue == true){
       let index =0;
       let indexPro =0;

       for (let entry of this.listFichas){
          if(entry.procesado == "0" || entry.procesado == null ){
            this.selectedItemFicha.push(entry);
            this.selectedCheckBox[index] =true;
            this.booChecked[index] =true;
          }
          else if(entry.procesado == "1"){
            this.selectedItemFicha.splice(index,1);
            this.selectedCheckBox[index] =false;
            this.booChecked[index] =false;
            indexPro++
          }
          index++;
      }

      if( this.listFichas.length == indexPro){

          if(this.booSelectAll == false){
              this.booSelectAll = undefined;
              this.selectedAll = undefined;
          }
          else if(this.booSelectAll == undefined){
              this.booSelectAll = false;
              this.selectedAll = false;
          }

          this.mensaje_error="Todas las lineas de esta ficha ya tienen fechas planeadas , no pueden ser seleccionadas.";
          this.mensajeNotificacion(this.mensaje_error);
          //this.openModalMessage(template);
      }
    }
    else{
       this.selectedCheckBox.forEach(function (value , index , array ) {
            array[index] = newValue;
       });

       this.booChecked.forEach(function (value , index , array ) {
            array[index] = newValue;
       });
    }
 }

 onIndexOf( newValue : ListFicha ) {
      return this.listFichas.indexOf(newValue);
 }

 onChangeDetalleFicha(newValue , data :ListFicha , template: TemplateRef<any> , index : number) {
    if(data.procesado == '1'){
       if(this.booChecked[index] == undefined){
          this.booChecked[index] =false;
       }
       else if(this.booChecked[index] == false || this.booChecked[index] == true){
          this.booChecked[index] =undefined;
       }

       this.mensaje_error="Esta linea ya tiene fechas planeadas configuradas , no se puede seleccionar";
       this.mensajeNotificacion(this.mensaje_error);
       //this.openModalMessage(template);
    }
    else{
      /*Agrega lineas a programar*/
      this.selectedCheckBox[index] = newValue;
      this.booChecked[index] =newValue;

      if(newValue){
         this.selectedItemFicha.push(data);
       }
       else{
         var index = this.selectedItemFicha.indexOf(data);
         this.selectedItemFicha.splice(index,1);
       }
    }
}

 /*Open modal en usuarios*/
 public openModalMessage(template: TemplateRef<any>) {
   this.modalRef = this.modalService.show(template);
 }

  add(template: TemplateRef<any>): void {
      //Validaciones
      if((<FormArray>this.form.controls['fechas_rango']).length == 0){
          this.mensaje_error="Por lo menos defina un rango de fecha.";
          this.mensajeNotificacion(this.mensaje_error);
          //this.openModalMessage(template);
          return;
      }

      if(this.selectedItem == null){
        this.mensaje_error="Primero debe seleccionar una OT ,y después presionar el botón buscar";
        this.mensajeNotificacion(this.mensaje_error);
          //this.openModalMessage(template);
        return;
      }

      if(this.selectedItemFicha.length == 0){
        this.mensaje_error="No hay detalles de fichas seleccionados , debe seleccionarlos de la grilla";
        this.mensajeNotificacion(this.mensaje_error);
          //this.openModalMessage(template);
        return;
      }

      //Encabezado
      PARAMETRIZACIONFECHAS[FIRSTPARAMETRIZACION].cliente=this.data.cliente;
      PARAMETRIZACIONFECHAS[FIRSTPARAMETRIZACION].ot=this.data.ot;
      PARAMETRIZACIONFECHAS[FIRSTPARAMETRIZACION].categoria=this.data.categoria;
      PARAMETRIZACIONFECHAS[FIRSTPARAMETRIZACION].cargo=this.data.cargo;
      PARAMETRIZACIONFECHAS[FIRSTPARAMETRIZACION].frecuencia=this.data.frecuencia;
      PARAMETRIZACIONFECHAS[FIRSTPARAMETRIZACION].dias_habiles=this.data.dias_habiles;
      PARAMETRIZACIONFECHAS[FIRSTPARAMETRIZACION].dias_armado=this.data.dias_armado;
      PARAMETRIZACIONFECHAS[FIRSTPARAMETRIZACION].dias_pedido=this.data.dias_pedido;
      PARAMETRIZACIONFECHAS[FIRSTPARAMETRIZACION].dias_recepcion=this.data.dias_recepcion;
      PARAMETRIZACIONFECHAS[FIRSTPARAMETRIZACION].fecha_entrega=this.data.fecha_entrega;
      PARAMETRIZACIONFECHAS[FIRSTPARAMETRIZACION].cancelacion=this.data.cancelacion;
      PARAMETRIZACIONFECHAS[FIRSTPARAMETRIZACION].alerta_fecha=this.data.alerta_fecha;
      PARAMETRIZACIONFECHAS[FIRSTPARAMETRIZACION].alerta_correo=this.data.alerta_correo;
      PARAMETRIZACIONFECHAS[FIRSTPARAMETRIZACION].fechas = new Array<FechasType>();
      PARAMETRIZACIONFECHAS[FIRSTPARAMETRIZACION].fichas = new Array<ListFicha>();

      //DetalleFichas tecnicas
      //Detalle
        let index =0;
        for (let obj in this.form.get('fechas_rango')){
           if(this.form.get(['fechas_rango', index, 'fecha_inicial'])!=null){
               let fechasData = new FechasType;
               fechasData.fecha_inicio =this.form.get(['fechas_rango', index, 'fecha_inicial']).value;
               fechasData.fecha_fin    =this.form.get(['fechas_rango', index, 'fecha_final']).value;
               PARAMETRIZACIONFECHAS[FIRSTPARAMETRIZACION].fechas.push(fechasData);
            }
           index++;
       }

      this.selectedItemFicha.forEach(function (value , index , array ) {
          PARAMETRIZACIONFECHAS[FIRSTPARAMETRIZACION].fichas.push(value);
      });

      this.parametrizacionFechasService.updateParametrizacion(PARAMETRIZACIONFECHAS[FIRSTPARAMETRIZACION])
        .subscribe(parametrizacion => {
            let resp =  false;
            this.listFichas.forEach(function (value ,index, array ) {

            var found = parametrizacion.find(function(element) {
                      return element.id == value .id;
            });

            if(found!=null){
                  value['ARMADO_PEDIDO']    = found['Armado'];
                  value['PEDIDO_PROVEEDOR'] = found['pedido'];
                  value['RECEPCION_BODEGA'] = found['recepcion'];
                  value['FECHA_ENTREGA']    = found['entrega'];
                  value['CANCELACION']      = found['cancelacion'];
                  value['ALERTA_FECHA']     = found['alerta'];
                  value['NOMBRE_FRECUENCIA']= found['frecuencia'];
                  value['procesado']= '1';
                  resp = true;
              }
            });

            if(resp){
              this.selectedAll = false;
              this.booSelectAll = false;
              this.selectedCheckBox.forEach(function (value , index , array ) {
                   array[index] = false;
              });

              this.booChecked.forEach(function (value ,index, array ) {
                    array[index] = false;
              });
              this.mensaje_error="Planificación realizada de forma satisfactoria";
              this.mensajeNotificacion(this.mensaje_error);
              //this.openModalMessage(template);
            }
      });

      this.selectedItemFicha = [];
  }

  /*Valida campos de formulario*/
  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
    const control = formGroup.get(field);
    if (control instanceof FormControl) {
      control.markAsTouched({ onlySelf: true });
    } else if (control instanceof FormGroup) {
      this.validateAllFormFields(control);
    }
  });
  }

  /*Limpia formulario*/
  reset() {
    this.form.reset();
  }

  //Carga del metodo despues de la carga
  ngAfterViewInit(){
    $(document).ready(function(){
          $("#navmainmenu").show();
     });
  }

  /*Metodo que abre dialogo para mostrar las fechas configuradas*/
  openModal(){
      this.display='block';
  }

  /*Metodo cierra dialogo  que cierra dialogo  */
  onCloseHandled(){
       this.display='none';
  }

  //Ir a ficha tecnica
  goFicha(template: TemplateRef<any>){
    if(this.selectedOtsPa['ot'] == undefined)
    {
      this.mensaje_error="Debe seleccionar una OT";
      this.mensajeNotificacion(this.mensaje_error);
      //this.openModalMessage(template);
    }
    else
      this.router.navigate(['./ficha-tecnica/'+this.selectedOtsPa['ot']])
  }

  /*private findFicha(ot){
        this.parametrizacionFechasService.getListFichasOt( ot )
        .subscribe(listfichas => {
            this.listFichas=listfichas as ListFicha[];
       });

     this.fichaTecnicaService.getData()
      .subscribe(resp => {
        this.llenarOt(resp.ot, resp.clientes, ot);
        //this.combosCategorias = resp.categorias;
      });
  }*/

  private llenarOt(ots, listClients, otselected){
    ots.forEach(element => {
      this.combosOts.push({'ot': element['ID_OT'], 'cliente': element['ID_CLIENTE']});
    });
    this.data.ot = this.combosOts.find(x => x.ot == otselected);

    listClients.forEach(element => {
      this.combosClientes.push({'cliente': element['NIT'], 'party_name': element['NOMBRE']});
    });

    this.data.cliente = this.combosClientes.find(x => x.cliente == this.data.ot["cliente"]);
  }

  mensajeNotificacion(mensaje: string) {
    const dialogo = this.modalConfirmacion('AVISO', mensaje, 'Aceptar', false);
    dialogo.componentInstance.confirmacionCallback.subscribe(resultado => {
      dialogo.close();
    })
  }

  modalConfirmacion(titulo: string, mensaje: string, etiquetaConfirmacion: string, verCancelar = true, mData = null) {
    let data = {
      titulo: titulo,
      mensaje: mensaje,
      etiquetaConfirmacion: etiquetaConfirmacion,
      verCancelar: verCancelar,
    }
    return this.dialog.open(AlertsComponent, { data: data });
  }

  ngOnChanges(changes: SimpleChanges) {
    /*const name: SimpleChange = changes.name;
    console.log('prev value: ', name.previousValue);
    console.log('got name: ', name.currentValue);
    this._name = name.currentValue.toUpperCase();*/
  }

  updateMyDateIni(newDate , i:number) {
    if( newDate != undefined){
      //this.minFechaFin = new Date(newDate);
      this.listFechasFin[i].date =  new Date(newDate);
      this.fechasArrayFin[i] =  new Date(newDate);
    }
  }

  updateMyDateFin(newDate, i:number) {

  }

  resetDate(i:number){
    this.listFechasIni[i].date = new Date();
    this.fechasArrayIni[i] = new Date();

    this.listFechasFin[i].date =  new Date();
    this.fechasArrayFin[i] =  new Date();
  }

  /*getIndexRandom() : number{
    return Math.floor(Math.random() * 100) + 1;
  }*/

   /*Setea la Cliente a buscar*/
   onCliente(newValue) {
    if(newValue.length == 0){
      return;
    }
    if(this.banderaFilter === 2 || this.banderaFilter === 3){
      this.banderaFilter = 0;
    }
    else if(newValue!=null && this.banderaFilter == 0){
      this.setClienteOt(newValue);
      this.selectedItem = newValue;
    }
    else{
      this.banderaFilter = 2;
    }
  }

  setClienteOt(clienteData){
    this.selectedOtsPa = [];
    this.data.categoria = "";
    this.data.cargo = "";
 
    /* let newValue = {
       ot: "",
    }; */ 
    //let newValue = {cod_cargo_ciudad: val.COD_CARGO_CIUDAD, cargo_descripcion : val.CARGO_CIUDAD};
 
    if(clienteData!=null && clienteData != undefined){
      //this.selectedItem = newValue;
      let respp = this.dataControls.filter(x => x.ID_CLIENTE == clienteData.id_cliente);

      let misOts = this.onlyUnique(respp,'OT');
      let dataOt = misOts.map( val => ({
        ot: val.OT
      }));
      this.combosOts=dataOt;

      this.combosCategorias = respp != undefined ? this.onlyUnique(respp,'ID_CATEGORIA').map( val => ({id_categoria: val.ID_CATEGORIA, categoria_descripcion : val.DESCRIPCION_CATEGORIA})): [];
      //Cargos
      this.combosCargos = respp != undefined ? this.onlyUnique(respp,'COD_CARGO_CIUDAD').map( val => ({cod_cargo_ciudad: val.COD_CARGO_CIUDAD, cargo_descripcion : val.CARGO_CIUDAD})): [];
    }
  }

  
}

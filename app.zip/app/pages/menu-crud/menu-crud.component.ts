import { Component, OnInit ,Input ,TemplateRef , ViewChild , ElementRef ,OnChanges, SimpleChanges } from '@angular/core';
import { FormGroup, FormBuilder, Validators ,FormControl} from '@angular/forms';
import { MENUS } from '../../mocks/mock-menu';
import { Menu } from '../../class/menu';
import { MenuService } from '../../service/menu/menu.service';
import { Validation } from '../../validation/validation';
import { OrderPipe } from 'ngx-order-pipe';
import { ValidationService } from '../../service/validation/validation.service';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { AuthService }  from '../../service/auth/auth.service';
import { Router,NavigationExtras } from '@angular/router';
import { MenuEstadoService } from '../../service/menu-estado/menu-estado.service';
import { MatDialog } from '@angular/material';
import { AlertsComponent } from '../../utils/alerts/alerts.component';

class OptPages {
  id: number;
  value: string;
  label : string;
  selected : string;
};

@Component({
  selector: 'app-menu-crud',
  templateUrl: './menu-crud.component.html',
  styleUrls: ['../../../assets/css/main.css',
               './menu-crud.component.css']
})

export class MenuCrudComponent implements OnInit {
  menus: Menu[];
  selectedMenu =[];
  display='none';
  idDelete:string;
  OpNameValue = 'add';
  data: Menu;
  form: FormGroup;
  order: string = 'id';
  reverse: boolean = true;
  public modalRef: BsModalRef;
  template: TemplateRef<any>
  mensaje_error:string;
  p:any;
  idx: any;
  selectedRangePage: OptPages[] = [
    { id: 1, value: '10'  , label:'10',   selected : 'selected' },
    { id: 2, value: '20' , label:'20',  selected : ''},
    { id: 3, value: '30' , label:'30',  selected : '' }
  ];
  perpageitem: number = 10;

  /*Llamada a metodo de consumo de menus*/
  constructor(private formBuilder: FormBuilder,
              private menuService: MenuService,
              private validationService :ValidationService,
              private orderPipe: OrderPipe,
              private modalService: BsModalService,
              private authService: AuthService,
              private router: Router,
              private menuEstadoService: MenuEstadoService,
              public dialog: MatDialog) { }

 /*Llamada a metodo de consumo de menus*/
  ngOnInit() {
      this.menus = this.orderPipe.transform(this.menus, 'id');
      this.setMenus();
      this.getMenus();
      this.form = this.formBuilder.group({
      datosusuarios: this.formBuilder.group({
        nombre: [null, Validators.required],
        url: [null],
        id_menu_padre: [null]
      })
    });
  }

  /*Ordenar menus*/
  setOrder(value: string) {
    if (this.order === value) {
      this.reverse = !this.reverse;
    }
    this.order = value;
  }

  /*Open modal en usuarios*/
  public openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);
  }

  /*Metodo usado para setear Menus*/
  setMenus(): void {
   this.menuService.setMenus()
       .subscribe(data=> this.data = data);
  }

  /*Metodo consumidor para traer menus*/
  getMenus(): void {
    this.menuService.getMenus()
    .subscribe(menus => {
          this.menus = menus;
          //console.log(this.menus);
      });
  }

  /*Lista los usuarios buscados*/
  searchMenus(term :string):void {
    this.menuService.searchMenus(term)
    .subscribe(menus =>{
        this.menus = menus;
    });
  }

  /*Metodo accion para agregar menus*/
  add(template: TemplateRef<any>): void {
    if(this.OpNameValue  === 'edit'){
      this.menuService.updateMenu(this.data)
        .subscribe(menu => {
            if(menu.hasOwnProperty('mensaje')){
              this.mensaje_error = menu['mensaje'];
              this.mensajeNotificacion(this.mensaje_error);
              //this.openModal(template);
              this.form.reset();
              this.OpNameValue='add';
              return;
            }
            var index = this.menus.findIndex(obj => obj.id== menu.id);
            this.menus[index] = menu;
            this.mensaje_error ='Menú editado satisfactoriamente.';
            this.mensajeNotificacion(this.mensaje_error);
            //this.openModal(template);
            this.form.reset();
            this.getMenus();
            this.OpNameValue  = 'add';
        });

      return;
    }

    this.menuService.addMenus(this.data)
        .subscribe(menu => {
            if(menu.hasOwnProperty('mensaje')){
             this.mensaje_error = menu['mensaje'];
             this.mensajeNotificacion(this.mensaje_error);
             //this.openModal(template);
             this.form.reset();
             this.OpNameValue='add';
             return;
            }

            this.menus.push(menu);
            this.mensaje_error ='Menú agregado satisfactoriamente.';
            this.mensajeNotificacion(this.mensaje_error);
            //this.openModal(template);
            this.form.reset();
            this.getMenus();
            this.OpNameValue='add';
    });
  }

  /*Metodo accion para borrar menu*/
  delete(id: string): void {
    //console.log('El id es '+id);
    this.menuService.deleteMenu( { id } as Menu ).
        subscribe( menu => {
          if(menu.hasOwnProperty("mensaje") && menu['mensaje'] == true){ // true
            this.mensaje_error ='Menú eliminado correctamente.';
            this.mensajeNotificacion(this.mensaje_error);
            //this.openModal(template);
            var index = this.menus.findIndex(obj => obj.id==id);
            this.menus.splice(index,1);
            this.getMenus();
          }
          else{
            this.mensaje_error =menu['mensaje'];
            this.mensajeNotificacion(this.mensaje_error);
            //this.openModal(template);
          }
          
        });
    this.display='none';
  }

  /*Metodo accion para editar menus*/
  save( menu : Menu): void {
    this.data = Object.assign({},menu);
    this.OpNameValue ='edit';
    this.animateScrollTop("30%");
  }

  /*Limpia formulario*/
   reset() {
     this.form.reset();
     this.OpNameValue  = 'add';
  }

  /*Metodo abre dialogo de confirmacion de borrado*/
  openModalDelete(id:string){
      //this.display='block';
      this.idDelete=id;
      this.mensajeEliminacion('Desea borrar el registro ?');
  }

  /*Metodo cierra dialogo de confirmacion de borrado*/
  onCloseHandledDelete(){
       this.display='none';
  }

  /*Selecccion tipo de operacion*/
  /*typeOperation (objeto: any): void {
     (typeof objeto === 'string' && this.add())  || (typeof objeto === 'object' && this.save(objeto))
  }*/

   //Limpia elementos del array
  clearData()  {
      for (let key of Object.keys(this.data)) {
        eval(  "this.data." +key+"=''");
      }
  }

  /*Se inician metodos de validacion*/
  isFieldValid(field: string) {
  return !this.form.get(field).valid && this.form.get(field).touched;
  }

  /**Envia datos de usuarios*/
  displayFieldCss(field: string) {
  return {
    'has-error': this.isFieldValid(field),
    'has-feedback': this.isFieldValid(field)
   };
  }

  /*Envia datos*/
  onSubmit(template: TemplateRef<any> ) {
    if (this.form.valid) {
          this.add(template);
    } else {
      this.validateAllFormFields(this.form);
    }
  }

  /*Valida campos de formulario*/
  validateAllFormFields(formGroup: FormGroup) {
  Object.keys(formGroup.controls).forEach(field => {
    //console.log(field);
    const control = formGroup.get(field);
    if (control instanceof FormControl) {
      control.markAsTouched({ onlySelf: true });
    } else if (control instanceof FormGroup) {
      this.validateAllFormFields(control);
    }
  });
  }

  public logout(){
    this.authService.logout();
    this.menuEstadoService.setMenuEstado(false);
    $('#totalizado').html('0');
    let redirect = this.authService.redirectUrl ? this.authService.redirectUrl : '/login';
    let navigationExtras: NavigationExtras = {
      queryParamsHandling: 'preserve',
      preserveFragment: true
    };
    // Redirect the user
    this.router.navigate([redirect], navigationExtras);
  }

  onChangePages(newValue){
    this.perpageitem = newValue;
  }

  animateScrollTop(px) {
    $('html, body').animate({
      scrollTop: px
    }, 'slow');
  }

  mensajeNotificacion(mensaje: string) {
    const dialogo = this.modalConfirmacion('AVISO', mensaje, 'Aceptar', false);
    dialogo.componentInstance.confirmacionCallback.subscribe(resultado => {
      dialogo.close();
    })
  }

  mensajeEliminacion(mensaje: string) {
    const dialogo = this.modalConfirmacion('AVISO', mensaje, 'Aceptar');
    dialogo.componentInstance.confirmacionCallback.subscribe(resultado => {
      this.delete(this.idDelete);
      dialogo.close();
    })
  }

  modalConfirmacion(titulo: string, mensaje: string, etiquetaConfirmacion: string, verCancelar = true, mData = null) {
    let data = {
      titulo: titulo,
      mensaje: mensaje,
      etiquetaConfirmacion: etiquetaConfirmacion,
      verCancelar: verCancelar,
    }
    return this.dialog.open(AlertsComponent, { data: data });
  }
}

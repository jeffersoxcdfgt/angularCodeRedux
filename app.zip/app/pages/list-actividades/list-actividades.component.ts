import { Component, OnInit } from '@angular/core';
import { Location , DatePipe } from '@angular/common';
import { AuthService }  from '../../service/auth/auth.service';
import { Router,NavigationExtras } from '@angular/router';
import { MenuEstadoService } from '../../service/menu-estado/menu-estado.service';
import { EstadosolicitudService } from '../../service/estadosolicitud/estadosolicitud.service';
import { TiposolicitudService } from '../../service/tiposolicitud/tiposolicitud.service';
import { ESTADOSOLICITUD } from '../../mocks/mock-estadosolicitud';
import { EstadoSolicitud } from '../../class/estadosolicitud';
import { TIPOSOLICITUD } from '../../mocks/mock-tiposolicitud';
import { TipoSolicitud } from '../../class/tiposolicitud';
import { ClienteOtService } from '../../service/cliente-ot/cliente-ot.service';
import { CLIENTEOT } from '../../mocks/mock-cliente-ot';
import { ClienteOt } from '../../class/cliente-ot';
import { MisSolicitudesService } from '../../service/mis-solicitudes/mis-solicitudes.service';
import { MISSOLICITUDES } from '../../mocks/mock-mis-solicitudes';
import { MisSolicitudes } from '../../class/mis-solicitudes';
import { ResumenEstadoService } from '../../service/resumen-estado/resumen-estado.service';
import { MisSolicitudesRcService } from '../../service/mis-solicitudes-rc/mis-solicitudes-rc.service';
import { AlertsComponent } from '../../utils/alerts/alerts.component';
import { MatDialog } from '@angular/material';

import { CONTROLESEGURIDAD } from '../../mocks/mock-control-seguridad';
import { ControlesSeguridad } from '../../class/controles_seguridad';
import { ControlSeguridadService } from '../../service/control-seguridad/control-seguridad.service';
import { getPathToSend , getOperations } from '../../utils/utils';

@Component({
  selector: 'app-list-actividades',
  templateUrl: './list-actividades.component.html',
  styleUrls: ['../../../assets/css/main.css',
      './list-actividades.component.css']
})
export class ListActividadesComponent implements OnInit {

  public minFechaEntrega = new Date();

  public estadosolicitud:EstadoSolicitud[];
  public  selectedEstadoSolicitud = [];
  public tiposolicitud:TipoSolicitud[];
  public  selectedTipoSolicitud = [];
  public clienteots:ClienteOt[];
  public  itemsOts :ClienteOt[];
  public  selecteditemsOts = [];
  public  itemsCliente : ClienteOt[];
  public  selectedClientesOts = [];
  public misSolicitudes:MisSolicitudes[];
  p:any;
  public detmisolicitud:MisSolicitudes[];
  show   = [];
  ArrMisSolicitudes : Array<MisSolicitudes[]>;
  display='none';
  mensaje_error :string;
  displayhistorico='none';
  public historico:MisSolicitudes[];
  order: string = 'id';
  reverse: boolean = true;
  no_solicitud:string;

  //Security variables
  pathsend :string;
  controlesseguridad : ControlesSeguridad;
  listcontroleseguridad :ControlesSeguridad[];
  //Security variables

  constructor(private authService: AuthService,
              private router: Router,
              private menuEstadoService: MenuEstadoService,
              private estadosolicitudService: EstadosolicitudService,
              private tiposolicitudService: TiposolicitudService,
              private clienteOtService: ClienteOtService,
              private misSolicitudesService: MisSolicitudesService,
              private resumenEstadoService: ResumenEstadoService,
              private misSolicitudesRcService : MisSolicitudesRcService,
              public dialog: MatDialog,
              private controlSeguridadService :ControlSeguridadService,
              private location: Location) {
                this.pathsend=getPathToSend(router.parseUrl(location.path()));
              }

  /*Constructor*/
  ngOnInit() {
    this.resumenEstadoService.setEstadoResumenCotizacion(false);
    this.ArrMisSolicitudes = new Array<MisSolicitudes[]>();
    //this.getEstadosSolicitud();
    //this.getTiposSolicitud();
    //this.getClienteOt();
    //this.getMisSolicitudes();

    if(!this.misSolicitudesRcService.getMisSolicitudesEstado() &&
       !this.misSolicitudesRcService.getMsOTEstado()){
      this.getEstadosSolicitud();
      this.getTiposSolicitud();
      this.getClienteOt();
      this.getMisSolicitudes();
      this.misSolicitudesRcService.setMisSolicitudesEstado(true);
      this.misSolicitudesRcService.setMsOTsEstado(true);

    }
    else{
      this.misSolicitudes  = this.misSolicitudesRcService.getlistMisSolicitudes();
      this.clienteots      = this.misSolicitudesRcService.getMsListOTs();
      this.itemsOts        = this.misSolicitudesRcService.getMsListOTs();
      this.itemsCliente    = this.misSolicitudesRcService.getClienteUnificada();
    }

    this.setControlesSeguridad();
    this.getControlesSeguridad();
  }

  /*Metodo usado para setear los controles de seguridad*/
  setControlesSeguridad(): void {
     this.controlSeguridadService.setSeguridadControles()
        .subscribe(data=> {
         this.controlesseguridad = data;
     });
  }

  /*Metodo consumidor para traer controles  de seguridad*/
  getControlesSeguridad(): void {
    this.controlSeguridadService.getSeguridadControles(this.pathsend)
        .subscribe(controleseguridad => {
        this.listcontroleseguridad = controleseguridad;
      });
  }

  setPermisos(filter:string){
      let data = Array.of(this.listcontroleseguridad);
      var booEstado;
      data.forEach(function (value) {
          if(value != undefined){
               booEstado = value.find(function(element) {
                  return element.descripcion == filter ? true : false;
              });
          }
      })
      if(booEstado===false || booEstado==undefined ) return false;
      return true;
  }

  /*Metodo consumidor para traer estados de solicitud*/
  getEstadosSolicitud(): void {
    this.estadosolicitudService.getEstadosSolicitud()
      .subscribe(estadosolicitud =>{
          this.estadosolicitud = estadosolicitud;
      });
  }

  /*Metodo consumidor para traer Tipos de solicitud*/
  getTiposSolicitud(): void {
    this.tiposolicitudService.getTiposSolicitud()
      .subscribe(tiposolicitud =>{
          this.tiposolicitud = tiposolicitud;
      });
  }

  /*Metodo consumidor para traer las ots y clientes*/
  getClienteOt(): void {
    this.clienteOtService.getClienteOt()
      .subscribe(clienteots =>{
            this.clienteots = clienteots
            this.itemsOts = clienteots; //Ots cargadas
            this.itemsCliente = this.onlyUnique(this.clienteots,'cliente_nit'); //Unificar clientes

            this.misSolicitudesRcService.setMsOTSolicitudes(clienteots) //Lista
            this.misSolicitudesRcService.setClienteUnificada(this.itemsCliente) //Lista loc clientes unificados

      });
  }

  /*Metodo consumidor para traer todas las solicitudes*/
  getMisSolicitudes(): void {
    this.misSolicitudesService.getMisSolicitudes()
      .subscribe(missolicitudes =>{
          if(missolicitudes.hasOwnProperty("mensaje")){
              this.mensaje_error=missolicitudes['mensaje'];
              this.mensajeNotificacion(this.mensaje_error);
              //this.openModal();
              return;
          }
          this.misSolicitudes = missolicitudes;
          this.misSolicitudesRcService.setMisSolicitudes(missolicitudes);
      });
  }

  onIndexOf( newValue : MisSolicitudes ) {
       return this.misSolicitudes.indexOf(newValue);
  }

  filtrosDetailTypeScript(i : number , id_detail : number ){
    if(this.show[i] == undefined || this.show[i] == false ){
        this.show[i] = true;
        this.misSolicitudesService.getMisSolicitudesID(id_detail)
          .subscribe(detmisolicitud =>{
              if(detmisolicitud.length > 0 ){
                 this.ArrMisSolicitudes[i] = detmisolicitud;
                $("#iconDetalleMisSolicitudes"+i).toggleClass("icon-detail-minus");
              }
              else{
                this.mensaje_error = "No existen detalles para este item.";
                this.mensajeNotificacion(this.mensaje_error);
                //this.openModal();
              }
          });
    }
    else if(this.show[i] == true){
      this.show[i] = false;
      $("#iconDetalleMisSolicitudes"+i).removeClass();
      $("#iconDetalleMisSolicitudes"+i).toggleClass("icon-detail-plus");
    }
  }

  /*Filtrado de las ots, pertenencientes a los clientes seleccionados*/
  getOtsXCliente() : void {
    this.selecteditemsOts = this.clienteots.filter(o=> !!this.selectedClientesOts.find(x => x.cliente_nit == o.cliente_nit));
  }

  /*Filtrado de los clientes, pertenencientes a las ots  seleccionados*/
  getClienteXOts() : void {
    this.selectedClientesOts = this.clienteots.filter(o=> !!this.selecteditemsOts.find(x => x.cliente_nit == o.cliente_nit));
  }

  /*Retorna datos unicos segun campo proporcionado*/
  onlyUnique(arraydata : Array<any> , field:string) : any[] {
     var unique = new Array();
     var resul = new Array();

     arraydata.forEach(function (value) {
          unique.push(value[field])
     });

    var uniqueFinal = unique.filter(function(elem, index, self) {
      return index === self.indexOf(elem);
    });

    uniqueFinal.forEach(function (datos) {
        var row = arraydata.find(function(element) {
              return element[field] ==  datos;
        });
        resul.push(row);
    });
    return resul;
  }

  /*Leave the system*/
  public logout(){
    this.authService.logout();
    this.menuEstadoService.setMenuEstado(false);
    $('#totalizado').html('0');
    let redirect = this.authService.redirectUrl ? this.authService.redirectUrl : '/login';
    let navigationExtras: NavigationExtras = {
      queryParamsHandling: 'preserve',
      preserveFragment: true
    };
    // Redirect the user
    this.router.navigate([redirect], navigationExtras);
  }

  /*Metodo abre dialogo para reportar errores*/
  openModal(){
      this.display='block';
  }

  /*Metodo cierra dialogo de reporte de errores*/
  onCloseHandled(){
       this.display='none';
  }


  /*Metodo abre dialogo para registrar el Historico de las solicitudes*/
  HistoricoOpenModal(id_solicitud : string ){
    this.misSolicitudesService.getHistoricoID(id_solicitud)
      .subscribe(historicosol =>{
          this.historico=historicosol;
          this.displayhistorico='block';
      });
  }

  /*Ordenar usuarios*/
  setOrder(value: string) {
    if (this.order === value) {
      this.reverse = !this.reverse;
    }
    this.order = value;
  }

  /*Metodo cierra dialogo  para registrar el Historico de las solicitudes*/
  HistoricoModalCloseError(){
       this.displayhistorico='none';
  }

  /*Filtra una sola solicitud*/
  search(){
     this.misSolicitudesService.searchSolicitudesID(this.no_solicitud)
      .subscribe(missolicitudes =>{
        if(missolicitudes.hasOwnProperty("mensaje")){
            this.mensaje_error=missolicitudes['mensaje'];
            this.mensajeNotificacion(this.mensaje_error);
            //this.openModal();
            return;
        }
        this.misSolicitudes = missolicitudes;
        this.misSolicitudesRcService.setMisSolicitudes(missolicitudes);
      });
  }

  mensajeNotificacion(mensaje: string) {
    const dialogo = this.modalConfirmacion('AVISO', mensaje, 'Aceptar', false);
    dialogo.componentInstance.confirmacionCallback.subscribe(resultado => {
      dialogo.close();
    })
  }

  modalConfirmacion(titulo: string, mensaje: string, etiquetaConfirmacion: string, verCancelar = true, mData = null) {
    let data = {
      titulo: titulo,
      mensaje: mensaje,
      etiquetaConfirmacion: etiquetaConfirmacion,
      verCancelar: verCancelar,
    }
    return this.dialog.open(AlertsComponent, { data: data });
  }

}

import { ActivatedRoute } from '@angular/router';
import { Location , DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { AuthService }  from '../../service/auth/auth.service';
import { Router,NavigationExtras } from '@angular/router';
import { MenuEstadoService } from '../../service/menu-estado/menu-estado.service';
import { FichaTecnicaService } from '../../service/ficha-tecnica/ficha-tecnica.service';
import { FichaTecnica } from '../../class/ficha-tecnica';
import { ParametrizacionFechasService }  from '../../service/parametrizacion-fechas/parametrizacion-fechas.service';
import { Portafolioespecifico } from '../../class/portafolio-especifico';
import { PortafolioEspecificoService }  from '../../service/portafolio-especifico/portafolio-especifico.service';
import { CONTROLESEGURIDAD } from '../../mocks/mock-control-seguridad';
import { ControlesSeguridad } from '../../class/controles_seguridad';
import { ControlSeguridadService } from '../../service/control-seguridad/control-seguridad.service';
import { getPathToSend , getOperations } from '../../utils/utils';
import { AlertsComponent } from '../../utils/alerts/alerts.component';
import { MatDialog } from '@angular/material';

export class Estados{
     id:string;
     descripcion:string;
}


@Component({
  selector: 'app-portafolio-especifico',
  templateUrl: './portafolio-especifico.component.html',
  styleUrls: ['../../../assets/css/main.css',
  './portafolio-especifico.component.css']
})


export class PortafolioEspecificoComponent implements OnInit {

  public portafoliosespecificos:FichaTecnica[];
  public mensaje_error:string;
  public display:string;
  public combos:any[];
  public combosClientes:any[];
  public selectedClientesOts = [];
  public combosOts:any[];
  public  selectedOTsClientes = [];
  public p:any;
  public listPortafoliosEspecificos:Portafolioespecifico[];
  public listPortafoliosEspecificos_aux:Portafolioespecifico[];

  pathsend :string;
  controlesseguridad : ControlesSeguridad;
  listcontroleseguridad :ControlesSeguridad[];

  TiposEstados: Estados [] =  [
      { id:'1', descripcion:'Activo '} ,
      { id:'2', descripcion:'Inactivo'}
  ];
  public selectedEstados = [];

  orderBy: any = [
    { id: 1, descripcion: 'Cliente'},
    { id: 2, descripcion: 'Compañia'},
    { id: 3, descripcion: 'Ot'},
    { id: 4, descripcion: 'Unidad de Negocio'}
  ];
  public selectedOrderBy = [];

  constructor(private authService: AuthService,
              private router: Router,
              private menuEstadoService: MenuEstadoService,
              private fichaTecnicaService:FichaTecnicaService,
              private parametrizacionFechasService: ParametrizacionFechasService,
              private portafolioEspecificoService: PortafolioEspecificoService,
              private controlSeguridadService :ControlSeguridadService,
              private route: ActivatedRoute,
              private location: Location,
              public dialog: MatDialog) {
                this.pathsend=getPathToSend(router.parseUrl(location.path()));
              }

  ngOnInit() {
    //this.getFichasPortafolioEspecifico();
    this.setControlesSeguridad();
    this.getControlesSeguridad();
    this.getListPortafoliosEspecificos();
    //this.getCombos();
  }

  /*Metodo usado para setear los controles de seguridad*/
  setControlesSeguridad(): void {
     this.controlSeguridadService.setSeguridadControles()
             .subscribe(data=> {
               this.controlesseguridad = data;
     });
  }

  /*Metodo consumidor para traer controles  de seguridad*/
  getControlesSeguridad(): void {
    this.controlSeguridadService.getSeguridadControles(this.pathsend)
        .subscribe(controleseguridad => {
             this.listcontroleseguridad = controleseguridad;
        });
  }

  setPermisos(filter:string){
      let data = Array.of(this.listcontroleseguridad);
      var booEstado;
      data.forEach(function (value) {
          if(value != undefined){
               booEstado = value.find(function(element) {
                  return element.descripcion == filter ? true : false;
              });
          }
      })
      if(booEstado===false || booEstado==undefined ) return false;
      return true;
  }

  /*Lista los portafolios especificos*/
  getListPortafoliosEspecificos(): void {
      this.portafolioEspecificoService.getPortafolioEspecifico()
      .subscribe(
            portafoliosespecificos => {
            this.listPortafoliosEspecificos = portafoliosespecificos;
            this.listPortafoliosEspecificos_aux = portafoliosespecificos;
            this.combosClientes  = this.onlyUnique(this.listPortafoliosEspecificos,'ID_CLIENTE');
            this.combosOts       = this.onlyUnique(this.listPortafoliosEspecificos,'OT');
      });
  }

  /*Metodo que controla el cambio del cliente*/
  changeCliente(){
    this.selectedOTsClientes = this.combosClientes.filter(o=> !!this.selectedClientesOts.find(x => x.ID_CLIENTE == o.ID_CLIENTE ));
  }

  /*Metodo que controla el cambio de OT*/
  changeOT(){
    this.selectedClientesOts = this.combosOts.filter(o=> !!this.selectedOTsClientes.find(x => x.OT == o.OT ));
  }

  /*Metodo para buscar los portafolios especificos*/
  searchPortaFolios(){
     this.listPortafoliosEspecificos = this.listPortafoliosEspecificos_aux;

     if(this.selectedClientesOts.length  != 0)
     {
      this.selectedOTsClientes = this.combosClientes.filter(o=> !!this.selectedClientesOts.find(x => x.ID_CLIENTE == o.ID_CLIENTE ));
      this.listPortafoliosEspecificos = this.listPortafoliosEspecificos.filter(o=> !!this.selectedOTsClientes.find(x => x.OT == o.OT ));
     }

     if (this.selectedOTsClientes.length != 0)
    {
      this.listPortafoliosEspecificos = this.listPortafoliosEspecificos.filter(o=> !!this.selectedOTsClientes.find(x => x.OT == o.OT ));

    }

    if(this.selectedEstados.length != 0)
    {
      this.listPortafoliosEspecificos = this.listPortafoliosEspecificos.filter(o=> !!this.selectedEstados.find(x => x.id == o.ESTADO ));
    }
  }

  /*Trae los combos*/
  getCombos(): void {
    this.parametrizacionFechasService.getCombos()
    .subscribe(
          combos => {
          this.combos = combos;
          this.combosClientes  = this.onlyUnique(this.combos,'id_cliente');
          this.combosOts = this.onlyUnique(this.combos,'ot');
    });
  }

  /*Retorna datos unicos segun campo proporcionado*/
  onlyUnique(arraydata : Array<any> , field:string) : any[] {
     var unique = new Array();
     var resul = new Array();

     arraydata.forEach(function (value) {
          unique.push(value[field])
     });

    var uniqueFinal = unique.filter(function(elem, index, self) {
      return index === self.indexOf(elem);
    });

    uniqueFinal.forEach(function (datos) {
        var row = arraydata.find(function(element) {
              return element[field] ==  datos;
        });
        resul.push(row);
    });
    return resul;
  }

  /**Se obtiene el listado ,de todos los portafolios especificos*/
  getFichasPortafolioEspecifico():void{
    this.fichaTecnicaService.getFichasPortafolioEspecifico()
      .subscribe(portafoliosespecificos =>{
          if(portafoliosespecificos.hasOwnProperty("mensaje")){
              console.log("Datos");
              this.mensaje_error=portafoliosespecificos['mensaje'];
              this.mensajeNotificacion(this.mensaje_error);
              //this.openModal();
              return;
          }
          this.portafoliosespecificos = portafoliosespecificos;
      });
  }

  //Funcion de salida del sistema
  public logout(){
    this.authService.logout();
    this.menuEstadoService.setMenuEstado(false);
    $('#totalizado').html('0');
    let redirect = this.authService.redirectUrl ? this.authService.redirectUrl : '/login';
    let navigationExtras: NavigationExtras = {
      queryParamsHandling: 'preserve',
      preserveFragment: true
    };
    // Redirect the user
    this.router.navigate([redirect], navigationExtras);
  }

  /*Metodo abre dialogo para reportar errores*/
  openModal(){
      this.display='block';
  }

  /*Metodo cierra dialogo de reporte de errores*/
  onCloseHandled(){
       this.display='none';
  }

  mensajeNotificacion(mensaje: string) {
    const dialogo = this.modalConfirmacion('AVISO', mensaje, 'Aceptar', false);
    dialogo.componentInstance.confirmacionCallback.subscribe(resultado => {
      dialogo.close();
    })
  }

  modalConfirmacion(titulo: string, mensaje: string, etiquetaConfirmacion: string, verCancelar = true) {
    let data = {
      titulo: titulo,
      mensaje: mensaje,
      etiquetaConfirmacion: etiquetaConfirmacion,
      verCancelar: verCancelar,
    }
    return this.dialog.open(AlertsComponent, { data: data });
  }

  orderBy_clientOTCompanyUN(orderby: number) {
    this.listPortafoliosEspecificos = this.listPortafoliosEspecificos_aux;
    if (orderby === 1) {
      this.listPortafoliosEspecificos.sort(function (obj1, obj2) {
        // Ascending:
          return obj1['NOMBRE_CLIENTE'] === null ? ''.localeCompare(obj1['NOMBRE_CLIENTE'] == null?'':obj1['NOMBRE_CLIENTE']):obj1['NOMBRE_CLIENTE'].localeCompare(obj2['NOMBRE_CLIENTE'] == null ? '':obj2['NOMBRE_CLIENTE']);
      });
    } else if (orderby === 2) {
      this.listPortafoliosEspecificos = this.listPortafoliosEspecificos_aux;
    } else if (orderby === 4) {
      this.listPortafoliosEspecificos.sort(function (obj1, obj2) {
        // Ascending:
          return obj1['ID_UNIDAD'] === null ? ''.localeCompare(obj1['ID_UNIDAD'] == null?'':obj1['ID_UNIDAD']):obj1['ID_UNIDAD'].localeCompare(obj2['ID_UNIDAD'] == null ? '':obj2['ID_UNIDAD']);
      });
    }
  }

  orderBy_ot () {
    this.listPortafoliosEspecificos = this.listPortafoliosEspecificos_aux;
    this.listPortafoliosEspecificos.sort(function (obj1, obj2) {
      // Ascending:
      return parseFloat(obj1['OT']) - parseFloat(obj2['OT']);
    });
  }

  //Realiza ordenamiento por filtros del listado de portafolios
  ordenarPor(): void {
    if (this.selectedOrderBy.length !== 0) {
      if (this.selectedOrderBy['id'] === 1) {
        this.orderBy_clientOTCompanyUN(1);
      } else if (this.selectedOrderBy['id'] === 2) {
        this.orderBy_clientOTCompanyUN(2);
      } else if (this.selectedOrderBy['id'] === 4) {
        this.orderBy_clientOTCompanyUN(4);
      } else {
        this.orderBy_ot();
      }
    }
  }
}

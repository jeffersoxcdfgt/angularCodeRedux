import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PortafolioEspecificoComponent } from './portafolio-especifico.component';

describe('PortafolioEspecificoComponent', () => {
  let component: PortafolioEspecificoComponent;
  let fixture: ComponentFixture<PortafolioEspecificoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PortafolioEspecificoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PortafolioEspecificoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

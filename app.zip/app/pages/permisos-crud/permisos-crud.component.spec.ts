import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PermisosCrudComponent } from './permisos-crud.component';

describe('PermisosCrudComponent', () => {
  let component: PermisosCrudComponent;
  let fixture: ComponentFixture<PermisosCrudComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PermisosCrudComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PermisosCrudComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

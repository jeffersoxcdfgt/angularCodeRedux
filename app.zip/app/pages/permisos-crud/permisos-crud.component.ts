import { Component, OnInit ,Input ,TemplateRef , ViewChild , ElementRef ,OnChanges, SimpleChanges } from '@angular/core';
import { FormGroup, FormBuilder, Validators ,FormControl ,FormArray , AbstractControl } from '@angular/forms';
import { PERMISOS } from '../../mocks/mock-permiso';
import { Permiso } from '../../class/permiso';
import { PermisoService } from '../../service/permiso/permiso.service';
import { Validation } from '../../validation/validation';
import { OrderPipe } from 'ngx-order-pipe';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ValidationService } from '../../service/validation/validation.service';
import { AuthService }  from '../../service/auth/auth.service';
import { Router,NavigationExtras } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';
import { MenuEstadoService } from '../../service/menu-estado/menu-estado.service';
import { AlertsComponent } from '../../utils/alerts/alerts.component';
import { MatDialog } from '@angular/material';

class OptPages {
  id: number;
  value: string;
  label : string;
  selected : string;
};

@Component({
  selector: 'app-permisos-crud',
  templateUrl: './permisos-crud.component.html',
  styleUrls: ['../../../assets/css/main.css',
              './permisos-crud.component.css']
})
export class PermisosCrudComponent implements OnInit {
  permisos: Permiso[];
  display='none';
  idDelete:string;
  form: FormGroup;
  data: Permiso;
  OpNameValue = 'add';
  order: string = 'id';
  reverse: boolean = true;
  public modalRef: BsModalRef;
  template: TemplateRef<any>
  mensaje_error:string;
  p:any;
  idx: any;
  selectedRangePage: OptPages[] = [
    { id: 1, value: '10'  , label:'10',   selected : 'selected' },
    { id: 2, value: '20' , label:'20',  selected : ''},
    { id: 3, value: '30' , label:'30',  selected : '' }
  ];
  perpageitem: number = 10;

  constructor(private formBuilder: FormBuilder,
              private permisoService: PermisoService,
              private validationService :ValidationService,
              private orderPipe: OrderPipe,
              private modalService: BsModalService,
              private authService: AuthService,
              private router: Router,
              private menuEstadoService: MenuEstadoService,
              public dialog: MatDialog
              ) { }

 /*Llamada a metodo de consumo de permisos*/
  ngOnInit() {
    this.permisos = this.orderPipe.transform(this.permisos, 'id');
    this.setPermisos();
    this.getPermisos();
    this.form = this.formBuilder.group({
      grupo: this.formBuilder.group({
        permisonombre: [null, Validators.required,this.validSpaceBlank]
      })
    })
  }

  //Valida no permite espacios en blanco
  validSpaceBlank(control: AbstractControl) {
      var pattern = /^\s+$/;
      return Observable.of(pattern.test(control.value)).pipe(
        map(result => result ? { invalid: true } : null)
      );
  }

  /*Open modal en permisos*/
  public openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);
  }

  /*Lista los permisos buscados*/
  searchPermisos(term :string):void {
    this.permisoService.searchPermisos(term)
    .subscribe(permisos =>{
        this.permisos = permisos;
    });
  }

  /*Metodo usado para setear permisos*/
  setPermisos(): void {
   this.permisoService.setPermisos()
       .subscribe(data=> this.data = data);
  }

  /*Ordenar permisos*/
  setOrder(value: string) {
    if (this.order === value) {
      this.reverse = !this.reverse;
    }
    this.order = value;
  }

  /*Metod consumidor para traer permisos*/
  getPermisos(): void {
    this.permisoService.getPermisos()
      .subscribe(permisos => this.permisos = permisos);
  }

  /*Metodo accion para agregar permisos*/
  add(template: TemplateRef<any>): void {
      if(this.OpNameValue  === 'edit'){
        this.permisoService.updatePermiso(this.data)
          .subscribe(permiso => {
              var index = this.permisos.findIndex(obj => obj.id== permiso.id);
              this.permisos[index] = permiso;
              this.mensaje_error ='Permiso editado satisfactoriamente.';
              this.mensajeNotificacion(this.mensaje_error);
              //this.openModal(template);
              this.form.reset();
          });
        this.OpNameValue  = 'add';
        return;
      }

      this.permisoService.addPermiso(this.data)
        .subscribe(permiso => {
          this.permisos.push(permiso);
          this.permisos = this.orderPipe.transform(this.permisos, 'id');
          this.mensaje_error ='Permiso agregado satisfactoriamente.';
          this.mensajeNotificacion(this.mensaje_error);
          //this.openModal(template);
          this.form.reset();
      });
  }

   /*Metodo accion para borrar permisos*/
   delete(id: string): void {
     this.permisoService.deletePermiso( { id } as Permiso ).
         subscribe( permiso => {
           var index = this.permisos.findIndex(obj => obj.id==id);
           this.permisos.splice(index,1);
         });
     this.display='none';
   }

   /*Metodo accion para editar permisos*/
   save( permiso : Permiso): void {
      this.data = Object.assign({},permiso);
      this.OpNameValue ='edit';
      this.animateScrollTop("30%");
   }


  /*Metodo abre dialogo de confirmacion de borrado*/
  openModalDelete(id:string){
      //this.display='block';
      this.idDelete=id;
      this.mensajeEliminacion('Desea borrar el registro?');
  }

  /*Metodo cierra dialogo de confirmacion de borrado*/
  onCloseHandledDelete(){
       this.display='none';
  }

  /*Selecccion tipo de operacion*/
  /*typeOperation (objeto: any): void {
     (typeof objeto === 'string' && this.add())  || (typeof objeto === 'object' && this.save(objeto))
  }*/

   //Limpia elementos del array
   clearData()  {
      for (let key of Object.keys(this.data)) {
        eval(  "this.data." +key+"=''");
      }
   }

  /*Se inician metodos de validacion*/
  isFieldValid(field: string) {
  return !this.form.get(field).valid && this.form.get(field).touched;
  }

  /*Envia datos*/
  onSubmit(template: TemplateRef<any>) {
    if (this.form.valid) {
          this.add(template);
    } else {
      this.validateAllFormFields(this.form);
    }
  }

  displayFieldCss(field: string) {
  return {
    'has-error': this.isFieldValid(field),
    'has-feedback': this.isFieldValid(field)
   };
  }

  validateAllFormFields(formGroup: FormGroup) {
  Object.keys(formGroup.controls).forEach(field => {
    console.log(field);
    const control = formGroup.get(field);
    if (control instanceof FormControl) {
      control.markAsTouched({ onlySelf: true });
    } else if (control instanceof FormGroup) {
      this.validateAllFormFields(control);
    }
  });
  }

  /*Limpia formulario*/
  reset() {
    this.form.reset();
    this.OpNameValue ='add';
  }

  public logout(){
    this.authService.logout();
    this.menuEstadoService.setMenuEstado(false);
    $('#totalizado').html('0');
    let redirect = this.authService.redirectUrl ? this.authService.redirectUrl : '/login';
    let navigationExtras: NavigationExtras = {
      queryParamsHandling: 'preserve',
      preserveFragment: true
    };
    // Redirect the user
    this.router.navigate([redirect], navigationExtras);
  }

  onChangePages(newValue){
    this.perpageitem = newValue;
  }

  animateScrollTop(px) {
    $('html, body').animate({
      scrollTop: px
    }, 'slow');
  }

  mensajeNotificacion(mensaje: string) {
    const dialogo = this.modalConfirmacion('AVISO', mensaje, 'Aceptar', false);
    dialogo.componentInstance.confirmacionCallback.subscribe(resultado => {
      dialogo.close();
    })
  }

  mensajeEliminacion(mensaje: string) {
    const dialogo = this.modalConfirmacion('AVISO', mensaje, 'Aceptar');
    dialogo.componentInstance.confirmacionCallback.subscribe(resultado => {
      this.delete(this.idDelete);
      dialogo.close();
    })
  }

  modalConfirmacion(titulo: string, mensaje: string, etiquetaConfirmacion: string, verCancelar = true) {
    let data = {
      titulo: titulo,
      mensaje: mensaje,
      etiquetaConfirmacion: etiquetaConfirmacion,
      verCancelar: verCancelar,
    }
    return this.dialog.open(AlertsComponent, { data: data });
  }
}

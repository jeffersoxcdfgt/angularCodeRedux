import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DetallePortafolioEspecificoComponent } from './detalle-portafolio-especifico.component';

describe('DetallePortafolioEspecificoComponent', () => {
  let component: DetallePortafolioEspecificoComponent;
  let fixture: ComponentFixture<DetallePortafolioEspecificoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetallePortafolioEspecificoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetallePortafolioEspecificoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

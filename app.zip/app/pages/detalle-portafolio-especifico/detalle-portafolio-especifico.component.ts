import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location , DatePipe } from '@angular/common';
import { Router,NavigationExtras, UrlTree , UrlSegment ,UrlSegmentGroup , PRIMARY_OUTLET  } from '@angular/router';
import { AuthService }  from '../../service/auth/auth.service';
import { MenuEstadoService } from '../../service/menu-estado/menu-estado.service';
import { Portafolioespecifico , RenderPortaFolioEspecifico,RenderProductos,RenderFechas , MONTH } from '../../class/portafolio-especifico';
import { PortafolioEspecificoService }  from '../../service/portafolio-especifico/portafolio-especifico.service';
import { ListaDesplegableComponent } from '../../lista-desplegable/lista-desplegable.component';
import { FichaTecnicaService } from '../../service/ficha-tecnica/ficha-tecnica.service';
import { MatDialog } from '@angular/material';
import { AlertsComponent } from '../../utils/alerts/alerts.component';
import { SpinerCargandoComponent } from '../../utils/spiner-cargando/spiner-cargando.component';
import { CONTROLESEGURIDAD } from '../../mocks/mock-control-seguridad';
import { ControlesSeguridad } from '../../class/controles_seguridad';
import { ControlSeguridadService } from '../../service/control-seguridad/control-seguridad.service';
import { getPathToSend , getOperations } from '../../utils/utils';

@Component({
  selector: 'app-detalle-portafolio-especifico',
  templateUrl: './detalle-portafolio-especifico.component.html',
  styleUrls: ['../../../assets/css/main.css',
    './detalle-portafolio-especifico.component.css']
})
export class DetallePortafolioEspecificoComponent implements OnInit {

  @ViewChild('ctrClientes') ctrClientes: ListaDesplegableComponent;
  @ViewChild('ctrOts') ctrOts: ListaDesplegableComponent;
  @ViewChild('ctrCategorias') ctrCategorias: ListaDesplegableComponent;
  @ViewChild('ctrFacturacion') ctrFacturacion: ListaDesplegableComponent;
  @ViewChild('ctrCargos') ctrCargos: ListaDesplegableComponent;
  @ViewChild('ctrFrecuencias') ctrFrecuencias: ListaDesplegableComponent;
  @ViewChild('ctrAno') ctrAno: ListaDesplegableComponent;

  clientesItem = [];
  otItem = [];
  cargosItem = [];
  categoriasItem = [];
  frecuenciasItem = [];
  ano: any[];
  fecha = new Date();

  public portafoliodetalle:any[];
  public detalleportaEnc:any[];
  public renderPortaFolioEspecifico:RenderPortaFolioEspecifico;
  public renderPortaFolioEspecificoAll:Array<RenderPortaFolioEspecifico>;
  public resAll:Array<RenderPortaFolioEspecifico>;
  public p:any;
  public fechas_string:string;

  public enero:string;
  public febrero:string;
  public marzo:string;
  public abril:string;
  public mayo:string;
  public junio:string;
  public julio:string;
  public agosto:string;
  public septiembre:string;
  public octubre:string;
  public noviembre:string;
  public diciembre:string;
  //Security variables
  pathsend :string;
  controlesseguridad : ControlesSeguridad;
  listcontroleseguridad :ControlesSeguridad[];
  //Security variables

  constructor(private route: ActivatedRoute,
              private router: Router,
              private authService: AuthService,
              private menuEstadoService: MenuEstadoService,
              private portafolioEspecificoService: PortafolioEspecificoService,
              private _router: ActivatedRoute,
              private location: Location,
              public dialog: MatDialog,
              private controlSeguridadService :ControlSeguridadService,
            ) {
              //this.getDataAll();
              this.years();
              this.pathsend=getPathToSend(router.parseUrl(location.path()));
            }

  ngOnInit() {
    const ot  = +this.route.snapshot.paramMap.get('id');
    this.getPortafolioEspecificoID(ot);
    this.setControlesSeguridad();
    this.getControlesSeguridad();
    this.getDataAll();
  }


  /*Metodo usado para setear los controles de seguridad*/
  setControlesSeguridad(): void {
     this.controlSeguridadService.setSeguridadControles()
        .subscribe(data=> {
         this.controlesseguridad = data;
     });
  }

  /*Metodo consumidor para traer controles  de seguridad*/
  getControlesSeguridad(): void {
    this.controlSeguridadService.getSeguridadControles(this.pathsend)
        .subscribe(controleseguridad => {
        this.listcontroleseguridad = controleseguridad;
      });
  }

  setPermisos(filter:string){
      let data = Array.of(this.listcontroleseguridad);
      var booEstado;
      data.forEach(function (value) {
          if(value != undefined){
               booEstado = value.find(function(element) {
                  return element.descripcion == filter ? true : false;
              });
          }
      })
      if(booEstado===false || booEstado==undefined ) return false;
      return true;
  }

  getDatesForMonth(fechas_entrega:Array<RenderFechas> , month:number) : boolean {
     this.fechas_string ="";

     let fechas_x_month = fechas_entrega.filter(function(element, index, self) {
            var monthloop = new Date(element.ENTREGA);
            return (monthloop.getMonth()+1) == (month);
     });

     if(fechas_x_month.length > 0){
         fechas_x_month.forEach(val=>{
              var day = new Date(val.ENTREGA);
              this.fechas_string+=day.getDate()+',';
         });

         let fechas = this.fechas_string.replace(/,+$/,'');
         switch(month){
           case MONTH.enero     : this.enero=fechas;break;
           case MONTH.febrero   : this.febrero=fechas;break;
           case MONTH.marzo     : this.marzo=fechas;break;
           case MONTH.abril     : this.abril=fechas;break;
           case MONTH.mayo      : this.mayo=fechas;break;
           case MONTH.junio     : this.junio=fechas;break;
           case MONTH.julio     : this.julio=fechas;break;
           case MONTH.agosto     :this.agosto=fechas;break;
           case MONTH.septiembre :this.septiembre=fechas;break;
           case MONTH.octubre   : this.octubre=fechas;break;
           case MONTH.noviembre : this.noviembre=fechas;break;
           case MONTH.diciembre : this.diciembre=fechas;break;
         }
         return true;
     }
     return false;
  }

  /*Metodo consumidor ,para traer los detalles de los portafolios*/
  getPortafolioEspecificoID( ot:number ): void {
    this.portafolioEspecificoService.getPortafolioEspecificoID(ot)
      .subscribe(portafoliodetalle =>{
          this.portafoliodetalle = portafoliodetalle;
          this.resAll=this.processPortafolio(this.portafoliodetalle);
      });
  }

   getRefCross(id_cargo:string , field:string , res:string) : string {
     var found = this.portafoliodetalle.find(function(element) {
        return element[field] == id_cargo;
     });
     return found[res];
   }

   getProducto(id_cargo:string , field:string) : string {
     var found = this.portafoliodetalle.find(function(element) {
        return element[field] == id_cargo;
     });
     return found
   }

   uniqueKeys(arraydata : Array<any>, ...args){
      var unique = new Array();
      var resul = new Array();
      var charsplit='~';
      // ->  /~+$/,''

      arraydata.forEach( value => {
          var valueField='';
          args.forEach (field => {
               valueField +=value[field]+charsplit;
          });
          var valueRtrim=valueField.replace(/~+$/,'');
          unique.push(valueRtrim);
      });

      var uniqueFinal = unique.filter(function(elem, index, self) {
          return index === self.indexOf(elem);
      });

      uniqueFinal.forEach(value =>{
          resul.push(value.split(charsplit));
      });

      return resul;
   }

  /*Retorna datos unicos segun campo proporcionado*/
  processPortafolio(arraydata : Array<any>) : Array<RenderPortaFolioEspecifico> {
     var cargosxcategoria = new Array();
     var cargosxcategoriaxpro = new Array();
     var cargosxcategoriaxproent = new Array();
     this.renderPortaFolioEspecificoAll= new Array<RenderPortaFolioEspecifico>();

     cargosxcategoria = this.uniqueKeys(arraydata , "ID_CARGO","ID_CATEGORIA");
     cargosxcategoriaxpro = this.uniqueKeys(arraydata , "ID_CARGO","ID_CATEGORIA","ID_ARTICULO");
     cargosxcategoriaxproent = this.uniqueKeys(arraydata , "ID_CARGO","ID_CATEGORIA","ID_ARTICULO","ENTREGA");

     cargosxcategoria.forEach( cargoxcate => {
          this.renderPortaFolioEspecifico = new RenderPortaFolioEspecifico;
          this.renderPortaFolioEspecifico.ID_CARGO = cargoxcate[0];
          this.renderPortaFolioEspecifico.ID_CATEGORIA = cargoxcate[1];
          this.renderPortaFolioEspecifico.DESCRIPCION_CARGO =  this.getRefCross(cargoxcate[0],'ID_CARGO','DESCRIPCION_CARGO');
          this.renderPortaFolioEspecifico.DESCRIPCION_CATEGORIA = this.getRefCross(cargoxcate[1],'ID_CATEGORIA','DESCRIPCION_CATEGORIA');;
          //Productos
          var rowproductos = cargosxcategoriaxpro.filter(function(element, index, self) {
               return (
                    (element[0] == cargoxcate[0]) &&
                    (element[1] == cargoxcate[1])
               );
         });

         this.renderPortaFolioEspecifico.articulos = new Array<RenderProductos>();
         rowproductos.forEach(res =>{
             let varproducto = new RenderProductos;
             varproducto.ID_ARTICULO =res[2];
             var datos_producto = this.getProducto(res[2],'ID_ARTICULO');
             varproducto.DESCRIPCION_ARTICULO= datos_producto['DESCRIPCION_ARTICULO'];
             varproducto.VENTA= datos_producto['VENTA'];
             varproducto.COSTO= datos_producto['COSTO'];
             varproducto.CONSUMO_X_PERSONA= datos_producto['CONSUMO_POR_PERSONA'];
             varproducto.PEDIDO_X_ENTREGA= datos_producto['PEDIDO_POR_ENTREGA'];
             varproducto.ID_TIPO_FACTURACION= datos_producto['ID_TIPO_FACTURACION'];
             varproducto.TIPO_FACTURACION= datos_producto['TIPO_FACTURACION'];
             varproducto.fechas_entrega =new Array<RenderFechas>();
             //Fechas de entrega
              var rowfechas = cargosxcategoriaxproent.filter(function(element, index, self) {
                   return (
                        (element[0] == res[0]) &&
                        (element[1] == res[1]) &&
                        (element[2] == res[2])
                   );
              });

              rowfechas.forEach( fechas =>{
                  let resfechas = new RenderFechas;
                  resfechas.ENTREGA = fechas[3];
                  varproducto.fechas_entrega.push(resfechas);
              });

              this.renderPortaFolioEspecifico.articulos.push(varproducto);
         });
         this.renderPortaFolioEspecificoAll.push(this.renderPortaFolioEspecifico);
     });

     return this.renderPortaFolioEspecificoAll;
  }

  //Funcion de salida del sistema
  public logout(){
    this.authService.logout();
    this.menuEstadoService.setMenuEstado(false);
    $('#totalizado').html('0');
    let redirect = this.authService.redirectUrl ? this.authService.redirectUrl : '/login';
    let navigationExtras: NavigationExtras = {
      queryParamsHandling: 'preserve',
      preserveFragment: true
    };
    this.router.navigate([redirect], navigationExtras);
  }

  /* Para los filtros */
  getDataAll(){
    this.portafolioEspecificoService.getOTClientes()
      .subscribe(resp => {
        this.clientesItem = resp.clientes;
        this.otItem = resp.ot;
        this.setOT(this._router.snapshot.paramMap.get('id'));
      });
  }

  public clienteChange(event){
    this.ctrOts.selectedItem = [];
    this.ctrCargos.selectedItem = [];
    this.ctrCategorias.selectedItem = [];
    this.ctrFrecuencias.selectedItem = [];
    this.ctrCargos.items = [];
    this.ctrCategorias.items = [];
    this.ctrFrecuencias.items = [];
    if(event == null){
      this.ctrOts.selectedItem = [];
      this.ctrOts.items = this.otItem;
    }
    else{
      this.ctrOts.items = this.otItem.filter(x=>x.ID_CLIENTE == event.NIT);
      if(this.otItem.filter(x=>x.ID_CLIENTE == event.NIT)["length"] == 1){
        //this.ctrOts.selectedItem = this.otItem.filter(x=>x.ID_CLIENTE == event.NIT)[0]['ID_OT'];
        this.ctrOts.selectedItem = this.otItem.find(x=>x.ID_CLIENTE == event.NIT);
        this.getDataFiltros(this.otItem.find(x=>x.ID_CLIENTE == event.NIT)['ID_OT']);
      }
    }

  }

  public otChange(event){
    this.ctrClientes.selectedItem = [];
    this.ctrCargos.selectedItem = [];
    this.ctrCategorias.selectedItem = [];
    this.ctrFrecuencias.selectedItem = [];
    this.ctrCargos.items = [];
    this.ctrCategorias.items = [];
    this.ctrFrecuencias.items = [];
    if(event == null){
      this.ctrClientes.selectedItem = [];
      this.ctrClientes.items = this.clientesItem;
    }
    else{
      this.ctrClientes.selectedItem = this.clientesItem.find(x=>x.NIT == event.ID_CLIENTE);
      this.getDataFiltros(event.ID_OT);
    }
  }

  getDataFiltros(ot){
    this.portafolioEspecificoService.getFiltrosPortafolioEspecifico(ot)
      .subscribe(resp => {
        this.cargosItem = resp.cargos;
        this.categoriasItem = resp.categorias;
        this.frecuenciasItem = resp.frecuencias;

        this.ctrCargos.items = resp.cargos;
        this.ctrCategorias.items = resp.categorias;
        this.ctrFrecuencias.items = resp.frecuencias;
      });
  }

  public years(){
    this.ano = [
      {id: this.fecha.getFullYear()-4, value: this.fecha.getFullYear()-4},
      {id: this.fecha.getFullYear()-3, value: this.fecha.getFullYear()-3},
      {id: this.fecha.getFullYear()-2, value: this.fecha.getFullYear()-2},
      {id: this.fecha.getFullYear()-1, value: this.fecha.getFullYear()-1},
      {id: this.fecha.getFullYear(), value: this.fecha.getFullYear()},
      {id: this.fecha.getFullYear()+1, value: this.fecha.getFullYear()+1},
      {id: this.fecha.getFullYear()+2, value: this.fecha.getFullYear()+2},
      {id: this.fecha.getFullYear()+3, value: this.fecha.getFullYear()+3},
      {id: this.fecha.getFullYear()+4, value: this.fecha.getFullYear()+4}];
  }

  public setOT(ot){
    let otrow = this.otItem.filter(x=>x.ID_OT== ot);
    if (this.ctrOts.selectedItem  === undefined) {
      this.ctrOts.selectedItem = [];
    }
    this.ctrOts.selectedItem = otrow[0];
    this.ctrClientes.selectedItem = this.clientesItem.find(x=>x.NIT == otrow[0]['ID_CLIENTE']);
    this.getDataFiltros(ot);
  }

  public getDetallePortafolioEsp(){
    if(this.ctrOts.selectedItem["ID_OT"] != null){
      let searchDatos = {
        'ot' : this.ctrOts.selectedItem["ID_OT"],
        'id_categoria' : (this.ctrCategorias.selectedItem != null)?this.ctrCategorias.selectedItem.map(x => x.ID_CATEGORIA).toString():null,
        'id_cargo' : (this.ctrCargos.selectedItem != null)?this.ctrCargos.selectedItem.map(x => x.ID_CARGO).toString():null,
        'id_frecuencia': (this.ctrFrecuencias.selectedItem != null)?this.ctrFrecuencias.selectedItem.map(x => x.ID_FRECUENCIA).toString():null,
        'ano': (this.ctrAno.selectedItem != null)?this.ctrAno.selectedItem['id']:null
      }
      this.portafolioEspecificoService.getDetallePE(searchDatos)
        .subscribe(portafoliodetalle => {
          if(portafoliodetalle.length == 0){
            const dialogo = this.modalConfirmacion('No existe', 'No se encontrarón registros', 'Aceptar',false);
            dialogo.componentInstance.confirmacionCallback.subscribe(resultado=>{dialogo.close();})
          }
          this.portafoliodetalle = portafoliodetalle;
          this.resAll=this.processPortafolio(this.portafoliodetalle);

        });
    }else{
      this.mensajeNotificacion('Debe seleccionar una OT');
    }
  }

  mensajeNotificacion(mensaje: string){
    const dialogo = this.modalConfirmacion('AVISO', mensaje, 'Aceptar',false);
    dialogo.componentInstance.confirmacionCallback.subscribe(resultado=>{
      dialogo.close();
    })
   }

   modalConfirmacion(titulo: string, mensaje: string, etiquetaConfirmacion: string, verCancelar = true){
    let data = {
      titulo: titulo,
      mensaje: mensaje,
      etiquetaConfirmacion: etiquetaConfirmacion,
      verCancelar: verCancelar
    }
    return this.dialog.open(AlertsComponent,{data: data});
  }
  lanzarLoading(){
    return this.dialog.open(SpinerCargandoComponent,{data: [], disableClose: true});
  }

  //Ir a ficha tecnica
  goFicha(){
    if(this.ctrOts.selectedItem ['ID_OT'] == undefined)
    {
      const dialogo = this.modalConfirmacion('AVISO', "Debe seleccionar una OT", 'Aceptar',false);
      dialogo.componentInstance.confirmacionCallback.subscribe(resultado=>{
        dialogo.close();
      })
    }
    else
      this.router.navigate(['./ficha-tecnica/'+this.ctrOts.selectedItem ['ID_OT']])
  }
}

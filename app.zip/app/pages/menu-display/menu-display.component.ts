import { Component, OnInit , ViewEncapsulation } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MenuDisplayService } from '../../service/menu-display/menu-display.service';
import { MenuEstadoService } from '../../service/menu-estado/menu-estado.service';
import 'rxjs/add/operator/map';
import * as $ from 'jquery';


@Component({
  selector: 'app-menu-display',
  templateUrl: './menu-display.component.html',
  styleUrls: [
            './menu-display.component.css'],
  providers: [MenuDisplayService],
})
export class MenuDisplayComponent implements OnInit {

  public list: any[];
  contador=0;

  constructor(private menuDisplayService: MenuDisplayService,
              private menuEstadoService: MenuEstadoService)
  { }

  ngOnInit() {
    if(!this.menuEstadoService.getMenuEstado()){
       this.getDisplayMenu();
    }
    else{
      this.list = this.menuEstadoService.getList();
    }
  }

  /* GET Se invoca el servicio para consumir las opciones de menu*/
  getDisplayMenu(): void {
    this.menuDisplayService.getDisplayMenu()
        .subscribe(
            list => {
              this.list = list;
              if(this.list.length > 0 && !this.menuEstadoService.getMenuEstado()){
                  this.menuEstadoService.setMenuEstado(true);
                  this.menuEstadoService.setList(this.list);
              }
      });
  }
}

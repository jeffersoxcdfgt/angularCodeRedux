import { Component, OnInit ,Input } from '@angular/core';
import { Rol } from '../../class/rol';
import { RolService } from '../../service/rol/rol.service';
import { Validation } from '../../validation/validation';
import { ValidationService } from '../../service/validation/validation.service';
import { AlertsComponent } from '../../utils/alerts/alerts.component';
import { MatDialog } from '@angular/material';

@Component({
  selector: 'app-roles-crud',
  templateUrl: './roles-crud.component.html',
  styleUrls: ['../../../assets/css/main.css',
              './roles-crud.component.css']
})

export class RolesCrudComponent implements OnInit {
  roles: Rol[];
  display='none';
  idDelete:string;
  OpNameValue = 'add';
  data: Rol;
  p:any;

  constructor(private rolService: RolService,
              private validationService :ValidationService,
              public dialog: MatDialog) {}


  /*Llamada a metodo de consumo de roles*/
  ngOnInit() {
    this.setRoles();
    this.getRoles();
  }

  /*Metodo usado para setear roles*/
  setRoles(): void {
   this.rolService.setRoles()
       .subscribe(data=> this.data = data);
  }

  /*Metodo consumidor para traer roles*/
  getRoles(): void {
    this.rolService.getRoles()
    .subscribe(roles => this.roles = roles);
  }

  /*Metodo accion para agregar roles*/
  add(): void {
      this.rolService.addRol(this.data)
        .subscribe(rol => {
            var index = this.roles.findIndex(obj => obj.id==this.data.id);
            (this.OpNameValue  === 'add' && this.roles.push(rol))  || ( this.OpNameValue  === 'edit' && (this.roles[index] = rol));
             this.OpNameValue='add';
      });
  }

 /*Metodo accion para borrar roles*/
  delete(id: string): void {
    this.rolService.deleteRol( { id } as Rol ).
        subscribe( rol => {
          var index = this.roles.findIndex(obj => obj.id==id);
          this.roles.splice(index,1);
        });
    this.display='none';
  }

  /*Metodo accion para editar roles*/
  save( rol : Rol): void {
     this.data = rol;
     this.OpNameValue ='edit';
  }

  /*Metodo abre dialogo de confirmacion de borrado*/
  openModalDelete(id:string){
      //this.display='block';
      this.idDelete=id;
      this.mensajeEliminacion('Desea borrar el registro?');
  }

  /*Metodo cierra dialogo de confirmacion de borrado*/
  onCloseHandledDelete(){
       this.display='none';
  }

  /*Selecccion tipo de operacion*/
  typeOperation (objeto: any): void {
     (typeof objeto === 'string' && this.add())  || (typeof objeto === 'object' && this.save(objeto))
  }

   //Limpia elementos del array
   clearData()  {
      for (let key of Object.keys(this.data)) {
        eval(  "this.data." +key+"=''");
      }
   }

   mensajeNotificacion(mensaje: string) {
    const dialogo = this.modalConfirmacion('AVISO', mensaje, 'Aceptar', false);
    dialogo.componentInstance.confirmacionCallback.subscribe(resultado => {
      dialogo.close();
    })
  }

  mensajeEliminacion(mensaje: string) {
    const dialogo = this.modalConfirmacion('AVISO', mensaje, 'Aceptar');
    dialogo.componentInstance.confirmacionCallback.subscribe(resultado => {
      this.delete(this.idDelete);
      dialogo.close();
    })
  }

  modalConfirmacion(titulo: string, mensaje: string, etiquetaConfirmacion: string, verCancelar = true) {
    let data = {
      titulo: titulo,
      mensaje: mensaje,
      etiquetaConfirmacion: etiquetaConfirmacion,
      verCancelar: verCancelar,
    }
    return this.dialog.open(AlertsComponent, { data: data });
  }

}

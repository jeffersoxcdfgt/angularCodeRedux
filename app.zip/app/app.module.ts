import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { ModalModule } from 'ngx-bootstrap/modal';
import { HttpModule } from '@angular/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { FormsModule , ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule }    from '@angular/common/http';
import { AppComponent } from './app.component';
import { MessageService } from './service/message/message.service';
import { MessagesComponent } from './messages/messages.component';
import { LoginComponent } from './login/login.component';
import { LoginRecoveryComponent } from './login-recovery/login-recovery.component';
import { AppRoutingModule } from './app-routing.module';
import { LoginRecoveryService } from './service/login-recovery/login-recovery.service';
import { ValidationService } from './service/validation/validation.service';
import { AssignNewPasswordComponent } from './assign-new-password/assign-new-password.component';
import { AssignNewPasswordService } from './service/assign-new-password/assign-new-password.service';
import { HomeComponent } from './pages/home/home.component';
import { MenuCrudComponent } from './pages/menu-crud/menu-crud.component';
import { UsuariosCrudComponent } from './pages/usuarios-crud/usuarios-crud.component';
import { UsuarioService } from './service/usuario/usuario.service';
import { ClientesCrudComponent } from './pages/clientes-crud/clientes-crud.component';
import { ClienteService } from './service/cliente/cliente.service';
import { PerfilesCrudComponent } from './pages/perfiles-crud/perfiles-crud.component';
import { PerfilesService } from './service/perfiles/perfiles.service';
import { RolesCrudComponent } from './pages/roles-crud/roles-crud.component';
import { RolService } from './service/rol/rol.service';
import { LoginService } from './service/login/login.service';
import { PermisosCrudComponent } from './pages/permisos-crud/permisos-crud.component';
import { PermisoService } from './service/permiso/permiso.service';
import { MenuService } from './service/menu/menu.service';
import { RolAutocompleteComponent } from './rol-autocomplete/rol-autocomplete.component';
import { RolAutocompleteService } from './service/rol-autocomplete/rol-autocomplete.service';
import { TipousuarioAutocompleteComponent } from './tipousuario-autocomplete/tipousuario-autocomplete.component';
import { TipousuarioAutocompleteService } from './service/tipousuario-autocomplete/tipousuario-autocomplete.service';
import { FieldErrorDisplayComponent } from './field-error-display/field-error-display.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { UsuarioAutocompleteComboboxComponent } from './usuario-autocomplete-combobox/usuario-autocomplete-combobox.component';
import { UsuarioAutocompleteComboboxService } from './service/usuario-autocomplete-combobox/usuario-autocomplete-combobox.service';
import { PortafolioEspecificoComponent } from './pages/portafolio-especifico/portafolio-especifico.component';
import { MenuListComponent } from './pages/menu-list/menu-list.component';
import { MenuDisplayComponent } from './pages/menu-display/menu-display.component';
import { TipoUsuarioComponent } from './pages/tipo-usuario/tipo-usuario.component';
import { TipoUsuarioService } from './service/tipo-usuario/tipo-usuario.service';
import { PortafolioGeneralComponent } from './pages/portafolio-general/portafolio-general.component';
import { PortafolioGeneralService } from './service/portafolio-general/portafolio-general.service';
import { SideBarComponent } from './side-bar/side-bar.component';
import { SidebarModule } from 'ng-sidebar';
import { CollapseModule } from 'ngx-bootstrap';
import { ResumenCotizacionComponent } from './pages/resumen-cotizacion/resumen-cotizacion.component';
import { MultiselectComponent } from './multiselect/multiselect.component';
import { SideBar2Component } from './side-bar2/side-bar2.component';
import { ReadMoreComponent } from './read-more/read-more.component';
import { ResumenCotizacionService } from './service/resumen-cotizacion/resumen-cotizacion.service';
import { ClientesAutompleteComponent } from './clientes-automplete/clientes-automplete.component';
import { ClientesAutocompleteService } from './service/clientes-autocomplete/clientes-autocomplete.service';
import { OtAutompleteComponent } from './ot-automplete/ot-automplete.component';
import { OtAutocompleteService } from './service/ot-autocomplete/ot-autocomplete.service';
import { PrioridadAutocompleteComponent } from './prioridad-autocomplete/prioridad-autocomplete.component';
import { PrioridadAutocompleteService } from './service/prioridad-autocomplete/prioridad-autocomplete.service';
import { AuthService } from './service/auth/auth.service';
import { AuthGuardService } from './service/auth-guard/auth-guard.service';
import { NotFoundComponent } from './not-found/not-found.component';
import { SelectivePreloadingStrategyService } from './service/selective-preloading-strategy/selective-preloading-strategy.service';
import { CanDeactivateGuardService } from './service/can-deactivate-guard/can-deactivate-guard.service';
import { PortafolioToResumenCotizacionService } from './service/portafolio-to-resumen-cotizacion/portafolio-to-resumen-cotizacion.service';
import { DownloadFileService } from './service/download-file/download-file.service';
import { AutoCompleteModule } from 'ng5-auto-complete';
import { NgSelectModule } from '@ng-select/ng-select';
import { ListaCotizacionesComponent } from './pages/lista-cotizaciones/lista-cotizaciones.component';
import { ListaCotizacionesService } from './service/lista-cotizaciones/lista-cotizaciones.service';
import {NgxMaskModule} from 'ngx-mask';
import { CurrencyMaskModule } from "ng2-currency-mask";
import { CurrencyMaskConfig, CURRENCY_MASK_CONFIG } from "ng2-currency-mask/src/currency-mask.config";
import { TipocomprasService } from './service/tipocompras/tipocompras.service';
import { TipocomprasAutocompleteComponent } from './tipocompras-autocomplete/tipocompras-autocomplete.component';
import { CategoriasComponent } from './categorias/categorias.component';
import { CategoriasService } from './service/categorias/categorias.service';
import { SubcategoriasService } from './service/subcategorias/subcategorias.service';
import { DataCategoriasService } from './service/data-categorias/data-categorias.service';
import { ParametrizacionFechasComponent } from './pages/parametrizacion-fechas/parametrizacion-fechas.component';
import { OwlDateTimeModule, OwlNativeDateTimeModule , OWL_DATE_TIME_LOCALE , OWL_DATE_TIME_FORMATS } from 'ng-pick-datetime';
import { FrecuenciaAutocompleteComponent } from './frecuencia-autocomplete/frecuencia-autocomplete.component';
import { FrecuenciaAutocompleteService } from './service/frecuencia-autocomplete/frecuencia-autocomplete.service';
import { ControlesCrudComponent } from './pages/controles-crud/controles-crud.component';
import { ControlesService } from './service/controles/controles.service';
import { OrderModule } from 'ngx-order-pipe'; // <- import OrderModule
import {CarouselModule} from 'ngx-bootstrap';
import { ControlSeguridadService } from './service/control-seguridad/control-seguridad.service';
import { ParametrizacionFechasService } from './service/parametrizacion-fechas/parametrizacion-fechas.service';
import { UnidadAutompleteComponent } from './unidad-automplete/unidad-automplete.component';
import { FichaTecnicaComponent } from './pages/ficha-tecnica/ficha-tecnica.component';
import { CtrClienteComponent } from './ctr-cliente/ctr-cliente.component';
import { CtrOtComponent } from './ctr-ot/ctr-ot.component';
import { ListaDesplegableComponent } from './lista-desplegable/lista-desplegable.component';
import { UnidadService } from './service/unidad/unidad.service';
import { SearchFichaTecnicaService } from './service/ficha-tecnica/search-ficha-tecnica.service';
import { FichaTecnicaService } from './service/ficha-tecnica/ficha-tecnica.service';
import { TipoFacturacionService } from './service/tipo-facturacion/tipo-facturacion.service';
import { CtrFacturacionComponent } from './ctr-facturacion/ctr-facturacion.component';
import { CtrCargoComponent } from './ctr-cargo/ctr-cargo.component';
import { DetallePortafolioEspecificoComponent } from './pages/detalle-portafolio-especifico/detalle-portafolio-especifico.component';
import { ListActividadesComponent } from './pages/list-actividades/list-actividades.component';
import { MenuEstadoService } from './service/menu-estado/menu-estado.service';
import { CargoService } from './service/cargo/cargo.service';
import { EstadosolicitudService } from './service/estadosolicitud/estadosolicitud.service';
import { TiposolicitudService } from './service/tiposolicitud/tiposolicitud.service';
import { ClienteOtService } from './service/cliente-ot/cliente-ot.service';
import { MisSolicitudesService } from './service/mis-solicitudes/mis-solicitudes.service';
import { PortafolioEspecificoService } from './service/portafolio-especifico/portafolio-especifico.service';
import { ResumenEstadoService } from './service/resumen-estado/resumen-estado.service';
import { PgEstadoService } from './service/pg-estado/pg-estado.service';
import { MisSolicitudesRcService } from './service/mis-solicitudes-rc/mis-solicitudes-rc.service';
import { ResumisPortaService } from './service/resumis-porta/resumis-porta.service';
import { AlertsComponent } from './utils/alerts/alerts.component';
import { MaterialModule } from './utils/material/material.module';
import { SpinerCargandoComponent } from './utils/spiner-cargando/spiner-cargando.component';
import { ThousandsPipe } from './pipes/thousands.pipe';
import { UsuarioDisplayComponent } from './usuario-display/usuario-display.component';
import { PagesComponent } from './pages/pages.component';


export const CustomCurrencyMaskConfig: CurrencyMaskConfig = {
    align: "right",
    allowNegative: true,
    decimal: ",",
    precision: 2,
    prefix: "R$ ",
    suffix: "",
    thousands: "."
};

@NgModule({
  declarations: [
    AppComponent,
    MessagesComponent,
    LoginComponent,
    LoginRecoveryComponent,
    AssignNewPasswordComponent,
    HomeComponent,
    MenuCrudComponent,
    UsuariosCrudComponent,
    ClientesCrudComponent,
    PerfilesCrudComponent,
    RolesCrudComponent,
    PermisosCrudComponent,
    RolAutocompleteComponent,
    TipousuarioAutocompleteComponent,
    FieldErrorDisplayComponent,
    UsuarioAutocompleteComboboxComponent,
    PortafolioEspecificoComponent,
    MenuListComponent,
    MenuDisplayComponent,
    TipoUsuarioComponent,
    PortafolioGeneralComponent,
    SideBarComponent,
    ResumenCotizacionComponent,
    MultiselectComponent,
    SideBar2Component,
    ReadMoreComponent,
    ClientesAutompleteComponent,
    OtAutompleteComponent,
    PrioridadAutocompleteComponent,
    NotFoundComponent,
    ListaCotizacionesComponent,
    TipocomprasAutocompleteComponent,
    CategoriasComponent,
    ParametrizacionFechasComponent,
    FrecuenciaAutocompleteComponent,
    ControlesCrudComponent,
    UnidadAutompleteComponent,
    FichaTecnicaComponent,
    CtrClienteComponent,
    CtrOtComponent,
    ListaDesplegableComponent,
    CtrFacturacionComponent,
    CtrCargoComponent,
    DetallePortafolioEspecificoComponent,
    ListActividadesComponent,
    AlertsComponent,
    SpinerCargandoComponent,
    ThousandsPipe,
    UsuarioDisplayComponent,
    PagesComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule,
    HttpModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    MaterialModule,
    NgxPaginationModule,
    CollapseModule.forRoot(),
    BsDropdownModule.forRoot(),
    TooltipModule.forRoot(),
    ModalModule.forRoot(),
    SidebarModule.forRoot(),
    AutoCompleteModule,
    NgSelectModule,
    NgxMaskModule.forRoot(),
    CurrencyMaskModule,
    OwlDateTimeModule,
    OwlNativeDateTimeModule,
    OrderModule,
    CarouselModule.forRoot(),
  ],
  providers: [
    MessageService,
    LoginRecoveryService,
    ValidationService,
    AssignNewPasswordService,
    UsuarioService,
    ClienteService,
    PerfilesService,
    RolService,
    LoginService,
    PermisoService,
    MenuService,
    RolAutocompleteService,
    TipousuarioAutocompleteService,
    UsuarioAutocompleteComboboxService,
    TipoUsuarioService,
    PortafolioGeneralService,
    ResumenCotizacionService,
    ClientesAutocompleteService,
    OtAutocompleteService,
    PrioridadAutocompleteService,
    AuthService,
    AuthGuardService,
    SelectivePreloadingStrategyService,
    CanDeactivateGuardService,
    PortafolioToResumenCotizacionService,
    DownloadFileService,
    ListaCotizacionesService,
    TipocomprasService,
    CategoriasService,
    SubcategoriasService,
    DataCategoriasService,
    FrecuenciaAutocompleteService,
    ControlesService,
    ControlSeguridadService,
    ParametrizacionFechasService,
    UnidadService,
    SearchFichaTecnicaService,
    FichaTecnicaService,
    TipoFacturacionService,
    MenuEstadoService,
    CargoService,
    EstadosolicitudService,
    TiposolicitudService,
    ClienteOtService,
    MisSolicitudesService,
    PortafolioEspecificoService,
    ResumenEstadoService,
    PgEstadoService,
    MisSolicitudesRcService,
    ResumisPortaService,
    {provide: OWL_DATE_TIME_LOCALE, useValue: 'sp'}
  ],
  exports: [BsDropdownModule, TooltipModule, ModalModule, AlertsComponent],
  entryComponents: [AlertsComponent,SpinerCargandoComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }

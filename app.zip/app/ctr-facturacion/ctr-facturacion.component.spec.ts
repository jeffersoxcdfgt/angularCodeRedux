import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CtrFacturacionComponent } from './ctr-facturacion.component';

describe('CtrFacturacionComponent', () => {
  let component: CtrFacturacionComponent;
  let fixture: ComponentFixture<CtrFacturacionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CtrFacturacionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CtrFacturacionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

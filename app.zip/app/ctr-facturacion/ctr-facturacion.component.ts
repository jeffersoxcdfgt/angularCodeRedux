import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { TipoFacturacionService } from '../service/tipo-facturacion/tipo-facturacion.service';
import { TipoFacturacion } from '../class/tipoFacturacion';

@Component({
  selector: 'app-ctr-facturacion',
  templateUrl: './ctr-facturacion.component.html',
  styleUrls: ['./ctr-facturacion.component.css']
})
export class CtrFacturacionComponent implements OnInit {
  tipoFacturacion: TipoFacturacion[];
  selectFacturacion: any[];
  @Output() emitEvent: EventEmitter<any> = new EventEmitter<any>();
  @Output() emitEventRows: EventEmitter<any[]> = new EventEmitter<any[]>();
  constructor(private tipoFacturacionService: TipoFacturacionService) { }

  ngOnInit() {
    this.getFacturacion();
  }

  setFacturacion(){
    //RESUMENCOTIZACION[FIRST].id = this.selectFacturacion.id;
  }

  /*Metodo consumidor trae las categorias*/
  getFacturacion(): void {
    this.tipoFacturacionService.getFacturacion()
    .subscribe(tipoFacturacion => {
      this.tipoFacturacion = tipoFacturacion;
      this.emitEventRows.emit(this.tipoFacturacion);
    });
  }

  getFacturaSelected(): void{
    this.emitEvent.emit(this.selectFacturacion);
  }

  get facturas():any[]{
    return this.tipoFacturacion;
  }

  set facturas(tipoFacturacion:any[]){
    this.tipoFacturacion = tipoFacturacion;
  }

}

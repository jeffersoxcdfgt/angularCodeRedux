import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OtAutompleteComponent } from './ot-automplete.component';

describe('OtAutompleteComponent', () => {
  let component: OtAutompleteComponent;
  let fixture: ComponentFixture<OtAutompleteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OtAutompleteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OtAutompleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

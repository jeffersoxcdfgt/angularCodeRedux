import { Component, OnInit ,ViewEncapsulation } from '@angular/core';
import { NgSelectModule } from '@ng-select/ng-select';
import { FormControl ,FormGroup, FormBuilder, Validators, FormsModule} from '@angular/forms';
import { OtAutocompleteService } from '../service/ot-autocomplete/ot-autocomplete.service';
import { Validation } from '../validation/validation';
import { ValidationService } from '../service/validation/validation.service';
import { ResumenCotizacion } from '../class/resumen-cotizacion';
import { RESUMENCOTIZACION , FIRST } from '../mocks/mock-resumen-cotizacion';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/map';
import { ot_display } from '../class/ot_display';


@Component({
  selector: 'app-ot-automplete',
  templateUrl: './ot-automplete.component.html',
  styleUrls: ['./ot-automplete.component.css'],
  providers: [OtAutocompleteService],
})
export class OtAutompleteComponent implements OnInit {
  searchTerm : FormControl = new FormControl();
  searchResult = [];
  ots: any[];
  selectedOts:ot_display;

  constructor(  private formBuilder: FormBuilder,
                private otAutocompleteService: OtAutocompleteService ,
                private validationService :ValidationService
  ) { }

  ngOnInit() {
    this.getOtAutoComplete();
  }

  setOt(ot:string){
      //RESUMENCOTIZACION[FIRST].id_ot = this.selectedOts.id_ot;
  }

  /*Metodo consumidor para traer clientes*/
  getOtAutoComplete(): void {
    this.otAutocompleteService.getOts()
        .subscribe(ots => {
          this.ots = ots
    });
  }

}

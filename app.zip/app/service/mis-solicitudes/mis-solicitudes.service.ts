import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { ValidationService } from '../validation/validation.service';
import { MisSolicitudes } from '../../class/mis-solicitudes';
import { MISSOLICITUDES } from '../../mocks/mock-mis-solicitudes';

@Injectable()
export class MisSolicitudesService {

  private misSolicitudesdUrl = environment.protocol+'://'+environment.ApiUrl+'/api/listSolicitudes';
  private misSolicitudesdUrlID = environment.protocol+'://'+environment.ApiUrl+'/api/listSolicitudesID';
  private historicoUrlID = environment.protocol+'://'+environment.ApiUrl+'/api/historicoID';
  private searchSolicitudesIDUrl = environment.protocol+'://'+environment.ApiUrl+'/api/searchSolicitudesID';

  constructor(private http: HttpClient,
               private validationService :ValidationService) { }


  /** Trae los datos del servidor */
  getMisSolicitudes(): Observable <MisSolicitudes[]> {
    const url = `${this.misSolicitudesdUrl}`;
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
    return this.http.get <MisSolicitudes[]>(url, httpOptions)
            .pipe(tap(missolicitudes => this.validationService.log(`trae la lista de solicitudes`)),
             	catchError(this.validationService.handleError('getMisSolicitudes', []))
        );
    }

    /** Trae los datos del servidor por id */
    getMisSolicitudesID (id : number): Observable<MisSolicitudes[]> {
      const url = `${this.misSolicitudesdUrlID}/${id}`;
      const httpOptions = {
        headers: new HttpHeaders(
            {
              'Content-Type': 'application/json',
              'Authorization':'Bearer '+localStorage.getItem('token')
            }
          )
      };
      return this.http.get<MisSolicitudes[]>(url,httpOptions)
        .pipe(
               tap(detmisolicitud => this.validationService.log(`trae solicitudes por id`)),
               catchError(this.validationService.handleError('getMisSolicitudesID', []))
        );
     }


     /** Trae los datos del servidor por id */
     getHistoricoID (id : string): Observable<MisSolicitudes[]> {
       const url = `${this.historicoUrlID}/${id}`;
       const httpOptions = {
         headers: new HttpHeaders(
             {
               'Content-Type': 'application/json',
               'Authorization':'Bearer '+localStorage.getItem('token')
             }
           )
       };
       return this.http.get<MisSolicitudes[]>(url,httpOptions)
         .pipe(
              tap(historicosol => this.validationService.log(`trae el historico de las solicitudes por id`)),
              catchError(this.validationService.handleError('getHistoricoID', []))
         );
      }


      /** Busqueda de Solicitud por ID */
      searchSolicitudesID (id : string): Observable<MisSolicitudes[]> {
        const url = `${this.searchSolicitudesIDUrl}?id=${id}`;
        const httpOptions = {
          headers: new HttpHeaders(
              {
                'Content-Type': 'application/json',
                'Authorization':'Bearer '+localStorage.getItem('token')
              }
            )
        };
        return this.http.get<MisSolicitudes[]>(url,httpOptions)
          .pipe(
              tap(detmisolicitud => this.validationService.log(`trae una sola solicitud por id`)),
              catchError(this.validationService.handleError('searchSolicitudesID', []))
          );
       }

}

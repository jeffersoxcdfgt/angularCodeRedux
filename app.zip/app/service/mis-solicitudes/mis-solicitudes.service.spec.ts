import { TestBed, inject } from '@angular/core/testing';

import { MisSolicitudesService } from './mis-solicitudes.service';

describe('MisSolicitudesService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MisSolicitudesService]
    });
  });

  it('should be created', inject([MisSolicitudesService], (service: MisSolicitudesService) => {
    expect(service).toBeTruthy();
  }));
});

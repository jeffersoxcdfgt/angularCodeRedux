import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { ValidationService } from '../validation/validation.service';
import { ControlesSeguridad } from '../../class/controles_seguridad';
import { CONTROLESEGURIDAD } from '../../mocks/mock-control-seguridad';

@Injectable()
export class ControlSeguridadService {

  private seguridadControlesUrl = environment.protocol+'://'+environment.ApiUrl+'/api/controles_controller';

  constructor( private http: HttpClient,
                private validationService :ValidationService) { }

   /** Permite setear controles*/
   setSeguridadControles(): Observable<ControlesSeguridad> {
      return of(new ControlesSeguridad);
   }

   /** Trae los datos del servidor */
   getSeguridadControles (param : string ): Observable<ControlesSeguridad[]> {
     const url = `${this.seguridadControlesUrl}?pantalla=${param}`;
     const httpOptions = {
       headers: new HttpHeaders(
           {
             'Content-Type': 'application/json',
             'Authorization':'Bearer '+localStorage.getItem('token')
           }
         )
    };
    return this.http.get<ControlesSeguridad[]>(url,httpOptions)
        .pipe(
            tap(controlesseguridad => this.validationService.log(`trae controles a mostrar`)),
            catchError(this.validationService.handleError('getSeguridadControles', []))
        );
    }





}

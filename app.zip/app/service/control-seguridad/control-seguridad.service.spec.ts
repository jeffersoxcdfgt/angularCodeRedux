import { TestBed, inject } from '@angular/core/testing';

import { ControlSeguridadService } from './control-seguridad.service';

describe('ControlSeguridadService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ControlSeguridadService]
    });
  });

  it('should be created', inject([ControlSeguridadService], (service: ControlSeguridadService) => {
    expect(service).toBeTruthy();
  }));
});

import { TestBed, inject } from '@angular/core/testing';

import { TipousuarioAutocompleteService } from './tipousuario-autocomplete.service';

describe('TipousuarioAutocompleteService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [TipousuarioAutocompleteService]
    });
  });

  it('should be created', inject([TipousuarioAutocompleteService], (service: TipousuarioAutocompleteService) => {
    expect(service).toBeTruthy();
  }));
});

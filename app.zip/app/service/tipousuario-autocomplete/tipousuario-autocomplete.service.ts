import { Injectable } from '@angular/core';
import { Http , Headers} from '@angular/http';
import { environment } from '../../../environments/environment';

@Injectable()
export class TipousuarioAutocompleteService {
  url: string

  constructor(private http : Http) {
        this.url  = environment.protocol+'://'+environment.ApiUrl+'/api/tipo_usuario/busqueda?nombre=';
  }

  search_word(term){
    const httpOptions = {
      headers: new Headers(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
        return this.http.get(this.url + term , httpOptions).map(res => {
            return res.json().map(item => {
                return item.nombre
            })
        })
    }

}

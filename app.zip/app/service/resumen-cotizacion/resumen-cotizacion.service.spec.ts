import { TestBed, inject } from '@angular/core/testing';

import { ResumenCotizacionService } from './resumen-cotizacion.service';

describe('ResumenCotizacionService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ResumenCotizacionService]
    });
  });

  it('should be created', inject([ResumenCotizacionService], (service: ResumenCotizacionService) => {
    expect(service).toBeTruthy();
  }));
});

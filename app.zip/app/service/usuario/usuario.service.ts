import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { ValidationService } from '../validation/validation.service';
import { Usuario } from '../../class/usuario';
import { USUARIO  } from '../../mocks/mock-usuario';
import { CLIENTE } from '../../mocks/mock-cliente';
import { Cliente } from '../../class/cliente';

@Injectable()
export class UsuarioService {

  private usuariosUrl = environment.protocol+'://'+environment.ApiUrl+'/api/usuarios';
  private usuariosUrlDelete = environment.protocol+'://'+environment.ApiUrl+'/api/usuario/eliminar';
  private clientesUrlXOts = environment.protocol+'://'+environment.ApiUrl+'/api/buscar_cliente_ots';
  private otsUrlXCliente = environment.protocol+'://'+environment.ApiUrl+'/api/buscar_ots_cliente';
  private usuariosSearchUrl = environment.protocol+'://'+environment.ApiUrl+'/api/usuario/busqueda';

  /**Constructur para injectar dependencias**/
  constructor(  private http: HttpClient,
                private validationService :ValidationService){
  }

  /** Permite setear usuarios*/
   setUsuarios(): Observable<Usuario> {
      return of(new Usuario);
  }

  /** Trae los datos del servidor */
  getUsuarios (): Observable<Usuario[]> {
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
    return this.http.get<Usuario[]>(this.usuariosUrl,httpOptions)
      .pipe(
        tap(usuarios => this.validationService.log(`trae usuarios`)),
        catchError(this.validationService.handleError('getUsuarios', []))
      );
  }

  //////// Metodos para crud //////////

  /** POST: agrega un usuario al servidor */
  addUsuario (usuario: Usuario): Observable<Usuario> {
    const url = `${this.usuariosUrl}`;
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
    return this.http.post<Usuario>(url, usuario, httpOptions).pipe(
      tap((usuario: Usuario) => this.validationService.log(`Agrega usuario w/ id=${usuario.id}`)),
      catchError(this.validationService.handleError<Usuario>('addUsuario'))
    );
  }

  /** PUT: actualiza usuario en el servidor */
 updateUsuario (usuario: Usuario ): Observable<any> {
   const id = usuario.id;
   const url = `${this.usuariosUrl}/${id}`;

   const httpOptions = {
     headers: new HttpHeaders(
         {
           'Content-Type': 'application/json',
           'Authorization':'Bearer '+localStorage.getItem('token')
         }
       )
   };
   return this.http.put(url,usuario,httpOptions).pipe(
     tap(_ => this.validationService.log(`updated usuario id=${usuario.id}`)),
     catchError(this.validationService.handleError<any>('updateUsuario'))
   );
 }

  /** DELETE: Borra usuario del servidor */
  deleteUsuario (usuario: Usuario | number): Observable<Usuario> {
    const id = typeof usuario === 'number' ? usuario : usuario.id;
    const url = `${this.usuariosUrlDelete}/${id}`;
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
    return this.http.delete<Usuario>(url, httpOptions).pipe(
      tap(_ => this.validationService.log(`Borrar usuario  id=${id}`)),
      catchError(this.validationService.handleError<Usuario>('deleteUsuario'))
    );
  }

  /*Retorna Ots por Clientes*/
  getOtsClientes (cliente: any): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
    return this.http.post<any>(this.clientesUrlXOts, cliente, httpOptions).pipe(
      tap((cliente: any) => this.validationService.log(`Se consulta ots por cliente`)),
      catchError(this.validationService.handleError<any>('getOtsClientes'))
    );
  }

  /*Retorna Cliente por OTs*/
  getClientesOts (ot: any): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
    return this.http.post<any>(this.otsUrlXCliente, ot, httpOptions).pipe(
      tap((ot: any) => this.validationService.log(`Se consulta Clientes por ot`)),
      catchError(this.validationService.handleError<any>('getClientesOts'))
    );
  }

  /* Obtiene lista de usuarios filtrados*/
  searchUsuarios(term: string): Observable<Usuario[]> {
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
    return this.http.get<Usuario[]>(`${this.usuariosSearchUrl}?nombre=${term}`,httpOptions).pipe(
      tap(_ => this.validationService.log(`Lista de usuarios encontrados "${term}"`)),
      catchError(this.validationService.handleError<Usuario[]>('searchUsuarios', []))
    );
  }

}

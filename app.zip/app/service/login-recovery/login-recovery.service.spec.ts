import { TestBed, inject } from '@angular/core/testing';

import { LoginRecoveryService } from './login-recovery.service';

describe('LoginRecoveryService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [LoginRecoveryService]
    });
  });

  it('should be created', inject([LoginRecoveryService], (service: LoginRecoveryService) => {
    expect(service).toBeTruthy();
  }));
});

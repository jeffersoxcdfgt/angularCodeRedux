import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/delay';
import { interval } from 'rxjs/observable/interval';
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { ValidationService } from '../validation/validation.service';
import { RESUMENCOTIZACION,FIRST } from '../../mocks/mock-resumen-cotizacion';
import { ResumenCotizacion } from '../../class/resumen-cotizacion';
import { PORTAFOLIOGENERAL } from '../../mocks/mock-portafolio-general';
import { Portafoliogeneral } from '../../class/portafolio-general';
import { Subscription } from "rxjs/Subscription";
import * as $ from 'jquery';

@Injectable()
export class PortafolioToResumenCotizacionService {
  resumencotizacion: ResumenCotizacion;
  aux: ResumenCotizacion;
  isLoggedIn = false;
  interval: Subscription;
  id_cotizacion : string;

  constructor(private validationService :ValidationService) { }

  /** Permite setear datos*/
  setToDetailResumen(resumenCotizacion :ResumenCotizacion): Observable<ResumenCotizacion> {
      return of(new ResumenCotizacion);
  }

  setCalcular(){
      this.interval = interval(1000).subscribe(
        val => {
          let datos=RESUMENCOTIZACION[FIRST].detalle;
          let total=0;
          let subtotal_venta =0;
          let subtotal_costo =0;
          let iva = 0;
          let total_venta = 0;
          let base_gravable = 0;
          let base_excenta  = 0;

          datos.forEach(function (value) {
              total +=Number(value.CANTIDAD);
              subtotal_venta += Number(value.SUBTOTAL_VENTA_COT);
              subtotal_costo += Number(value.SUBTOTAL_COSTO);

              if(Number(value.PORCENTAJE) > 0){
                  base_gravable += (Number(value.CANTIDAD)  * Number(value.PRECION_VENTA));
                  iva += (Number(value.CANTIDAD)  * Number(value.PRECION_VENTA)) * (Number(value.PORCENTAJE) / 100);
              }
              else{
                  base_excenta  +=  (Number(value.CANTIDAD)  * Number(value.PRECION_VENTA));
              }
              value.estado =1;
          });
          total_venta = Number(subtotal_venta) + Number(iva);
          RESUMENCOTIZACION[FIRST].SUBTOTAL_VENTA_COT = (subtotal_venta).toString();
          RESUMENCOTIZACION[FIRST].TOTAL_COSTO = (subtotal_costo).toString();
          RESUMENCOTIZACION[FIRST].TOTAL_VENTA = (total_venta).toString();
          RESUMENCOTIZACION[FIRST].BASE_GRAVABLE = (base_gravable).toString();
          RESUMENCOTIZACION[FIRST].BASE_EXCENTA = (base_excenta).toString();
          RESUMENCOTIZACION[FIRST].IVA = (iva).toString();
          $('#totalizado').html(total.toString());
        });
  }

  stopCalcular(){
    this.interval.unsubscribe();
  }

  //Set Solicitud
  setIdSolicitud(value : string){
      this.id_cotizacion=value;
  }

 //Get Solicitud
  getIdSolicitud(){
    return this.id_cotizacion;
  }
}

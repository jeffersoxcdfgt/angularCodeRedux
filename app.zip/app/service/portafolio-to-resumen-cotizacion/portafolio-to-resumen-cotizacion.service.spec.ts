import { TestBed, inject } from '@angular/core/testing';

import { PortafolioToResumenCotizacionService } from './portafolio-to-resumen-cotizacion.service';

describe('PortafolioToResumenCotizacionService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PortafolioToResumenCotizacionService]
    });
  });

  it('should be created', inject([PortafolioToResumenCotizacionService], (service: PortafolioToResumenCotizacionService) => {
    expect(service).toBeTruthy();
  }));
});

import { TestBed, inject } from '@angular/core/testing';

import { DataCategoriasService } from './data-categorias.service';

describe('DataCategoriasService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DataCategoriasService]
    });
  });

  it('should be created', inject([DataCategoriasService], (service: DataCategoriasService) => {
    expect(service).toBeTruthy();
  }));
});

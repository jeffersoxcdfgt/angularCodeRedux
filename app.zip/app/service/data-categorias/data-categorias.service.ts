import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Categoria } from '../../class/categoria';

@Injectable()
export class DataCategoriasService {
  selectedCategorias: Categoria;

  constructor() { }

  setCategoria(categoria : Categoria){
      this.selectedCategorias =  categoria;
  }

  getCategorias(){
    return this.selectedCategorias;
  }

}

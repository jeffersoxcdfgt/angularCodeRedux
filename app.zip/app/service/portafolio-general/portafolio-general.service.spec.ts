import { TestBed, inject } from '@angular/core/testing';

import { PortafolioGeneralService } from './portafolio-general.service';

describe('PortafolioGeneralService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PortafolioGeneralService]
    });
  });

  it('should be created', inject([PortafolioGeneralService], (service: PortafolioGeneralService) => {
    expect(service).toBeTruthy();
  }));
});

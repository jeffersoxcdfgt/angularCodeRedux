import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { ValidationService } from '../validation/validation.service';
import { PORTAFOLIOGENERAL } from '../../mocks/mock-portafolio-general';
import { Portafoliogeneral } from '../../class/portafolio-general';
import { Filtroportafolio } from '../../class/filtro-portafolio';

@Injectable()
export class PortafolioGeneralService {

  private portafoliogeneralUrl = environment.protocol + '://' + environment.ApiUrl + '/api/articulos';
  private SelectportafoliogeneralUrl = environment.protocol + '://' + environment.ApiUrl + '/api/getArticulos';
  private newFiltersUrl = environment.protocol + '://' + environment.ApiUrl + '/api/filtrosPortafolio';

  constructor(private http: HttpClient,
    private validationService: ValidationService) { }

  /** Permite setear filtros de portafolio*/
  setFiltrosPortafolios(): Observable<Filtroportafolio> {
    return of(new Filtroportafolio);
  }

  /*Nueva tabla de filtros*/
  getNewFilters(): Observable<any[]> {
    const url = `${this.newFiltersUrl}`;
    const httpOptions = {
      headers: new HttpHeaders(
        {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + localStorage.getItem('token')
        }
      )
    };
    return this.http.get<any[]>(url, httpOptions)
      .pipe(
        tap(filtros => this.validationService.log(`trae el valor de todos los filtros`)),
        catchError(this.validationService.handleError('getNewFilters', []))
      );
  }

  /** Trae los datos del servidor */
  getPortafoliogeneral(id: string = null): Observable<Portafoliogeneral[]> {
    let url = `${this.portafoliogeneralUrl}`;
    /*if (id) {
      url = `${this.portafoliogeneralUrl}?kit=${id}`;
    }*/

    const httpOptions = {
      headers: new HttpHeaders(
        {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + localStorage.getItem('token')
        }
      )
    };
    return this.http.get<Portafoliogeneral[]>(url, httpOptions)
      .pipe(
        tap(portafoliogenerales => this.validationService.log(`trae portafolios generales`)),
        catchError(this.validationService.handleError('getPortafoliogeneral', []))
      );
  }

  /** Filtro de los productos del portafolio**/
  //getFiltroPortafolio(id_tipocompra: string, id_categoria: string, id_subcategoria: string): Observable<Portafoliogeneral[]> {
  getFiltroPortafolio(id_tipocompra: string, id_categoria: string, id_subcategoria: string, id_kit: string): Observable<Portafoliogeneral[]> {
    //const url = `${this.SelectportafoliogeneralUrl}?tipo_compra=${id_tipocompra}&categoria=${id_categoria}&sub_categoria=${id_subcategoria}`;
    const url = `${this.SelectportafoliogeneralUrl}?tipo_compra=${id_tipocompra}&categoria=${id_categoria}&sub_categoria=${id_subcategoria}&kit_noguero=${id_kit}`;
    const httpOptions = {
      headers: new HttpHeaders(
        {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + localStorage.getItem('token')
        }
      )
    };
    return this.http.get<Portafoliogeneral[]>(url, httpOptions).pipe(
      tap(_ => this.validationService.log(`Trae el portafolio filtrado`)),
      catchError(this.validationService.handleError<Portafoliogeneral[]>(`getFiltroPortafolio`))
    );
  }

}

import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { ValidationService } from '../validation/validation.service';
import { Cotizacion } from '../../class/cotizacion';
import { COTIZACION } from '../../mocks/mock-cotizacion';

@Injectable()
export class ListaCotizacionesService {

   private ListadoCotizacionUrl = environment.protocol+'://'+environment.ApiUrl+'/api/busqueda_cotizaciones';

   constructor( private http: HttpClient,private validationService :ValidationService) {}

   /** Permite setear listado de cotizaciones*/
   setCotizaciones(): Observable<Cotizacion> {
      return of(new Cotizacion);
   }

   /**Lista todas las cotizaciones guardadas**/
   getListaCotizaciones (): Observable<Cotizacion[]> {
     const url = `${this.ListadoCotizacionUrl}`;
     const httpOptions = {
       headers: new HttpHeaders(
           {
             'Content-Type': 'application/json',
             'Authorization':'Bearer '+localStorage.getItem('token')
           }
         )
     };
     return this.http.get<Cotizacion[]>(url,httpOptions)
       .pipe(
         tap(cotizaciones => this.validationService.log(`trae cotizaciones`)),
         catchError(this.validationService.handleError('getListaCotizaciones', []))
       );
   }

    /* Obtiene lista de cotizaciones filtradas*/
    searchCotizaciones(term: string): Observable<Cotizacion[]> {
      const httpOptions = {
        headers: new HttpHeaders(
            {
              'Content-Type': 'application/json',
              'Authorization':'Bearer '+localStorage.getItem('token')
            }
          )
      };
      return this.http.get<Cotizacion[]>(`${this.ListadoCotizacionUrl}/?nombre=${term}`,httpOptions).pipe(
        tap(_ => this.validationService.log(`Lista de cotizaciones encontradas "${term}"`)),
        catchError(this.validationService.handleError<Cotizacion[]>('searchCotizaciones', []))
      );
    }

}

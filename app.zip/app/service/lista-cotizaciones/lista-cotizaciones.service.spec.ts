import { TestBed, inject } from '@angular/core/testing';

import { ListaCotizacionesService } from './lista-cotizaciones.service';

describe('ListaCotizacionesService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ListaCotizacionesService]
    });
  });

  it('should be created', inject([ListaCotizacionesService], (service: ListaCotizacionesService) => {
    expect(service).toBeTruthy();
  }));
});

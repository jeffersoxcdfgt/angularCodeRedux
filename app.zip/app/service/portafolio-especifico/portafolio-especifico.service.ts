import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { ValidationService } from '../validation/validation.service';
import { Portafolioespecifico } from '../../class/portafolio-especifico';
import { PORTAFOLIOESPECIFICO } from '../../mocks/mock-portafolio-especifico';

@Injectable()
export class PortafolioEspecificoService {

    private portafolioEspecifico = environment.protocol+'://'+environment.ApiUrl+'/api/PortafolioEspecifico';
    private portafolioEspecificoID = environment.protocol+'://'+environment.ApiUrl+'/api/PortafolioEspecificoID';

    constructor( private http: HttpClient, private validationService :ValidationService) { }

    /** Permite setear portafolio -especifico*/
    setPortafolioEspecifico(): Observable<Portafolioespecifico> {
        return of(new Portafolioespecifico);
    }

    /** Trae los datos del servidor */
    getPortafolioEspecifico (): Observable<Portafolioespecifico[]> {
      const url = `${this.portafolioEspecifico}`;
      const httpOptions = {
      headers: new HttpHeaders(
            {
              'Content-Type': 'application/json',
              'Authorization':'Bearer '+localStorage.getItem('token')
            }
          )
      };
        return this.http.get<Portafolioespecifico[]>(url,httpOptions)
           .pipe(
               tap(portafolioespecificos => this.validationService.log(`trae portafolios`)),
               catchError(this.validationService.handleError('getPortafolioEspecifico', []))
           );
     }

     /** Trae los datos del servidor por id */
     getPortafolioEspecificoID (id : number): Observable<any[]> {
       const url = `${this.portafolioEspecificoID}/${id}`;
       const httpOptions = {
       headers: new HttpHeaders(
             {
               'Content-Type': 'application/json',
               'Authorization':'Bearer '+localStorage.getItem('token')
             }
           )
       };
       return this.http.get<any[]>(url,httpOptions)
         .pipe(
            tap(portafolioesdetalle => this.validationService.log(`trae detalle portafolios por id`)),
            catchError(this.validationService.handleError('getPortafolioEspecificoID', []))
         );
      }

    /** get all data */
  getOTClientes(): Observable<any>{
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
      )
    };
    const url = environment.protocol+'://'+environment.ApiUrl+'/api/listOTClients/';
    return this.http.get<any[]>(url, httpOptions)
    .pipe(
        tap(dataAllOTClientes => this.validationService.log(`trae las ot y clientes`)),
        catchError(this.validationService.handleError('getOTClientes', []))
    );
  }

    /** Trae los datos para los filtros */
    getFiltrosPortafolioEspecifico (ot): Observable<any> {
      const httpOptions = {
      headers: new HttpHeaders(
            {
              'Content-Type': 'application/json',
              'Authorization':'Bearer '+localStorage.getItem('token')
            }
          )
      };
      const url = environment.protocol+'://'+environment.ApiUrl+'/api/listFiltros/'+ot;
        return this.http.get<any>(url,httpOptions)
           .pipe(
               tap(portafolioespecificos => this.validationService.log(`trae filtros portafolios`)),
               catchError(this.validationService.handleError('getFiltrosPortafolioEspecifico', []))
           );
     }

     /** Trae los datos para los filtros */
    getAllFiltros (ot): Observable<any> {
      const httpOptions = {
      headers: new HttpHeaders(
            {
              'Content-Type': 'application/json',
              'Authorization':'Bearer '+localStorage.getItem('token')
            }
          )
      };
      const url = environment.protocol+'://'+environment.ApiUrl+'/api/listFiltros/'+ot;
        return this.http.get<any>(url,httpOptions)
           .pipe(
               tap(portafolioespecificos => this.validationService.log(`trae filtros portafolios`)),
               catchError(this.validationService.handleError('getFiltrosPortafolioEspecifico', []))
           );
     }

      /** Trae Detalle de acuerdo a los datos de los filtros seleccionados */
      getDetallePE (searchDatos): Observable<any[]> {
      const httpOptions = {
      headers: new HttpHeaders(
            {
              'Content-Type': 'application/json',
              'Authorization':'Bearer '+localStorage.getItem('token')
            }
          )
      };
      const url = environment.protocol+'://'+environment.ApiUrl+'/api/filtrosPtEspecificos/';
        return this.http.post<any[]>(url,searchDatos,httpOptions)
           .pipe(
               tap(portafolioespecificos => this.validationService.log(`trae detalle filtros portafolios`)),
               catchError(this.validationService.handleError('getDetallePE', []))
           );
     }

}

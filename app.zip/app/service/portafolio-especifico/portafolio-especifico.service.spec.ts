import { TestBed, inject } from '@angular/core/testing';

import { PortafolioEspecificoService } from './portafolio-especifico.service';

describe('PortafolioEspecificoService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PortafolioEspecificoService]
    });
  });

  it('should be created', inject([PortafolioEspecificoService], (service: PortafolioEspecificoService) => {
    expect(service).toBeTruthy();
  }));
});

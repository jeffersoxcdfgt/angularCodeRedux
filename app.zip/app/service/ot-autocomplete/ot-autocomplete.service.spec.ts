import { TestBed, inject } from '@angular/core/testing';

import { OtAutocompleteService } from './ot-autocomplete.service';

describe('OtAutocompleteService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [OtAutocompleteService]
    });
  });

  it('should be created', inject([OtAutocompleteService], (service: OtAutocompleteService) => {
    expect(service).toBeTruthy();
  }));
});

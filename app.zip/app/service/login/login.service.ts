import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { ValidationService } from '../validation/validation.service';
import { Login } from '../../class/login';
import { LOGIN } from '../../mocks/mock-login';

const httpOptions = {
  headers: new HttpHeaders(
    {
       'Content-Type': 'application/json'
    }
  )
};

@Injectable()
export class LoginService {

private loginValidateUrl = environment.protocol+'://'+environment.ApiUrl+'/api/ingreso1';
  isLoggedIn = false;
  redirectUrl: string;

  constructor( private http: HttpClient,
              private validationService :ValidationService) { }

  getLogins(): Observable<Login[]> {
      return of(LOGIN);
  }

  /** POST: valida el ingreso del usuario */
  validateLogin (login: Login): Observable<Login> {
      const httpOptions = {
        headers: new HttpHeaders(
            {
              'Content-Type': 'application/json',
              'Authorization':'Bearer '+localStorage.getItem('token'),
            }
          )
     };
      return this.http.post<Login>(this.loginValidateUrl, login, httpOptions).pipe(
            tap((login: Login) => this.validationService.log(`${login.mensaje}`)),
                catchError(this.validationService.handleError<Login>('validateLogin'))
            );
  }

}

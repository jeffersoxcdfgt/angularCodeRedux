import { TestBed, inject } from '@angular/core/testing';

import { ClientesAutocompleteService } from './clientes-autocomplete.service';

describe('ClientesAutocompleteService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ClientesAutocompleteService]
    });
  });

  it('should be created', inject([ClientesAutocompleteService], (service: ClientesAutocompleteService) => {
    expect(service).toBeTruthy();
  }));
});

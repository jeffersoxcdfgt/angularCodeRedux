import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { ValidationService } from '../validation/validation.service';
import { EstadoSolicitud } from '../../class/estadosolicitud';
import { ESTADOSOLICITUD } from '../../mocks/mock-estadosolicitud';

@Injectable()
export class EstadosolicitudService {

      private estadoSolicitudUrl = environment.protocol+'://'+environment.ApiUrl+'/api/estadoSolicitud';

      constructor(private http: HttpClient,
                   private validationService :ValidationService) { }

      /** Permite setear estados de solicitud*/
      setEstadosSolicitud(): Observable<EstadoSolicitud> {
            return of(new EstadoSolicitud);
      }

      /** Trae los datos del servidor */
      getEstadosSolicitud (): Observable<EstadoSolicitud[]> {
        const httpOptions = {
          headers: new HttpHeaders(
              {
                'Content-Type': 'application/json',
                'Authorization':'Bearer '+localStorage.getItem('token')
              }
            )
        };
        return this.http.get<EstadoSolicitud[]>(this.estadoSolicitudUrl,httpOptions)
              .pipe(tap(estadosolicitud => this.validationService.log(`trae estados de solicitud`)),
                catchError(this.validationService.handleError('getEstadosSolicitud', []))
              );
      }

}

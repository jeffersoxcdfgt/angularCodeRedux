import { TestBed, inject } from '@angular/core/testing';

import { EstadosolicitudService } from './estadosolicitud.service';

describe('EstadosolicitudService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [EstadosolicitudService]
    });
  });

  it('should be created', inject([EstadosolicitudService], (service: EstadosolicitudService) => {
    expect(service).toBeTruthy();
  }));
});

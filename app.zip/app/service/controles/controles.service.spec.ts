import { TestBed, inject } from '@angular/core/testing';

import { ControlesService } from './controles.service';

describe('ControlesService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ControlesService]
    });
  });

  it('should be created', inject([ControlesService], (service: ControlesService) => {
    expect(service).toBeTruthy();
  }));
});

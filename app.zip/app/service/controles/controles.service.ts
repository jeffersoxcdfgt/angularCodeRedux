import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { ValidationService } from '../validation/validation.service';
import { Control } from '../../class/control';
import { CONTROL } from '../../mocks/mock-control';

@Injectable()
export class ControlesService {

  private controlesUrl = environment.protocol+'://'+environment.ApiUrl+'/api/controles-menu';
  private controlesUrllDelete = environment.protocol+'://'+environment.ApiUrl+'/api/controles-menu';
  private controlesSearchUrl = environment.protocol+'://'+environment.ApiUrl+'/api/controles/busqueda';

  constructor( private http: HttpClient,
               private validationService :ValidationService) { }

  /** Permite setear controles*/
  setControles(): Observable<Control> {
     return of(new Control);
  }

  /** Trae los datos del servidor */
  getClontroles (): Observable<Control[]> {
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
   };
   return this.http.get<Control[]>(this.controlesUrl,httpOptions)
       .pipe(
           tap(controles => this.validationService.log(`trae controles`)),
           catchError(this.validationService.handleError('getClontroles', []))
       );
   }

   //////// Metodos para crud //////////

   /** POST: agrega un control al servidor */
   addControl (control: Control): Observable<Control> {
     const httpOptions = {
       headers: new HttpHeaders(
           {
             'Content-Type': 'application/json',
             'Authorization':'Bearer '+localStorage.getItem('token')
           }
         )
     };
     return this.http.post<Control>(`${this.controlesUrl}`, control, httpOptions).pipe(
       tap((control: Control) => this.validationService.log(`Agrega control w/ id=${control.id}`)),
       catchError(this.validationService.handleError<Control>('addControl'))
     );
   }

   /** PUT: actualiza control en el servidor */
  updateControl (control: Control): Observable<any> {
    const id = control.id;
    const url = `${this.controlesUrl}/${id}`;

    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
    return this.http.put(url, control, httpOptions).pipe(
      tap(_ => this.validationService.log(`updated control id=${control.id}`)),
      catchError(this.validationService.handleError<any>('updateControl'))
    );
  }

   /** DELETE: Borra control del servidor */
   deleteControl (control: Control | number): Observable<Control> {
     const id = typeof control === 'number' ? control : control.id;
     const url = `${this.controlesUrl}/${id}`;
     const httpOptions = {
       headers: new HttpHeaders(
           {
             'Content-Type': 'application/json',
             'Authorization':'Bearer '+localStorage.getItem('token')
           }
         )
     };

     return this.http.delete<Control>(url, httpOptions).pipe(
       tap(_ => this.validationService.log(`Borrar control  id=${id}`)),
       catchError(this.validationService.handleError<Control>('deleteControl'))
     );
   }


   /* GET busca controles por descripcion*/
  searchControl(term: string): Observable<Control[]> {
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
    return this.http.get<Control[]>(`${this.controlesSearchUrl}?nombre=${term}`,httpOptions).pipe(
      tap(_ => this.validationService.log(`Encuentra los controles "${term}"`)),
      catchError(this.validationService.handleError<Control[]>('searchControl', []))
    );
  }

}

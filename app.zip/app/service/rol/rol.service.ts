import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { ValidationService } from '../validation/validation.service';
import { ROLES } from '../../mocks/mock-rol';
import { Rol } from '../../class/rol';

@Injectable()
export class RolService {

  private rolesUrl = environment.protocol+'://'+environment.ApiUrl+'/api/roles';
  private rolesUrlDelete = environment.protocol+'://'+environment.ApiUrl+'/api/rol';

  constructor(private http: HttpClient,
               private validationService :ValidationService) { }

  /** Permite setear roles*/
  setRoles(): Observable<Rol> {
    return of(new Rol);
  }

  /** Trae los datos del servidor */
  getRoles (): Observable<Rol[]> {
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
    return this.http.get<Rol[]>(this.rolesUrl , httpOptions)
          .pipe(
            tap(roles => this.validationService.log(`trae roles`)),
            catchError(this.validationService.handleError('getRoles', []))
          );
  }

  //////// Metodos para crud //////////

  /** POST: agrega un rol al servidor */
  addRol (rol: Rol): Observable<Rol> {
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
    return this.http.post<Rol>(this.rolesUrl, rol, httpOptions).pipe(
      tap((rol: Rol) => this.validationService.log(`Agrega rol w/ id=${rol.id}`)),
      catchError(this.validationService.handleError<Rol>('addRol'))
    );
  }

  /** DELETE: Borra rol del servidor */
  deleteRol (rol: Rol | number): Observable<Rol> {
    const id = typeof rol === 'number' ? rol : rol.id;
    const url = `${this.rolesUrlDelete}/${id}`;
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
    return this.http.delete<Rol>(url, httpOptions).pipe(
      tap(_ => this.validationService.log(`Borrar rol id=${id}`)),
      catchError(this.validationService.handleError<Rol>('deleteRol'))
    );
  }

}

import { Injectable } from '@angular/core';

@Injectable()
export class ResumenEstadoService {

  public booResumenCotizacion : boolean = false;
  public opt:string;

  constructor() { }

    /*Setea el valor del estado del menu*/
    setEstadoResumenCotizacion(estado : boolean){
        this.booResumenCotizacion = estado;
    }

    /*Obtiene el valor del estado del menu*/
    getEstadoResumenCotizacion(){
        return this.booResumenCotizacion;
    }

    /*Setea el valor del la operacion*/
    setOptResumenCotizacion(opt : string){
        this.opt = opt;
    }

    /*Obtiene el valor de la operacion*/
    getOptResumenCotizacion(){
        return this.opt;
    }


}

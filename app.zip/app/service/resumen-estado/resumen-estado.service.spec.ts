import { TestBed, inject } from '@angular/core/testing';

import { ResumenEstadoService } from './resumen-estado.service';

describe('ResumenEstadoService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ResumenEstadoService]
    });
  });

  it('should be created', inject([ResumenEstadoService], (service: ResumenEstadoService) => {
    expect(service).toBeTruthy();
  }));
});

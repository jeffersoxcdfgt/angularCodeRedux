import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { ValidationService } from '../validation/validation.service';
import { Menu } from '../../class/menu';
import { MENUS } from '../../mocks/mock-menu';

@Injectable()
export class MenuService {

  private menusUrl = environment.protocol+'://'+environment.ApiUrl+'/api/menus';
  private menusUrlDelete = environment.protocol+'://'+environment.ApiUrl+'/api/menu/eliminar';
  private menusUrlSearch = environment.protocol+'://'+environment.ApiUrl+'/api/menus/busqueda';

  constructor(private http: HttpClient,
               private validationService :ValidationService) { }

   /** Permite setear menus*/
   setMenus(): Observable<Menu> {
      return of(new Menu);
  }

    /** Trae los datos del servidor */
   getMenus (): Observable<Menu[]> {
     const httpOptions = {
       headers: new HttpHeaders(
           {
             'Content-Type': 'application/json',
             'Authorization':'Bearer '+localStorage.getItem('token')
           }
         )
     };
       return this.http.get<Menu[]>(this.menusUrl,httpOptions)
          .pipe(
            tap(menus => this.validationService.log(`trae menus`)),
              catchError(this.validationService.handleError('getMenus', []))
        );
  }

  //////// Metodos para crud //////////

  /** POST: agrega un menu al servidor */
  addMenus (menu: Menu): Observable<Menu> {
    const url = `${this.menusUrl}`;
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
    return this.http.post<Menu>(url, menu, httpOptions).pipe(
      tap((menu: Menu) => this.validationService.log(`Agrega menu w/ id=${menu.id}`)),
      catchError(this.validationService.handleError<Menu>('addMenus'))
    );
  }

  /** PUT: actualiza menu en el servidor */
 updateMenu(menu: Menu ): Observable<any> {
   console.log('updateMenu');
   console.log(menu);
   const id = menu.id;
   const url = `${this.menusUrl}/${id}`;

   const httpOptions = {
     headers: new HttpHeaders(
         {
           'Content-Type': 'application/json',
           'Authorization':'Bearer '+localStorage.getItem('token')
         }
       )
   };
   return this.http.put(url,menu,httpOptions).pipe(
     tap(_ => this.validationService.log(`updated menu id=${menu.id}`)),
     catchError(this.validationService.handleError<any>('updateMenu'))
   );
 }

  /** DELETE: Borra menu del servidor */
  deleteMenu (menu: Menu | number): Observable<Menu> {
    const id = typeof menu === 'number' ? menu : menu.id;
    const url = `${this.menusUrlDelete}/${id}`;
    console.log('El id es '+id);
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };

    return this.http.delete<Menu>(url, httpOptions).pipe(
      tap(_ => this.validationService.log(`Borrar menu id=${id}`)),
      catchError(this.validationService.handleError<Menu>('deleteMenu'))
    );
  }

  /* Obtiene lista de menus filtrados*/
  searchMenus(term: string): Observable<Menu[]> {
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
    return this.http.get<Menu[]>(`${this.menusUrlSearch}?nombre=${term}`,httpOptions).pipe(
      tap(_ => this.validationService.log(`Lista de menus encontrados "${term}"`)),
      catchError(this.validationService.handleError<Menu[]>('searchMenus', []))
    );
  }
}

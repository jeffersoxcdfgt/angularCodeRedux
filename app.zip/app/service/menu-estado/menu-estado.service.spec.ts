import { TestBed, inject } from '@angular/core/testing';

import { MenuEstadoService } from './menu-estado.service';

describe('MenuEstadoService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MenuEstadoService]
    });
  });

  it('should be created', inject([MenuEstadoService], (service: MenuEstadoService) => {
    expect(service).toBeTruthy();
  }));
});

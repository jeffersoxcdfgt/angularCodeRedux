import { Injectable } from '@angular/core';
import { PgEstadoService } from '../pg-estado/pg-estado.service';
import { MisSolicitudesRcService } from '../mis-solicitudes-rc/mis-solicitudes-rc.service';
import { RESUMENCOTIZACION , FIRST } from '../../mocks/mock-resumen-cotizacion';
import { ResumenEstadoService } from '../resumen-estado/resumen-estado.service';

@Injectable()
export class MenuEstadoService {

  public booEstadoMenu : boolean = false;
  public list: any[];

   constructor(private pgEstadoService:PgEstadoService,
   private misSolicitudesRcService:MisSolicitudesRcService,
   private resumenEstadoService: ResumenEstadoService,){  }

    /*Setea el valor del estado del menu*/
    setMenuEstado(estado : boolean){

        //Resumen Cotizacion
        this.cleanData();
        this.resumenEstadoService.setOptResumenCotizacion('add');
        this.resumenEstadoService.setEstadoResumenCotizacion(false);

        //Portafolio general
        this.pgEstadoService.setMenuPg(false);
        this.pgEstadoService.setMenuPgFilters(false);

        //Mis Solicitudes
        this.misSolicitudesRcService.setMisSolicitudesEstado(false);
        this.misSolicitudesRcService.setMsOTsEstado(false);
        this.booEstadoMenu = estado;
    }


    cleanData():void{
      RESUMENCOTIZACION[FIRST].id='';
      RESUMENCOTIZACION[FIRST].nombre='';
      RESUMENCOTIZACION[FIRST].id_usuario_crea='';
      RESUMENCOTIZACION[FIRST].id_usuario_aprueba='';
      RESUMENCOTIZACION[FIRST].estado='';
      RESUMENCOTIZACION[FIRST].id_cliente= '';
      RESUMENCOTIZACION[FIRST].id_ot=[];
      RESUMENCOTIZACION[FIRST].id_prioridad='';
      RESUMENCOTIZACION[FIRST].SUBTOTAL_VENTA_COT='';
      RESUMENCOTIZACION[FIRST].BASE_EXCENTA='';
      RESUMENCOTIZACION[FIRST].BASE_GRAVABLE='';
      RESUMENCOTIZACION[FIRST].IVA='';
      RESUMENCOTIZACION[FIRST].TOTAL_VENTA='';
      RESUMENCOTIZACION[FIRST].TOTAL_COSTO='';
      RESUMENCOTIZACION[FIRST].usurio_crea_cotizacion='';
      RESUMENCOTIZACION[FIRST].destinatario_aprobador=[];
      RESUMENCOTIZACION[FIRST].detalle=[];
    }

    /*Obtiene el valor del estado del menu*/
    getMenuEstado(){
        return this.booEstadoMenu;
    }

    /*Guarda la lista*/
    setList(list : any[]){
        this.list = list;
    }
    /*Obtiene la lista*/
    getList(){
        return this.list;
    }

}

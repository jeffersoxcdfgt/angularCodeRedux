import { TestBed, inject } from '@angular/core/testing';

import { AssignNewPasswordService } from './assign-new-password.service';

describe('AssignNewPasswordService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AssignNewPasswordService]
    });
  });

  it('should be created', inject([AssignNewPasswordService], (service: AssignNewPasswordService) => {
    expect(service).toBeTruthy();
  }));
});

import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';

import { Newpassword } from '../../class/newpassword';
import { NEWPASSWORD } from '../../mocks/mock-assign-new-password';
import { environment } from '../../../environments/environment';
import { ValidationService } from '../validation/validation.service';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class AssignNewPasswordService {

  private loginUrlNewPassword = environment.protocol+'://'+environment.ApiUrl+'/api/actualizar_clave';

  constructor(
    private http: HttpClient,
    private validationService :ValidationService) { }

    sendNewPassword(): Observable<Newpassword[]> {
    // Todo: mensaje enviado despues de traer los datos
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
    return this.http.get<Newpassword[]>(this.loginUrlNewPassword,httpOptions)
    }

    getNewPssword(): Observable<Newpassword[]> {
      // TODO: send the message _after_ fetching data
      return of(NEWPASSWORD);
    }

    /** POST: add a new login to the server */
    addNewPassword (newpassword: Newpassword): Observable<Newpassword> {
       const httpOptions = {
         headers: new HttpHeaders(
            {
              'Content-Type': 'application/json',
              'Authorization':'Bearer '+localStorage.getItem('token')
            }
          )
       };
        return this.http.post<Newpassword>(this.loginUrlNewPassword, newpassword, httpOptions).pipe(
          tap( (newpassword: Newpassword) =>
          this.validationService.log(`${newpassword.mensaje}`)
        ),
        catchError(this.validationService.handleError<Newpassword>('Fallo al interntar cambiar password'))
        );
    }
}

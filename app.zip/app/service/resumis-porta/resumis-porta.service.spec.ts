import { TestBed, inject } from '@angular/core/testing';

import { ResumisPortaService } from './resumis-porta.service';

describe('ResumisPortaService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ResumisPortaService]
    });
  });

  it('should be created', inject([ResumisPortaService], (service: ResumisPortaService) => {
    expect(service).toBeTruthy();
  }));
});

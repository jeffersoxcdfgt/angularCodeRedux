import { Injectable } from '@angular/core';
import { ControlesSeguridad } from '../../class/controles_seguridad';

@Injectable()
export class ResumisPortaService {

  public booEstadoConSeguridad : boolean = false;
  public listSeguridad: ControlesSeguridad[];

  constructor() { }

  /*Setea el valor para listas los controles*/
  setControlesSeguridadEstado(estado : boolean){ this.booEstadoConSeguridad = estado; }
  /*Obtiene el valor del estado de los controles*/
  getControlesSeguridadsEstado(){ return this.booEstadoConSeguridad; }
  /*Guarda la lista de controles*/
  setControlesSeguridad(listSeguridad : ControlesSeguridad[]){this.listSeguridad = listSeguridad; }
  /*Obtiene la lista de controles*/
  getControlesSeguridad(){  return this.listSeguridad;}

}

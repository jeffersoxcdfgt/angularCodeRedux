import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { ValidationService } from '../validation/validation.service';
import { Perfil } from '../../class/perfil';
import { PERFIL } from '../../mocks/mock-perfil';
import { Saveperfil } from '../../class/save_perfil';

@Injectable()
export class PerfilesService {

  private perfilesUrl = environment.protocol+'://'+environment.ApiUrl+'/api/perfiles';
  private perfilesUrlDelete = environment.protocol+'://'+environment.ApiUrl+'/api/perfil_elimina';
  private perfilcombosUrl = environment.protocol+'://'+environment.ApiUrl+'/api/menu_controles';
  private savePerfilUrl = environment.protocol+'://'+environment.ApiUrl+'/api/perfiles';
  private searchPerfilUrl = environment.protocol+'://'+environment.ApiUrl+'/api/perfiles/busqueda';
  private searchPerfilUrlId = environment.protocol+'://'+environment.ApiUrl+'/api/perfiles';
  private perfilUpdateUrl = environment.protocol+'://'+environment.ApiUrl+'/api/perfiles';

  constructor( private http: HttpClient,
               private validationService :ValidationService
  ) { }

  /** Permite setear perfiles*/
  setPerfiles(): Observable<Perfil> {
      return of(new Perfil);
  }

  /** Trae los datos del servidor */
  getPerfiles (): Observable<Perfil[]> {
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
      return this.http.get<Perfil[]>(this.perfilesUrl,httpOptions)
         .pipe(
             tap(perfiles => this.validationService.log(`trae perfiles`)),
             catchError(this.validationService.handleError('getPerfiles', []))
         );
   }

   //////// Metodos para crud //////////

   /** POST: agrega un perfil al servidor */
   addPerfil (saveperfil: Saveperfil): Observable<Saveperfil> {
     const httpOptions = {
       headers: new HttpHeaders(
           {
             'Content-Type': 'application/json',
             'Authorization':'Bearer '+localStorage.getItem('token')
           }
         )
     };
     return this.http.post<Saveperfil>(this.savePerfilUrl, saveperfil, httpOptions).pipe(
       tap((saveperfil: Saveperfil) => this.validationService.log(`Agrega perfil w/ id=${saveperfil.nombre}`)),
       catchError(this.validationService.handleError<Saveperfil>('addPerfil'))
     );
   }

   /** PUT: actualiza perfil en el servidor */
  updatePerfil(saveperfil: Saveperfil ): Observable<any> {
    const id = saveperfil.id;
    const url = `${this.perfilUpdateUrl}/${id}`;

    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
    return this.http.put(url,saveperfil,httpOptions).pipe(
      tap(_ => this.validationService.log(`updated perfil id=${saveperfil.id}`)),
      catchError(this.validationService.handleError<any>('updatePerfil'))
    );
  }

   /** DELETE: Borra perfil del servidor */
   deletePerfil (perfil: Perfil | number): Observable<Perfil> {
     const id = typeof perfil === 'number' ? perfil : perfil.id;
     const url = `${this.perfilesUrlDelete}/${id}`;
     const httpOptions = {
       headers: new HttpHeaders(
           {
             'Content-Type': 'application/json',
             'Authorization':'Bearer '+localStorage.getItem('token')
           }
         )
     };
     return this.http.delete<Perfil>(url, httpOptions).pipe(
       tap(_ => this.validationService.log(`Borrar perfil id=${id}`)),
       catchError(this.validationService.handleError<Perfil>('deletePerfil'))
     );
   }

   /* GET busca perfiles por nombre*/
  searchPerfiles(term: string): Observable<Saveperfil[]> {
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
    return this.http.get<Saveperfil[]>(`${this.searchPerfilUrl}?nombre=${term}`,httpOptions).pipe(
      tap(_ => this.validationService.log(`Encuentra los perfiles "${term}"`)),
      catchError(this.validationService.handleError<Saveperfil[]>('searchPerfiles', []))
    );
  }

  /** Trae perfiles por id*/
  getPerfilEdit(id: number | string): Observable<any> {
    const url = `${this.searchPerfilUrlId}/${id}`;
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
    return this.http.get<any>(url,httpOptions).pipe(
      tap(_ => this.validationService.log(`Trae perfiles id=${id}`)),
      catchError(this.validationService.handleError<any>(`getPerfilEdit id=${id}`))
    );
  }

   /** lista todos los combos*/
   getListCombos (): Observable<any[]> {
     const httpOptions = {
       headers: new HttpHeaders(
           {
             'Content-Type': 'application/json',
             'Authorization':'Bearer '+localStorage.getItem('token')
           }
         )
    };
    return this.http.get<any[]>(this.perfilcombosUrl,httpOptions)
        .pipe(
            tap(combos => this.validationService.log(`trae combos`)),
            catchError(this.validationService.handleError('getListCombos', []))
        );
    }
}

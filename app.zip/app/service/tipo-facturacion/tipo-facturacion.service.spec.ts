import { TestBed, inject } from '@angular/core/testing';

import { TipoFacturacionService } from './tipo-facturacion.service';

describe('TipoFacturacionService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [TipoFacturacionService]
    });
  });

  it('should be created', inject([TipoFacturacionService], (service: TipoFacturacionService) => {
    expect(service).toBeTruthy();
  }));
});

import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ValidationService } from '../validation/validation.service';
import { Observable } from 'rxjs/Observable';
import { tap, catchError } from 'rxjs/operators';
import { TipoFacturacion } from '../../class/tipoFacturacion';

@Injectable()
export class TipoFacturacionService {
  private servicioUrl = environment.protocol+'://'+environment.ApiUrl+'/api/facturacion';
  
  constructor(private http: HttpClient,
    private validationService :ValidationService) { }

  
  /** Trae los datos del servidor */
  getFacturacion (): Observable<TipoFacturacion[]> {
    const httpOptions = {
        headers: new HttpHeaders(
            {
              'Content-Type': 'application/json',
              'Authorization':'Bearer '+localStorage.getItem('token')
            }
        )
    };
    return this.http.get<TipoFacturacion[]>(this.servicioUrl,httpOptions)
        .pipe(
            tap(facturacion => this.validationService.log(`trae Tipo facturacios`)),
            catchError(this.validationService.handleError('getFacturacion', []))
        );

  }


}

import { TestBed, inject } from '@angular/core/testing';

import { ClienteOtService } from './cliente-ot.service';

describe('ClienteOtService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ClienteOtService]
    });
  });

  it('should be created', inject([ClienteOtService], (service: ClienteOtService) => {
    expect(service).toBeTruthy();
  }));
});

import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { ValidationService } from '../validation/validation.service';
import { ClienteOt } from '../../class/cliente-ot';
import { CLIENTEOT } from '../../mocks/mock-cliente-ot';

@Injectable()
export class ClienteOtService {

  private clienteOtnUrl = environment.protocol+'://'+environment.ApiUrl+'/api/buscar_cliente_ots';

  constructor(private http: HttpClient,
               private validationService :ValidationService) { }

  /** Trae los datos las frecuencias de la integracion */
  getClienteOt (): Observable<ClienteOt[]> {
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
    return this.http.post<ClienteOt[]>(this.clienteOtnUrl,httpOptions)
      .pipe(
             tap(clienteots => this.validationService.log(`trae ot y clientes`)),
             catchError(this.validationService.handleError('getClienteOt', []))
      );
   }

}

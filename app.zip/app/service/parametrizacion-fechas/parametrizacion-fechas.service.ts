  import { Injectable } from '@angular/core';
  import { HttpClient, HttpHeaders } from '@angular/common/http';
  import { Observable } from 'rxjs/Observable';
  import { of } from 'rxjs/observable/of';
  import { catchError, map, tap } from 'rxjs/operators';
  import { environment } from '../../../environments/environment';
  import { ValidationService } from '../validation/validation.service';
  import { FechasType , ParametrizacionFechas } from '../../class/parametrizacion-fechas';
  import { FIRSTPARAMETRIZACION , PARAMETRIZACIONFECHAS } from '../../mocks/mock-parametrizacion-fechas';
  import { ListFicha  } from '../../class/listficha';
  import { LISTFICHA  } from '../../mocks/mock-listficha';
  import { FechasPlaneadas } from '../../class/fechas_planeadas';
  import { FECHASPLANEADAS  } from '../../mocks/mock-fechas-planeadas';


  @Injectable()
  export class ParametrizacionFechasService {

    private parametrizacionUrl = environment.protocol+'://'+environment.ApiUrl+'/api/parametrizacionFechas';
    private parametrizacionUpdateUrl = environment.protocol+'://'+environment.ApiUrl+'/api/updateFechas';
    private parametrizacionUrlSearch = environment.protocol+'://'+environment.ApiUrl+'/api/parametrizacionFechas';
    private frecuenciaUrl = environment.protocol+'://'+environment.ApiUrl+'/api/frecuencia';
    private combosUrl = environment.protocol+'://'+environment.ApiUrl+'/api/combosClientesOTFichas';
    private listMailsUrl = environment.protocol+'://'+environment.ApiUrl+'/api/listMails';
    private detalleFichaIdUrl = environment.protocol+'://'+environment.ApiUrl+'/api/detalleFichaId';
    private detalleFechasPlaneadasUrl = environment.protocol+'://'+environment.ApiUrl+'/api/getDetailFechasPlan';
    private dataOtsFicha =  environment.protocol+'://'+environment.ApiUrl+'/api/getFichasData';

    constructor( private http: HttpClient, private validationService :ValidationService) { }

    /** Permite setear parametrizacion*/
    setParametrizacion(): Observable<ParametrizacionFechas> {
        return of(new ParametrizacionFechas);
    }

    /** Trae los datos del servidor */
    getParametrizacion (): Observable<ParametrizacionFechas[]> {
      const httpOptions = {
        headers: new HttpHeaders(
            {
              'Content-Type': 'application/json',
              'Authorization':'Bearer '+localStorage.getItem('token')
            }
          )
      };
      return this.http.get<ParametrizacionFechas[]>(this.parametrizacionUrl,httpOptions)
        .pipe(
               tap(perfiles => this.validationService.log(`trae parametrizacion`)),
               catchError(this.validationService.handleError('getParametrizacion', []))
        );
     }

     //////// Metodos para crud //////////

     /** POST: agrega una parametrizacion al servidor */
     addParametrizacion (parametrizacionFechas: ParametrizacionFechas): Observable<ParametrizacionFechas> {
       const url = `${this.parametrizacionUrl}`;
       const httpOptions = {
         headers: new HttpHeaders(
             {
               'Content-Type': 'application/json',
               'Authorization':'Bearer '+localStorage.getItem('token')
             }
           )
       };
       return this.http.post<ParametrizacionFechas>(url, parametrizacionFechas, httpOptions).pipe(
         tap((parametrizacionFechas: ParametrizacionFechas) => this.validationService.log(`Agrega parametrizacion w/ id=${parametrizacionFechas.id}`)),
         catchError(this.validationService.handleError<ParametrizacionFechas>('addParametrizacion'))
       );
     }

     /** PUT: actualiza parametrizacion en el servidor */
    updateParametrizacion(parametrizacionFechas: ParametrizacionFechas ): Observable<any> {
      const url = `${this.parametrizacionUpdateUrl}`;
      const httpOptions = {
        headers: new HttpHeaders(
            {
              'Content-Type': 'application/json',
              'Authorization':'Bearer '+localStorage.getItem('token')
            }
          )
      };
      return this.http.put(url,parametrizacionFechas,httpOptions).pipe(
        tap(_ => this.validationService.log(`updated parametrizacion id=${parametrizacionFechas.id}`)),
        catchError(this.validationService.handleError<any>('updateParametrizacion'))
      );
    }

    /** DELETE: Borra parametrizacion del servidor */
    deleteParametrizacion (parametrizacionFechas: ParametrizacionFechas | number): Observable<ParametrizacionFechas> {
      const id = typeof parametrizacionFechas === 'number' ? parametrizacionFechas : parametrizacionFechas.id;
      const url = `${this.parametrizacionUrl}/${id}`;
      const httpOptions = {
        headers: new HttpHeaders(
            {
              'Content-Type': 'application/json',
              'Authorization':'Bearer '+localStorage.getItem('token')
            }
          )
      };
      return this.http.delete<ParametrizacionFechas>(url, httpOptions).pipe(
        tap(_ => this.validationService.log(`Borrar parametrizacion id=${id}`)),
        catchError(this.validationService.handleError<ParametrizacionFechas>('deleteParametrizacion'))
      );
    }

    /* GET busca parametrizacion */
   searchParametrizacion(term: string): Observable<ParametrizacionFechas[]> {
     const httpOptions = {
       headers: new HttpHeaders(
           {
             'Content-Type': 'application/json',
             'Authorization':'Bearer '+localStorage.getItem('token')
           }
         )
     };
     return this.http.get<ParametrizacionFechas[]>(`${this.parametrizacionUrl}?nombre=${term}`,httpOptions).pipe(
       tap(_ => this.validationService.log(`Encuentra los parametrizacion "${term}"`)),
       catchError(this.validationService.handleError<ParametrizacionFechas[]>('searchParametrizacion', []))
     );
   }

   /** Trae los datos las frecuencias de la integracion */
   getFrecuencia (): Observable<any[]> {
     const httpOptions = {
       headers: new HttpHeaders(
           {
             'Content-Type': 'application/json',
             'Authorization':'Bearer '+localStorage.getItem('token')
           }
         )
     };
     return this.http.get<any[]>(this.frecuenciaUrl,httpOptions)
       .pipe(
              tap(frecuencias => this.validationService.log(`trae frecuencias`)),
              catchError(this.validationService.handleError('getFrecuencia', []))
       );
    }

    /** Trae los datos del servidor */
    getCombos (): Observable<any[]> {
      const httpOptions = {
        headers: new HttpHeaders(
            {
              'Content-Type': 'application/json',
              'Authorization':'Bearer '+localStorage.getItem('token')
            }
          )
      };
      return this.http.get<any[]>(this.combosUrl,httpOptions)
        .pipe(
            tap(combos => this.validationService.log(`trae combos`)),
            catchError(this.validationService.handleError('getCombos', []))
        );
     }

     /** Trae los datos del servidor */
     getListMails (): Observable<any[]> {
       const httpOptions = {
         headers: new HttpHeaders(
             {
               'Content-Type': 'application/json',
               'Authorization':'Bearer '+localStorage.getItem('token')
             }
           )
       };
       return this.http.get<any[]>(this.listMailsUrl,httpOptions)
         .pipe(
             tap(listMails => this.validationService.log(`trae lista de mails`)),
             catchError(this.validationService.handleError('getListMails', []))
         );
      }

      /** Lista de fichas */
      getListFichas (): Observable<any[]> {
        const url = `${this.parametrizacionUrl}`;
        const httpOptions = {
          headers: new HttpHeaders(
              {
                'Content-Type': 'application/json',
                'Authorization':'Bearer '+localStorage.getItem('token')
              }
            )
        };
        return this.http.get<any[]>(url,httpOptions)
          .pipe(
              tap(combos => this.validationService.log(`trae lista de fichas`)),
              catchError(this.validationService.handleError('getListFichas', []))
          );
       }

       /** Trae las fichas por ot */
       getListFichasOt(id: number): Observable<ListFicha[]> {
          const url = `${this.parametrizacionUrlSearch}/${id}/edit`;
          const httpOptions = {
            headers: new HttpHeaders(
                {
                  'Content-Type': 'application/json',
                  'Authorization':'Bearer '+localStorage.getItem('token')
                }
              )
          };
          return this.http.get<ListFicha[]>(url,httpOptions).pipe(
            tap(_ => this.validationService.log(`Lista de fichas por Id=${id}`)),
            catchError(this.validationService.handleError<ListFicha[]>(`getListFichasOt id=${id}`))
          );
      }

        /** Fichas ya procesadas*/
        getFichasIdDetalle(listFicha: ListFicha |  number): Observable<any> {
          const id = typeof listFicha === 'number' ? listFicha : listFicha.id;
          const url = `${this.detalleFichaIdUrl}/${id}`;
          const httpOptions = {
            headers: new HttpHeaders(
                {
                  'Content-Type': 'application/json',
                  'Authorization':'Bearer '+localStorage.getItem('token')
                }
              )
          };
          return this.http.get<any>(url ,httpOptions).pipe(
            tap(_ => this.validationService.log(`lista los detalles de ficha procesadas id=${id}`)),
            catchError(this.validationService.handleError<any>(`getFichasIdDetalle id=${id}`))
          );
        }

        /** Trae las fechas planedas*/
        getFechasPlaneadas(id:  number): Observable<any> {
          const url = `${this.detalleFechasPlaneadasUrl}/${id}`;
          const httpOptions = {
            headers: new HttpHeaders(
                {
                  'Content-Type': 'application/json',
                  'Authorization':'Bearer '+localStorage.getItem('token')
                }
              )
          };
          return this.http.get<any>(url ,httpOptions).pipe(
            tap(_ => this.validationService.log(`lista las fechas planedas por id=${id}`)),
            catchError(this.validationService.handleError<any>(`getFechasPlaneadas id=${id}`))
          );
        }

        /**OBTENER todos los datos configurados en ficha tecnica*/
        getOtsForFicha(ot_env:string): Observable<any[]> {
         const url = `${this.dataOtsFicha}?OT_ENV=${ot_env}`;

         const httpOptions = {
           headers: new HttpHeaders(
               {
                 'Content-Type': 'application/json',
                 'Authorization':'Bearer '+localStorage.getItem('token')
               }
             )
         };
         return this.http.get<any[]>(url, httpOptions)
         .pipe(
             tap(_ => this.validationService.log(`Trae todos los datos que estan en ficha tecnica`)),
             catchError(this.validationService.handleError('getOtsForFicha', []))
         );
      }

  }

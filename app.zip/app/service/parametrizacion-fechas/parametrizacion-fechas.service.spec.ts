import { TestBed, inject } from '@angular/core/testing';

import { ParametrizacionFechasService } from './parametrizacion-fechas.service';

describe('ParametrizacionFechasService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ParametrizacionFechasService]
    });
  });

  it('should be created', inject([ParametrizacionFechasService], (service: ParametrizacionFechasService) => {
    expect(service).toBeTruthy();
  }));
});

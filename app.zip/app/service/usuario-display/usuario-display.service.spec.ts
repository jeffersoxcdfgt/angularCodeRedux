import { TestBed, inject } from '@angular/core/testing';

import { UsuarioDisplayService } from './usuario-display.service';

describe('UsuarioDisplayService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [UsuarioDisplayService]
    });
  });

  it('should be created', inject([UsuarioDisplayService], (service: UsuarioDisplayService) => {
    expect(service).toBeTruthy();
  }));
});

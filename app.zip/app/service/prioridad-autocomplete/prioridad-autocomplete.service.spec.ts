import { TestBed, inject } from '@angular/core/testing';

import { PrioridadAutocompleteService } from './prioridad-autocomplete.service';

describe('PrioridadAutocompleteService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PrioridadAutocompleteService]
    });
  });

  it('should be created', inject([PrioridadAutocompleteService], (service: PrioridadAutocompleteService) => {
    expect(service).toBeTruthy();
  }));
});

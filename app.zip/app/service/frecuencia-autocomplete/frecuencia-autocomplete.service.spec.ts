import { TestBed, inject } from '@angular/core/testing';

import { FrecuenciaAutocompleteService } from './frecuencia-autocomplete.service';

describe('FrecuenciaAutocompleteService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FrecuenciaAutocompleteService]
    });
  });

  it('should be created', inject([FrecuenciaAutocompleteService], (service: FrecuenciaAutocompleteService) => {
    expect(service).toBeTruthy();
  }));
});

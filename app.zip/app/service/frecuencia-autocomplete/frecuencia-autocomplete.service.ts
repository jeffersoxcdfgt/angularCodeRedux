import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { ValidationService } from '../validation/validation.service';
import { FRECUENCIA } from '../../mocks/mock-frecuencia';
import { Frecuencia } from '../../class/frecuencia';

@Injectable()
export class FrecuenciaAutocompleteService {

  private FrecuenciaUrl = environment.protocol+'://'+environment.ApiUrl+'/api/frecuencia';

  constructor(private http: HttpClient,
              private validationService :ValidationService) { }


    /** Trae el listado de frecuencias*/
    getFrecuencias (): Observable<Frecuencia[]> {
        const httpOptions = {
            headers: new HttpHeaders(
            {
                'Content-Type': 'application/json',
                'Authorization':'Bearer '+localStorage.getItem('token')
            }
          )
        };
        return this.http.get<Frecuencia[]>(this.FrecuenciaUrl,httpOptions)
            .pipe(
                tap(frecuencias => this.validationService.log(`trae frecuencias`)),
                catchError(this.validationService.handleError('getFrecuencias', []))
        );
    }

}

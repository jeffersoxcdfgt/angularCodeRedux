import { TestBed, inject } from '@angular/core/testing';

import { RolAutocompleteService } from './rol-autocomplete.service';

describe('RolAutocompleteService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [RolAutocompleteService]
    });
  });

  it('should be created', inject([RolAutocompleteService], (service: RolAutocompleteService) => {
    expect(service).toBeTruthy();
  }));
});

import { TestBed, inject } from '@angular/core/testing';

import { PgEstadoService } from './pg-estado.service';

describe('PgEstadoService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PgEstadoService]
    });
  });

  it('should be created', inject([PgEstadoService], (service: PgEstadoService) => {
    expect(service).toBeTruthy();
  }));
});

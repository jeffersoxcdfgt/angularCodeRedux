import { Injectable } from '@angular/core';

@Injectable()
export class PgEstadoService {

  public booEstadoPg : boolean = false;
  public listPg: any[];

  public booEstadoPgFilters : boolean = false;
  public listPgFilters: any[];

  constructor() { }

  /*Setea el valor del Portafolio general*/
  setMenuPg(estado : boolean){ this.booEstadoPg = estado; }
  /*Obtiene el valor del Portafolio general*/
  getMenuPg(){ return this.booEstadoPg; }
  /*Guarda la lista*/
  setListPg(listPg : any[]){this.listPg = listPg; }
  /*Obtiene la lista*/
  getListPg(){  return this.listPg;}


  //Filtros

  /*Setea el valor del Portafolio general filtros*/
  setMenuPgFilters(estado : boolean){ this.booEstadoPgFilters = estado; }
  /*Obtiene el valor del Portafolio general filtros*/
  getMenuPgFilters(){ return this.booEstadoPgFilters; }
  /*Guarda la lista*/
  setListPgFilters(listPgFilters : any[]){this.listPgFilters = listPgFilters; }
  /*Obtiene la lista*/
  getListPgFilters(){  return this.listPgFilters;}

}

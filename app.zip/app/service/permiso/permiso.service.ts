import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { ValidationService } from '../validation/validation.service';
import { Permiso } from '../../class/permiso';
import { PERMISOS } from '../../mocks/mock-permiso';

@Injectable()
export class PermisoService {
  private permisosUrl = environment.protocol+'://'+environment.ApiUrl+'/api/permisos';
  private permisosUrlDelete = environment.protocol+'://'+environment.ApiUrl+'/api/permiso/eliminar';
  private permisosUrlSearch = environment.protocol+'://'+environment.ApiUrl+'/api/permiso/busqueda';

  constructor(private http: HttpClient,
               private validationService :ValidationService) { }

  /** Permite setear permisos*/
  setPermisos(): Observable<Permiso> {
      return of(new Permiso);
  }

  /** Trae los datos del servidor */
  getPermisos (): Observable<Permiso[]> {
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
    return this.http.get<Permiso[]>(this.permisosUrl,httpOptions)
          .pipe(tap(permisos => this.validationService.log(`trae permisos`)),
            catchError(this.validationService.handleError('getPermisos', []))
          );
  }

  //////// Metodos para crud //////////

  /** POST: agrega un permiso al servidor */
  addPermiso (permiso: Permiso): Observable<Permiso> {
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
    return this.http.post<Permiso>(this.permisosUrl, permiso, httpOptions).pipe(
      tap((permiso: Permiso) => this.validationService.log(`Agrega permiso w/ id=${permiso.id}`)),
      catchError(this.validationService.handleError<Permiso>('addPermiso'))
    );
  }

  /** PUT: actualiza permiso en el servidor */
 updatePermiso (permiso: Permiso ): Observable<any> {
   const id = permiso.id;
   const url = `${this.permisosUrl}/${id}`;
   const httpOptions = {
     headers: new HttpHeaders(
         {
           'Content-Type': 'application/json',
           'Authorization':'Bearer '+localStorage.getItem('token')
         }
       )
   };
   return this.http.put(url, permiso, httpOptions).pipe(
     tap(_ => this.validationService.log(`actualiza permiso id=${permiso.id}`)),
     catchError(this.validationService.handleError<any>('updatePermiso'))
   );
 }

  /** DELETE: Borra rol del servidor */
  deletePermiso (permiso: Permiso | number): Observable<Permiso> {
    const id = typeof permiso === 'number' ? permiso : permiso.id;
    const url = `${this.permisosUrlDelete}/${id}`;
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
    return this.http.delete<Permiso>(url, httpOptions).pipe(
      tap(_ => this.validationService.log(`Borrar permiso id=${id}`)),
      catchError(this.validationService.handleError<Permiso>('deletePermiso'))
    );
  }

  /* GET busca permisos por nombre*/
 searchPermisos(term: string): Observable<Permiso[]> {
   const httpOptions = {
     headers: new HttpHeaders(
         {
           'Content-Type': 'application/json',
           'Authorization':'Bearer '+localStorage.getItem('token')
         }
       )
   };
   return this.http.get<Permiso[]>(`${this.permisosUrlSearch}?nombre=${term}`,httpOptions).pipe(
     tap(_ => this.validationService.log(`Encuentra los permisos "${term}"`)),
     catchError(this.validationService.handleError<Permiso[]>('searchPermisos', []))
   );
 }

}

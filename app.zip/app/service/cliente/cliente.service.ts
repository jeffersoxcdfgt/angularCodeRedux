import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { ValidationService } from '../validation/validation.service';
import { Cliente } from '../../class/cliente';
import { CLIENTE } from '../../mocks/mock-cliente';

@Injectable()
export class ClienteService {

   private clientesUrl = environment.protocol+'://'+environment.ApiUrl+'/api/clientes';
   private clientesUrlDelete = environment.protocol+'://'+environment.ApiUrl+'/api/cliente/eliminar';
   private clientesSearch = environment.protocol+'://'+environment.ApiUrl+'/api/cliente/buscar';

  constructor( private http: HttpClient,
                private validationService :ValidationService) { }


   /** Permite setear clientes*/
   setClientes(): Observable<Cliente> {
      return of(new Cliente);
   }

   /** Trae los datos del servidor */
   getClientes (): Observable<Cliente[]> {
     const httpOptions = {
       headers: new HttpHeaders(
           {
             'Content-Type': 'application/json',
             'Authorization':'Bearer '+localStorage.getItem('token')
           }
         )
    };
    return this.http.get<Cliente[]>(this.clientesUrl,httpOptions)
        .pipe(
            tap(clientes => this.validationService.log(`trae clientes`)),
            catchError(this.validationService.handleError('getClientes', []))
        );
    }

    //////// Metodos para crud //////////

    /** POST: agrega un cliente al servidor */
    addCliente (cliente: Cliente): Observable<Cliente> {
      const httpOptions = {
        headers: new HttpHeaders(
            {
              'Content-Type': 'application/json',
              'Authorization':'Bearer '+localStorage.getItem('token')
            }
          )
      };
      return this.http.post<Cliente>(this.clientesUrl, cliente, httpOptions).pipe(
        tap((cliente: Cliente) => this.validationService.log(`Agrega cliente w/ id=${cliente.id}`)),
        catchError(this.validationService.handleError<Cliente>('addCliente'))
      );
    }

    /** PUT: actualiza cliente en el servidor */
   updateCliente (cliente: Cliente): Observable<any> {
     const id = cliente.id;
     const url = `${this.clientesUrl}/${id}`;

     const httpOptions = {
       headers: new HttpHeaders(
           {
             'Content-Type': 'application/json',
             'Authorization':'Bearer '+localStorage.getItem('token')
           }
         )
     };
     return this.http.put(url, cliente, httpOptions).pipe(
       tap(_ => this.validationService.log(`updated cliente id=${cliente.id}`)),
       catchError(this.validationService.handleError<any>('updateCliente'))
     );
   }

    /** DELETE: Borra cliente del servidor */
    deleteCliente (cliente: Cliente | number): Observable<Cliente> {
      const id = typeof cliente === 'number' ? cliente : cliente.id;
      const url = `${this.clientesUrlDelete}/${id}`;
      const httpOptions = {
        headers: new HttpHeaders(
            {
              'Content-Type': 'application/json',
              'Authorization':'Bearer '+localStorage.getItem('token')
            }
          )
      };

      return this.http.delete<Cliente>(url, httpOptions).pipe(
        tap(_ => this.validationService.log(`Borrar cliente  id=${id}`)),
        catchError(this.validationService.handleError<Cliente>('deleteCliente'))
      );
    }

    /* GET busca clientes por nit*/
   searchCliente(term: string): Observable<Cliente[]> {
     const httpOptions = {
       headers: new HttpHeaders(
           {
             'Content-Type': 'application/json',
             'Authorization':'Bearer '+localStorage.getItem('token')
           }
         )
     };
     return this.http.get<Cliente[]>(`${this.clientesSearch}?nombre=${term}`,httpOptions).pipe(
       tap(_ => this.validationService.log(`Encuentra los clientes "${term}"`)),
       catchError(this.validationService.handleError<Cliente[]>('searchCliente', []))
     );
   }
}

import { TestBed, inject } from '@angular/core/testing';

import { SubcategoriasService } from './subcategorias.service';

describe('SubcategoriasService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SubcategoriasService]
    });
  });

  it('should be created', inject([SubcategoriasService], (service: SubcategoriasService) => {
    expect(service).toBeTruthy();
  }));
});

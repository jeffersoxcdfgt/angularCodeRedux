import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { ValidationService } from '../validation/validation.service';
import { SUBCATEGORIA } from '../../mocks/mock-subcategoria';
import { Subcategoria } from '../../class/subcategoria';
import { FiltroCategoria } from '../../class/filtro_categoria';

@Injectable()
export class SubcategoriasService {

  private SubcategoriaUrl = environment.protocol+'://'+environment.ApiUrl+'/api/subcategorias';

  constructor(private http: HttpClient,
            private validationService :ValidationService) { }

  /** Obtiene subcategorias por Id */
  getSubcategoria(filtroCategoria: FiltroCategoria []): Observable<FiltroCategoria[]> {
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
    return this.http.post<FiltroCategoria[]>(this.SubcategoriaUrl,filtroCategoria,httpOptions).pipe(
      tap(_ => this.validationService.log(`Obtiene subcategorias`)),
      catchError(this.validationService.handleError<FiltroCategoria[]>(`getSubcategoria`))
    );
  }

}

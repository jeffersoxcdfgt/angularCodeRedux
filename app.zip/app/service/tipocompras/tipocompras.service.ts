import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { ValidationService } from '../validation/validation.service';
import { TIPOCOMPRA } from '../../mocks/mock-tipocompra';
import { Tipocompra } from '../../class/tipocompra';

@Injectable()
export class TipocomprasService {

  private TipoCompraUrl = environment.protocol+'://'+environment.ApiUrl+'/api/tipo_compra/buscar';

  constructor(private http: HttpClient,
              private validationService :ValidationService) { }


  /** Trae el listado de tipos de compras */
  getTipoCompras (): Observable<Tipocompra[]> {
        const httpOptions = {
          headers: new HttpHeaders(
              {
                'Content-Type': 'application/json',
                'Authorization':'Bearer '+localStorage.getItem('token')
              }
            )
        };
        return this.http.get<Tipocompra[]>(this.TipoCompraUrl,httpOptions)
          .pipe(
                tap(tipocompras => this.validationService.log(`trae tiposcompra`)),
              catchError(this.validationService.handleError('getTipoCompras', []))
          );
  }

}

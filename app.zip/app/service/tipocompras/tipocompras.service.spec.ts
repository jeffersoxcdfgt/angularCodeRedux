import { TestBed, inject } from '@angular/core/testing';

import { TipocomprasService } from './tipocompras.service';

describe('TipocomprasService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [TipocomprasService]
    });
  });

  it('should be created', inject([TipocomprasService], (service: TipocomprasService) => {
    expect(service).toBeTruthy();
  }));
});

import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { ValidationService } from '../validation/validation.service';
import { TIPOUSUARIO } from '../../mocks/mock-tipousuario';
import { Tipousuario } from '../../class/tipo-usuario';

@Injectable()
export class TipoUsuarioService {

  private tipousuarioUrl = environment.protocol+'://'+environment.ApiUrl+'/api/tipos_usuarios';
  private tipousuarioUrlDelete = environment.protocol+'://'+environment.ApiUrl+'/api/tipo_usuario';

  constructor(private http: HttpClient,
               private validationService :ValidationService) { }

  /** Permite setear tipousuarios*/
   setTipousuarios(): Observable<Tipousuario> {
      return of(new Tipousuario);
  }


  /** Trae los datos del servidor */
  getTipousuarios (): Observable<Tipousuario[]> {
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
    return this.http.get<Tipousuario[]>(this.tipousuarioUrl,httpOptions)
          .pipe(
            tap(tipousuarios => this.validationService.log(`trae tipousuarios`)),
            catchError(this.validationService.handleError('getTipousuarios', []))
          );
  }

  //////// Metodos para crud //////////

  /** POST: agrega un tipousuario al servidor */
  addTipousuario (tipousuario: Tipousuario): Observable<Tipousuario> {
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
    return this.http.post<Tipousuario>(this.tipousuarioUrl, tipousuario, httpOptions).pipe(
      tap((tipousuario: Tipousuario) => this.validationService.log(`Agrega tipousuario w/ id=${tipousuario.id}`)),
      catchError(this.validationService.handleError<Tipousuario>('addTipousuario'))
    );
  }

  /** DELETE: Borra tipousuario del servidor */
  deleteTipousuario (tipousuario: Tipousuario | number): Observable<Tipousuario> {
    const id = typeof tipousuario === 'number' ? tipousuario : tipousuario.id;
    const url = `${this.tipousuarioUrlDelete}/${id}`;
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
    return this.http.delete<Tipousuario>(url, httpOptions).pipe(
      tap(_ => this.validationService.log(`Borrar tipousuario id=${id}`)),
      catchError(this.validationService.handleError<Tipousuario>('deleteTipousuario'))
    );
  }

}

import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { ValidationService } from '../validation/validation.service';
import { TipoSolicitud } from '../../class/tiposolicitud';
import { TIPOSOLICITUD } from '../../mocks/mock-tiposolicitud';

@Injectable()
export class TiposolicitudService {

      private tipoSolicitudUrl = environment.protocol+'://'+environment.ApiUrl+'/api/tipoSolicitud';

      constructor(private http: HttpClient,
                   private validationService :ValidationService) { }

      /** Permite setear tipos de solicitud*/
      setTiposSolicitud(): Observable<TipoSolicitud> {
           return of(new TipoSolicitud);
      }

      /** Trae los datos del servidor */
      getTiposSolicitud (): Observable<TipoSolicitud[]> {
        const httpOptions = {
          headers: new HttpHeaders(
              {
                'Content-Type': 'application/json',
                'Authorization':'Bearer '+localStorage.getItem('token')
              }
            )
        };
        return this.http.get<TipoSolicitud[]>(this.tipoSolicitudUrl,httpOptions)
              .pipe(tap(tiposolicitud => this.validationService.log(`trae tipos de solicitud`)),
                catchError(this.validationService.handleError('getTiposSolicitud', []))
              );
      }

}

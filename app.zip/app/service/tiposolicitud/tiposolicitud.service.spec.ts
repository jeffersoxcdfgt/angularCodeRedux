import { TestBed, inject } from '@angular/core/testing';

import { TiposolicitudService } from './tiposolicitud.service';

describe('TiposolicitudService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [TiposolicitudService]
    });
  });

  it('should be created', inject([TiposolicitudService], (service: TiposolicitudService) => {
    expect(service).toBeTruthy();
  }));
});

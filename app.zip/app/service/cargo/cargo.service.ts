import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ValidationService } from '../validation/validation.service';
import { Observable } from 'rxjs/Observable';
import { tap, catchError } from 'rxjs/operators';

@Injectable()
export class CargoService {
  private servicioUrl = environment.protocol+'://'+environment.ApiUrl+'/api/cargo/busqueda';

  constructor(private http: HttpClient, private validationService :ValidationService) { }

    /** Trae los datos del servidor */
  getCargos (): Observable<any[]> {
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
    return this.http.get<any[]>(this.servicioUrl,httpOptions)
        .pipe(
          tap(Cargos => this.validationService.log('trae getCargos')),
            catchError(this.validationService.handleError('getCargos', []))
      );
  }

}

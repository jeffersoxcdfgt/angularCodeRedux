import { TestBed, inject } from '@angular/core/testing';

import { SearchFichaTecnicaService } from './search-ficha-tecnica.service';

describe('SearchFichaTecnicaService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SearchFichaTecnicaService]
    });
  });

  it('should be created', inject([SearchFichaTecnicaService], (service: SearchFichaTecnicaService) => {
    expect(service).toBeTruthy();
  }));
});

import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ValidationService } from '../validation/validation.service';
import { Observable } from 'rxjs/Observable';
import { FichaTecnica } from '../../class/ficha-tecnica';
import { of } from 'rxjs/observable/of';
import { tap, catchError } from 'rxjs/operators';
import { DetalleFicha } from '../../class/ficha-detalle';
import { DetalleFechas } from '../../class/detalle_fechas';
import { Paginate } from '../../class/paginate';
import { MisSolicitudes } from '../../class/mis-solicitudes';
import { Usuario } from '../../class/usuario';

@Injectable()
export class FichaTecnicaService {
  private servicioUrl = environment.protocol+'://'+environment.ApiUrl+'/api/ficha';
  private servicioUrlDetalleFicha = environment.protocol+'://'+environment.ApiUrl+'/api/detalle_fecha_por_ot';
  private servicioUrlFechas = environment.protocol+'://'+environment.ApiUrl+'/api/detalle_fecha';
  private serviceUrlFile = environment.protocol+'://'+environment.ApiUrl+'/api/load_image';
  private portafolioEspecifico = environment.protocol+'://'+environment.ApiUrl+'/api/getPortafolioEspecifico';
  private serviceUrlSolicitarAprobar = environment.protocol+'://'+environment.ApiUrl+'/api/solicitudes';

  //Nuevo con todos los datos
  private serviceUrlAll = environment.protocol+'://'+environment.ApiUrl+'/api/load_ctr';
  typeMessage: string;
  mensaje: string;
  constructor(private http: HttpClient,
    private validationService :ValidationService) { }


  /** Permite setear clientes*/
  setFiha(): Observable<FichaTecnica> {
    return of(new FichaTecnica);
  }

  /** get all data */
  getData(): Observable<any>{
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
      )
    };
    return this.http.get<any[]>(this.serviceUrlAll, httpOptions)
    .pipe(
        tap(dataAll => this.validationService.log(`trae toda la data`)),
        catchError(this.validationService.handleError('getData', []))
    );
  }


  /** Trae los datos del servidor */
  getFichasPortafolioEspecifico(): Observable<FichaTecnica[]> {
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
    return this.http.get<FichaTecnica[]>(this.portafolioEspecifico,httpOptions)
      .pipe(
             tap(portafoliosespecificos => this.validationService.log(`trae lista de portafolios especificos`)),
             catchError(this.validationService.handleError('getFichasPortafolioEspecifico', []))
      );
   }

  /** Trae los datos del servidor */
  getFichas (searchDatos): Observable<FichaTecnica> {
    const httpOptions = {
        headers: new HttpHeaders(
            {
              'Content-Type': 'application/json',
              'Authorization':'Bearer '+localStorage.getItem('token')
            }
        )
    };
    //this.servicioUrl+'/'+ot   busqueda_detalle_ficha
    const url = environment.protocol+'://'+environment.ApiUrl+'/api/busqueda_detalle_ficha';
    return this.http.post<FichaTecnica>(url,searchDatos, httpOptions);
        //.map ((resp: any)=>resp.detalle);
        /*.pipe(
            tap(fichas => this.validationService.log(`trae Fichas tecnicas`)),
            catchError(this.validationService.handleError('getFicha', []))
        );*/

  }

  /** Delete: agrega un cliente al servidor */
  addFicha (ficha: FichaTecnica): Observable<FichaTecnica> {
    console.log("llego al servicio");
    console.log(ficha);
    const url = `${this.servicioUrl}`;

    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
    return this.http.post<FichaTecnica>(url, ficha, httpOptions).pipe(
      tap((ficha: FichaTecnica) => this.validationService.log(`Agrega ficha w/ id=${ficha.id}`)),
      catchError(this.validationService.handleError<FichaTecnica>('addficha'))
    );
  }

  deleteLineFicha(id: string){
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
    return this.http.delete(this.servicioUrl+'/'+id, httpOptions)
      .map((resp:any)=>{
        this.typeMessage = resp.tipoMensaje;
        this.mensaje = resp.mensaje;
        return resp.detalle;
      });
  }

  updateDetalleFicha(ficha: FichaTecnica){
    const id = typeof FichaTecnica === 'number' ? ficha : ficha.id;
    const url = `${this.servicioUrl}/${id}`;

    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
    return this.http.put(url, ficha, httpOptions)
      .map((resp:any)=>{return resp;});
  }
  /*updateDetalleFicha(detalleFicha: DetalleFicha){
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
    return this.http.put(this.servicioUrl+'/'+detalleFicha.id, detalleFicha, httpOptions)
      .map((resp:any)=>{return resp.detalleFicha;});
  }*/


  /** Trae los datos del servidor */
  getDetalleFichas (ot): Observable<Paginate> {
    const httpOptions = {
        headers: new HttpHeaders(
            {
              'Content-Type': 'application/json',
              'Authorization':'Bearer '+localStorage.getItem('token')
            }
        )
    };
    return this.http.get<Paginate>(this.servicioUrlDetalleFicha+'/'+ot,httpOptions);
  }


  /** Trae los datos de las fechas */
  getFechas (id): Observable<DetalleFechas[]> {
    const httpOptions = {
        headers: new HttpHeaders(
            {
              'Content-Type': 'application/json',
              'Authorization':'Bearer '+localStorage.getItem('token')
            }
        )
    };
    return this.http.get<DetalleFechas[]>(this.servicioUrlFechas+'/'+id,httpOptions);
  }

  postFileImagen(imagenForIpload: File, nit: string): Observable<any>{ //serviceUrlFile
    /*const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
      )
    };*/
    let headers = new HttpHeaders().set('Authorization', 'Bearer ' + localStorage.getItem('token'));
    const formData: FormData = new FormData();
    formData.append('image_cliente', imagenForIpload, imagenForIpload.name);
    formData.append('nit', nit);
    return this.http.post(this.serviceUrlFile,formData,{ headers: headers });
  }

  /*Envio del archivo al servidor ,para envio de mail*/
  /*postFile(fileToUpload: File , email:string): Observable<any> {
    const endpoint = this.SendMailUrl;
    const formData: FormData = new FormData();
    let headers = new HttpHeaders().set('Authorization', 'Bearer ' + localStorage.getItem('token'));
    formData.append('correo', email);
    formData.append('filename', fileToUpload, fileToUpload.name);
    return this.http.post(endpoint, formData, { headers: headers }).pipe(
      tap((data: any) => this.validationService.log(`Envio de mail`)),
         catchError(this.validationService.handleError<any>('sendMail'))
    );
  }*/

  sendAprobar(solicitudes: MisSolicitudes){
    //serviceUrlSolicitarAprobar
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
    const serviceUrlSolicitarAprobar2 = environment.protocol+'://'+environment.ApiUrl+'/api/envioAprobarFicha';
    return this.http.post<FichaTecnica>(serviceUrlSolicitarAprobar2, solicitudes, httpOptions);
  }

  getAprobadores2 (ot): Observable<any> {
    const httpOptions = {
        headers: new HttpHeaders(
            {
              'Content-Type': 'application/json',
              'Authorization':'Bearer '+localStorage.getItem('token')
            }
        )
    };
    const serviceUrlSolicitarAprobar = environment.protocol+'://'+environment.ApiUrl+'/api/usuariosAprobadores';
    return this.http.get<any>(serviceUrlSolicitarAprobar+'/'+ot,httpOptions);
  }

  /** Trae los datos del servidor */
  getFichaCargos (ot): Observable<any> {
    const httpOptions = {
        headers: new HttpHeaders(
            {
              'Content-Type': 'application/json',
              'Authorization':'Bearer '+localStorage.getItem('token')
            }
        )
    };
    //this.servicioUrl+'/'+ot   busqueda_detalle_ficha
    const url = environment.protocol+'://'+environment.ApiUrl+'/api/cargos_ctr/'+ot;
    return this.http.get<any[]>(url, httpOptions);

  }

  aprobarDetalleFicha(ficha: FichaTecnica){
    //debugger;
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
    const url = environment.protocol+'://'+environment.ApiUrl+'/api/aprobar_ficha/'+ficha.id;
    return this.http.put(url, ficha, httpOptions)
      .map((resp:any)=>{return resp;});
  }
}

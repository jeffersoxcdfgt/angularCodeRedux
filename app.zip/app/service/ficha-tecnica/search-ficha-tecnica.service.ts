import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { SearchFichaTecnica } from '../../class/searchFichaTecnica';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ValidationService } from '../validation/validation.service';
import { Observable } from 'rxjs/Observable';
import { map, tap } from 'rxjs/operators';

@Injectable()
export class SearchFichaTecnicaService {
  private servicioUrl = environment.protocol+'://'+environment.ApiUrl+'/api/categoriasPorOt';
  searchFichaTecnica: SearchFichaTecnica;

  constructor(private http: HttpClient,  private validationService :ValidationService) { }

  /**Trae los datos del servidor */
  getFicha(ot: string): Observable<SearchFichaTecnica>{
    const url = `${this.servicioUrl}/${ot}`;
    const httpOptions = {
      headers: new HttpHeaders(
        {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer '+localStorage.getItem('token')
        }
      )
    };
    return this.http.get<SearchFichaTecnica>(url,httpOptions)
      .pipe(
        map((resultado)=>{
          this.searchFichaTecnica= resultado
          return this.searchFichaTecnica
        }),
        tap(searchFichaTecnica=>this.validationService.log(`trae busqueda ficha`)),
        //catchError(this.validationService.handleError('getFicha', []))
      );

  }

}

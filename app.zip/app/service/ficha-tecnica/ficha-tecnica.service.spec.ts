import { TestBed, inject } from '@angular/core/testing';

import { FichaTecnicaService } from './ficha-tecnica.service';

describe('FichaTecnicaService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FichaTecnicaService]
    });
  });

  it('should be created', inject([FichaTecnicaService], (service: FichaTecnicaService) => {
    expect(service).toBeTruthy();
  }));
});

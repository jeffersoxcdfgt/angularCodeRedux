import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { ValidationService } from '../validation/validation.service';
import { Usuario } from '../../class/usuario';
import { USUARIO } from '../../mocks/mock-usuario';

@Injectable()
export class UsuarioAutocompleteComboboxService {

  private usuariosUrl = environment.protocol+'://'+environment.ApiUrl+'/api/usuarios';

  /**Constructur para injectar dependencias**/
  constructor(private http: HttpClient,private validationService :ValidationService){
  }

  /** Trae los datos del servidor */
  getUsuarios (): Observable<Usuario[]> {
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
    return this.http.get<Usuario[]>(this.usuariosUrl , httpOptions)
      .pipe(
        tap(usuarios => this.validationService.log(`trae usuarios`)),
        catchError(this.validationService.handleError('getUsuarios', []))
      );
  }

}

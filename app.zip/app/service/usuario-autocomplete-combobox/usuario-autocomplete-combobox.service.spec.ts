import { TestBed, inject } from '@angular/core/testing';

import { UsuarioAutocompleteComboboxService } from './usuario-autocomplete-combobox.service';

describe('UsuarioAutocompleteComboboxService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [UsuarioAutocompleteComboboxService]
    });
  });

  it('should be created', inject([UsuarioAutocompleteComboboxService], (service: UsuarioAutocompleteComboboxService) => {
    expect(service).toBeTruthy();
  }));
});

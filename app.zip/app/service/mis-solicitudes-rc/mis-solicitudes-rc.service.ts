import { Injectable } from '@angular/core';
import { MisSolicitudes } from '../../class/mis-solicitudes';
import { MISSOLICITUDES } from '../../mocks/mock-mis-solicitudes';
import { CLIENTEOT } from '../../mocks/mock-cliente-ot';
import { ClienteOt } from '../../class/cliente-ot';

@Injectable()
export class MisSolicitudesRcService {

  public booEstadoMs : boolean = false;
  public listMisSolicitudes: MisSolicitudes[] =  [];

  public booEstadoFiltroOt  : boolean = false;
  public listMiSoOT: ClienteOt[];

  public listMiClie: ClienteOt[];

  constructor() { }

  /*Setea el valor para Mis solicitudes*/
  setMisSolicitudesEstado(estado : boolean){ this.booEstadoMs = estado; }
  /*Obtiene el valor de Mis solicitudes*/
  getMisSolicitudesEstado(){ return this.booEstadoMs; }
  /*Guarda la lista*/
  setMisSolicitudes(listMisSolicitudes : MisSolicitudes[]){this.listMisSolicitudes = listMisSolicitudes; }
  /*Obtiene la lista*/
  getlistMisSolicitudes(){  return this.listMisSolicitudes;}
  //Agrega una nueva Solicitud
  add(msolicitud:MisSolicitudes ) {this.listMisSolicitudes.push(msolicitud);}
  //Update una nueva Solicitud
  update(msolicitud:MisSolicitudes , id:string ) {
    var index = this.listMisSolicitudes.findIndex(obj => obj.ID== id);
    this.listMisSolicitudes[index] = msolicitud;
  }


 //Filtros
 //Filtro de Ots
 /*Setea el valor para Mis ots en los filtros*/
 setMsOTsEstado(estado : boolean){ this.booEstadoFiltroOt = estado; }
 /*Obtiene el valor del filtro de las OTs*/
 getMsOTEstado(){ return this.booEstadoFiltroOt; }
 /*Guarda la lista*/
 setMsOTSolicitudes(lisOTs : ClienteOt[]){this.listMiSoOT = lisOTs; }
 /*Obtiene la lista*/
 getMsListOTs(){  return this.listMiSoOT;}

  //set los cliente unificados
 setClienteUnificada(clientUni : ClienteOt[]){this.listMiClie = clientUni; }
 //Trae los cliente unificados
 getClienteUnificada(){  return this.listMiClie;}

}

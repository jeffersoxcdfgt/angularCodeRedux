import { TestBed, inject } from '@angular/core/testing';

import { MisSolicitudesRcService } from './mis-solicitudes-rc.service';

describe('MisSolicitudesRcService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MisSolicitudesRcService]
    });
  });

  it('should be created', inject([MisSolicitudesRcService], (service: MisSolicitudesRcService) => {
    expect(service).toBeTruthy();
  }));
});

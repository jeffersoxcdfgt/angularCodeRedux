import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpClient, HttpHeaders , HttpParams } from '@angular/common/http';
import { of } from 'rxjs/observable/of';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/delay';
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { ValidationService } from '../validation/validation.service';
import { LoginService } from '../login/login.service';
import { Login } from '../../class/login';
import { Token } from '../../class/token';
import { LOGIN } from '../../mocks/mock-login';


@Injectable()
export class AuthService {
  isLoggedIn = false;
  // store the URL so we can redirect after logging in
  redirectUrl: string;
  token :string;
  private tokenKillUrl = environment.protocol+'://'+environment.ApiUrl+'/api/cerrar_sesion';

  constructor( private loginService: LoginService,
               private http: HttpClient,
               private validationService :ValidationService)
  { }

  login(): Observable<boolean> {
    return Observable.of(true).delay(1000).do(val => this.isLoggedIn = true);
  }

  /**Logout de la aplication*/
  logout(): void {
   this.isLoggedIn = false;
  }

  /** Cancel el token en el server*/
  KillToken(): Observable<Token[]> {
    const httpOptions = {
      headers: new HttpHeaders(
          {
            'Content-Type': 'application/json',
            'Authorization':'Bearer '+localStorage.getItem('token')
          }
        )
    };
      return this.http.get<Token[]>(this.tokenKillUrl,httpOptions)
         .pipe(
             tap(tokens => this.validationService.log(`Realiza el kill del token`)),
             catchError(this.validationService.handleError('KillToken', []))
         );
   }

}

import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { ValidationService } from '../validation/validation.service';
import { RESUMENCOTIZACION } from '../../mocks/mock-resumen-cotizacion';
import { ResumenCotizacion } from '../../class/resumen-cotizacion';
import { saveAs } from 'file-saver';

@Injectable()
export class DownloadFileService {

  constructor(private http: HttpClient) { }

}

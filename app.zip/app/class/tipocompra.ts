export class Tipocompra {
   id:string;
   descripcion: string;
   id_usuario_modifica :string;
   estado:string;
}

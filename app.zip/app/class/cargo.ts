export class Cargo {
    cod_cargo: string;
    desc_cargo: string;
    ot: string;
    cupos_aprobados: number;
    cupos_contratados: number;
    cod_empresa: number;
  }

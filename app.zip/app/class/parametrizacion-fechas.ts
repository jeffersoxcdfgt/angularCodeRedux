import { ListFicha  } from './listficha';

export class FechasType {
  id: string;
  fecha_inicio: string;
  fecha_fin: string;
  mensaje: string;
}

export class ParametrizacionFechas {
    id:string;
    ot: string;
    categoria: string;
    cargo: string;
    frecuencia: string;
    dias_habiles: string;
    dias_armado: string;
    dias_pedido: string;
    dias_recepcion: string;
    fecha_entrega: string;
    cancelacion: string;
    alerta_fecha: string;
    alerta_correo: string;
    mensaje: string;
    fechas:Array<FechasType>;
    fichas:Array<ListFicha>;
    cliente: any[];
}

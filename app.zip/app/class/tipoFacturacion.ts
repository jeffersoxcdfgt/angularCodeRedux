export class TipoFacturacion {
    meaning: string;
    value:string;
  }

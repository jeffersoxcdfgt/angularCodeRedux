import { DetalleFicha } from "./ficha-detalle";

export class FichaTecnica {
    id: number;
    id_cliente: string;
    id_unidad: string;
    ot: string;
    ano: number;
    img_cliente: string;
    estado: number;
    mensaje: string;
    observaciones: string;
    desc_cliente: string;
    desc_unidad: string;
    categorias: string;
    id_tipo_factura: string;
    tipo_factura: string;
    cargos: string;
    detalle: DetalleFicha[];//Paginate;
}

export class FiltroCategoria {
    category_id:string;
    grupo: string;
    description :string;
}

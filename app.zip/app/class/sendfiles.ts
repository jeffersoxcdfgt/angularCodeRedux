export class SendMailFiles {
  email: string;
  filename: File;
}

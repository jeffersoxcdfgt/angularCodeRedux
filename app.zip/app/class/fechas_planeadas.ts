export class FechasPlaneadas {
    id : string;
    id_detalle_ficha : string;
    armado : string;
    pedido : string;
    recepcion: string;
    entrega: string;
    cancelacion: string;
    alerta: string;
    estado: string;
    id_rangos_fechas: string;
    updated_at: string;
    id_empresa: string;
}

export class MenuSave {
  id: string;
  nombre: string;
  url: string;
  id_menu_padre: string;
  id_empresa: string;
  id_usuario_modifica: string;
  controles: any[];
  permisos: any[];
}


export class Saveperfil {
    id:string;
    nombre: string;
    id_empresa: string;
    id_usuario_modifica: string;
    menus:Array<MenuSave>;
    mensaje:string;
}

export class Portafoliogeneral {
  id_articulo: string;
  rn: string;
  grupo: string;
  descripcion_categoria : string;
  subgrupo:string;
  id_segmento_3: string;
  id_oracle: string;
  id_actividad_adam:string;
  des_art_oracle: string;
  precio_global: string;
  est_id_oracle: string;
  categoria_inv:string;
  tipo: string;
  sexo: string;
  talla: string;
  descripcion_corta: string;
  cuenta_costo_ext: string;
  cuenta_costo_efi: string;
  cuenta_costo_eym: string;
  cuenta_costo_eze:string;
  color: string;
  fecha_creacion: string;
  fecha_actualizacion: string;
  precio_venta:string;
  imagen:string;
  tiempo:string;
  porcentaje_iva:string;
}

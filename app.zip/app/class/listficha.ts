export class ListFicha{
  id:string;
  id_cliente:string;
  id_categoria:string;
  ot:string;
  id_cargo:string;
  id_frecuencia:string;
  armado_pedido:string;
  pedido_proveedor:string;
  recepcion_bodega:string;
  fecha_entrega:string;
  cancelacion:string;
  alerta_fecha:string;
  estado:string;
  mensaje:string;
  procesado:string;
}

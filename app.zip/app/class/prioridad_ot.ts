export class prioridad_ot {
  id:string;
  hoas:string;
}

export class CiudadesCargo{
    id: number;
    id_detalle_ficha: number;
    id_ciudad: number;
    linea_cargo: string;
    cupos_aprobados: number;
    cupos_contratados: number;
    cupos_disponibles: number;
    estado: string;
}
export class CtrCliente {
    id: string;
    nombre: string;
    nit:string;
    negocio:string;
  }
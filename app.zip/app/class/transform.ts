export class Transform {
  menus:any[];
}

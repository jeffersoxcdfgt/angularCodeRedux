export class ClienteOt {
    cedula_coordinador_nacional: string;
    cedula_coordinador_negocio: string;
    cliente_adam: string;
    cliente_desc: string;
    cliente_nit: string;
    cliente_ot: string;
    customer_id: string;
    empresa: string;
    empresa_adam: string;
    empresa_desc: string;
    empresa_nit: string;
    estado: string;
    fact_serv_th_solo_contratados: string;
    linea_servicio: string;
    linea_servicio_desc: string;
    negocio: string;
    negocio_payroll: string;
    nombre_coordinador_nacional: string;
    nombre_coordinador_negocio: string;
    ot: string;
    porcentaje_admon: string;
    regional_facturacion: string;
    regional_facturacion_desc:string;
    regional_negocio: string;
    regional_negocio_desc: string;
    registro_fiscal: string;
    tipo_facturacion: string;
  }

export class Token {
  id: string;
  nombre: string;
}

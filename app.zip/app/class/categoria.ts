export class Categoria {
    id:string;
    description: string;
    id_usuario_modifica :string;
    estado:string;
}

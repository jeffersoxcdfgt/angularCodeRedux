export class Tipousuario {
  id: string;
  nombre: string;
}

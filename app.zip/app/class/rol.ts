export class Rol {
  id: string;
  nombre: string;
}

export class Newpassword {
  password: string;
  conpassword: string;
  token:string;
  mensaje:string;
  mensajeError: string;
}

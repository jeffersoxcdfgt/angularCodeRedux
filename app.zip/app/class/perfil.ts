export class Perfil {
  id: string;
  nombre: string;
  mensaje:string;
}

export class Subcategoria {
    id:string;
    subgrupo_descripcion: string;
    id_usuario_modifica :string;
    estado:string;
}

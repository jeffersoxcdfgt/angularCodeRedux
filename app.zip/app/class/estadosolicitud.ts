export class EstadoSolicitud {
    id: string;
    descripcion: string;
    estado: string;
  }

export class ot_display {
  id:string;
  id_cliente: string;
  id_usuario: string;
  id_ot: string;
  estado:string;;
}

export class Usuario {
      id: string;
      nombre:string;
      apellido:string;
      cedula:string;
      telefono_movil:string;
      email:string;
      id_tipo_usuario:string;
      ot:any[];
      perfiles:any[];
      clientes:any[];
      usuario_dominio:string;
      mensaje:string;
      todas_ots:boolean;
}

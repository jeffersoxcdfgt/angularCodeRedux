export class Control {
    id: string;
    descripcion:string;
    nombre:string;
    id_menu: string;
    estado: string;
    id_empresa: string;
    id_usuario_crea: string;
    id_usuario_modifica: string;
}

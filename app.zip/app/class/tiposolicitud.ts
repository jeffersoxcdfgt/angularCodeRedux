export class TipoSolicitud {
    id: string;
    descripcion: string;
    estado: string;
  }

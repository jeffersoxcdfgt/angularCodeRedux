export class Controles {
  descripcion:string;
  estado:string;
  id:string;
  id_empresa:string;
  id_menu:string;
  id_usuario_crea:string;
  id_usuario_modifica:string;
}

export class Menus {
  controles:Controles[];
  id: string;
  id_empresa: string;
  id_menu_padre:string;
  id_usuario_modifica:string;
  nombre:string;
  url:string;
}

export class Permisos {
  id: string;
  nombre: string;
}

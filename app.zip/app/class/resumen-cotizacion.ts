export class CiudadesCargo{
  id:string;
  id_cotizacion:string;
  id_detalle_cotizacion:string;
  id_ciudad:string;
  id_cargo:string;
  cod_cargo:string;
  estado:string;
  id_tipo_factura:string;
  id_frecuencia:string;
}

export class DetalleResumenCotizacion {
  id:string;
  id_producto:string;
  cantidad:string;
  total:string;
  admon:string;
  id_facturable:string;
  id_frecuencia:string;
  descripcion_categoria:string;
  descripcion_corta:string;
  des_art_oracle:string;
  id_oracle:string;
  precio_venta:string;
  precio_global:string;
  subtotal_costo:string;
  subtotal_venta_cot:string;
  tiempo:string;
  aprobacion:string;
  cantidad_x_persona:string;
  categoria_inv:string;
  cuenta_costo_efi:string;
  cuenta_costo_ext:string;
  cuenta_costo_eym:string;
  cuenta_costo_eze:string;
  estado:string;
  id_segmento_3:string;
  sexo:string;
  subgrupo:string;
  talla:string;
  tipo:string;
  grupo:string;
  envio_aprobacion:string;
  ciudadesXCargo:Array<CiudadesCargo>;
}

export class ResumenCotizacion {
  id: string;
  nombre: string;
  id_usuario_crea: string;
  id_usuario_aprueba: string;
  estado: string;
  id_prioridad: string;
  subtotal_venta: string;
  usurio_crea_cotizacion: string;
  id_cliente: string;
  id_cliente_env: string;
  ot: string;
  ID_COTIZACION_COT: string;
  SUBTOTAL_VENTA_COT:string;
  TOTAL_COSTO:string;
  TOTAL_VENTA:string;
  BASE_GRAVABLE:string;
  BASE_EXCENTA:string;
  IVA:string;
  ciudadesxcargo:Array<any>;
  OT_FICHA:any[];
  id_ot:any[];
  destinatario_aprobador:any[];
  detalle:any[];
  productos:Array<DetalleResumenCotizacion>;
}

export class Menu {
  id:string;
  nombre: string;
  url: string;
  id_menu_padre: string;
}

export class Frecuencia {
  id: string;
  descripcion: string;
}

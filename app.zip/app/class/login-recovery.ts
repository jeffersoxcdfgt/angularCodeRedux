export class Loginrecovery {
  emailname: string;
  mensaje:string;
  mensajeError: string;
}

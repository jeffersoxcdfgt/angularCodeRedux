export class Filtroportafolio {
  id_tipocompra: string;
  id_categoria: string;
  id_subcategoria:string;
}

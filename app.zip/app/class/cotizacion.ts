export class Cotizacion {
id                   :string;
nombre               :string;
id_usuario_crea      :string;
id_usuario_aprueba   :string;
id_estado            :string;
id_empresa           :string;
id_usuario_modifica  :string;
id_cliente           :string;
id_ot                :string;
id_prioridad         :string;
subtotal_venta       :string;
base_excenta         :string;
base_gravable        :string;
iva                  :string;
total_venta          :string;
total_costo          :string;
created_at           :string;
updated_at           :string;
}

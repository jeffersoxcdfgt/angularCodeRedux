import { DetalleFichaTecnica } from "./detalleFichaTecnica";
import { Categoria } from "./categoria";

export class SearchFichaTecnica {
  "datos": {
    "id": number,
    "nombre": string,
    "id_usuario_crea": string,
    "id_usuario_aprueba": string,
    "id_estado": string,
    "id_cliente": string,
    "id_ot": string,
    "id_prioridad": string,
    "subtotal_venta": string,
    "base_excenta": string,
    "base_gravable": string,
    "iva": string,
    "total_venta": string,
    "total_costo": string,
    "detalle": DetalleFichaTecnica[]
  } ;
  "categorias": Categoria[]
}
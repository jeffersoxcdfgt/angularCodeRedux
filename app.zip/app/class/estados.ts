export class Estado {
  id: string;
  nombre: string;
}

export class Cliente {
  id: string;
  nombre: string;
  nit:string;
  direccion:string;
  estado:string;
  mensaje:string;
  jgzz_fiscal_code:string;
}

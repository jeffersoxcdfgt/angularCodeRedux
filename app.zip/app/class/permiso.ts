export class Permiso {
  id:string;
  nombre:string;
}

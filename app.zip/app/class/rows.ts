export class RowsHtml {
    htmlString:string;
}

export class AlertasMails {
    id:string;
    correos: string;
}

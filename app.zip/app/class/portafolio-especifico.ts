export class Portafolioespecifico {
   ID:string;
	 CATEGORIA:string;
	 ID_COTIZACION:string;
	 ID_ORACLE:string;
	 ID_ORACLE_PADRE:string;
	 PORTAFOLIO_GENERAL:string;
	 INDICADOR_KIT :string;
	 MARCA:string;
	 PORCENTAJE_ADMON:string;
	 CANTIDAD:string;
	 ID_FRECUENCIA:string;
	 FACTURABLE:string;
	 CANT_ENTR_X_PERS:string;
	 PERIODO_TIEMPO:string;
	 PEDIDOS_POR_ENTREGA:string;
	 TIEMPO_ENTREGA:string;
	 COSTO:string;
	 VENTA:string;
	 TOTA:string;
	 ESTADO:string;
	 OT:string;
	 ID_FICHA:string;
	 ID_DETALLE_FICHA:string;
	 FECHA_INICIAL:string;
	 FECHA_FINAL:string;
	 ID_FECHA_PARAMETRIZACION:string;
	 DESCRIPCION_ARTICULO:string;
	 ID_USUARIO_MODIFICA:string;
	 CREATED_AT:string;
	 UPDATED_AT:string;
	 ID_ARTICULO:string;
	 ESTADO_SINCRONICACION:string;
	 ERROR_SINCRONIZACION:string;
	 SEXO:string
	 TIPO:string;
	 TALLA:string
	 COLOR:string;
	 ID_DETALLE_COTIZACION:string;
}

export const enum MONTH {
  enero   = 1,
  febrero = 2,
  marzo   = 3,
  abril   = 4,
  mayo    = 5,
  junio   = 6,
  julio   = 7,
  agosto  = 8,
  septiembre  = 9,
  octubre     = 10,
  noviembre   = 11,
  diciembre   = 12
}

export class RenderFechas {
    ENTREGA:string;
}

export class RenderProductos {
    ID_ARTICULO:string;
    DESCRIPCION_ARTICULO:string;
    VENTA:string;
    COSTO:string;
    CONSUMO_X_PERSONA:string;
    PEDIDO_X_ENTREGA:string;
    ID_TIPO_FACTURACION:string;
    TIPO_FACTURACION:string;
    fechas_entrega:Array<RenderFechas>;
}

export class RenderPortaFolioEspecifico {
    ID_CARGO:string;
    ID_CATEGORIA:string;
    DESCRIPCION_CARGO:string;
    DESCRIPCION_CATEGORIA:string;
    articulos:Array<RenderProductos>;
}

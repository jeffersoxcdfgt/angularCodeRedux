import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-side-bar',
  templateUrl: './side-bar.component.html',
  styleUrls: ['../../assets/css/main.css',
              './side-bar.component.css']
})
export class SideBarComponent implements OnInit {
  public _opened: boolean = false;

  constructor() { }

  ngOnInit() {
  }

  public _toggleSidebar() {
    this._opened = !this._opened;
  }

}

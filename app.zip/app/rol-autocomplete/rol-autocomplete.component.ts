import { Component, OnInit ,ViewEncapsulation } from '@angular/core';
import { FormControl } from '@angular/forms';
import { RolAutocompleteService } from '../service/rol-autocomplete/rol-autocomplete.service';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/map';

@Component({
  selector: 'app-rol-autocomplete',
  templateUrl: './rol-autocomplete.component.html',
  styleUrls: ['../../assets/css/bootstrap.min.css',
              '../../assets/css/bootstrap-theme.min.css',
              '../../assets/css/main.css',
               './rol-autocomplete.component.css'],
  providers: [RolAutocompleteService],
})
export class RolAutocompleteComponent implements OnInit {
  searchTerm : FormControl = new FormControl();
  searchResult = [];

  constructor(private rolAutocompleteService: RolAutocompleteService ) { }

  ngOnInit() {
    this.getRolesAutoComplete();
  }

   /* GET Se invoca el servicio para consumir los roles*/
   getRolesAutoComplete(){
    this.searchTerm.valueChanges
        .debounceTime(400)
        .subscribe(data => {
            this.rolAutocompleteService.search_word(data).subscribe(response =>{
                this.searchResult = response
            })
        })
  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RolAutocompleteComponent } from './rol-autocomplete.component';

describe('RolAutocompleteComponent', () => {
  let component: RolAutocompleteComponent;
  let fixture: ComponentFixture<RolAutocompleteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RolAutocompleteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RolAutocompleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Menu } from '../class/menu';

export const MENUS: Menu[] = [
  {
    id: '',
    nombre: '',
    url: '',
    id_menu_padre: ''
   }
];

import { Subcategoria } from '../class/subcategoria';

export const SUBCATEGORIA: Subcategoria[] = [
  {
    id:'',
    subgrupo_descripcion: '',
    id_usuario_modifica :'',
    estado:'',
  }
];

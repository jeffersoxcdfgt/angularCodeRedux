import { Newpassword } from '../class/newpassword';

export const NEWPASSWORD: Newpassword[] = [
  { password: '', conpassword:'' ,token:'' , mensaje:'', mensajeError: ''}
];

import { TipoSolicitud } from '../class/tiposolicitud';

export const TIPOSOLICITUD: TipoSolicitud[] = [
  {
    id: '',
    descripcion: '',
    estado: ''
  }
];

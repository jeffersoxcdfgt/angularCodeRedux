import { Usuario  } from '../class/usuario';

export const USUARIO: Usuario[] = [
  {
    id: '',
    nombre:'',
    apellido:'',
    cedula:'',
    telefono_movil:'',
    email:'',
    id_tipo_usuario:'',
    ot:[],
    perfiles:[],
    clientes:[],
    usuario_dominio:'',
    mensaje:'',
    todas_ots:false
   }
];

import { Login } from '../class/login';

export const LOGIN: Login[] = [
  {
    usuario: '',
    password:'',
    mensaje:'',
    token:''
   }
];

import { Perfil } from '../class/perfil';

export const PERFIL: Perfil[] = [
  {
    id: '',
    nombre: '',
    mensaje:''
   }
];

import { Filtroportafolio } from '../class/filtro-portafolio';

export const FIRST:number =0;
export const FILTROPORTAFOLIO: Filtroportafolio[] = [
  {
    id_tipocompra: '',
    id_categoria: '',
    id_subcategoria:''
  }
];

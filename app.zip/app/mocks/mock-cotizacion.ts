import { Cotizacion } from '../class/cotizacion';

export const COTIZACION: Cotizacion[] = [
  {
    id                   :'',
    nombre               :'',
    id_usuario_crea      :'',
    id_usuario_aprueba   :'',
    id_estado            :'',
    id_empresa           :'',
    id_usuario_modifica  :'',
    id_cliente           :'',
    id_ot                :'',
    id_prioridad         :'',
    subtotal_venta       :'',
    base_excenta         :'',
    base_gravable        :'',
    iva                  :'',
    total_venta          :'',
    total_costo          :'',
    created_at           :'',
    updated_at           :''
  }
];

import { EstadoSolicitud } from '../class/estadosolicitud';

export const ESTADOSOLICITUD: EstadoSolicitud[] = [
  {
    id: '',
    descripcion: '',
    estado: ''
  }
];

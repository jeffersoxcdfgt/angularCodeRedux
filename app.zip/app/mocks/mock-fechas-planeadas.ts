import { FechasPlaneadas } from '../class/fechas_planeadas';

export const FECHASPLANEADAS: FechasPlaneadas[] = [
  {
    id : '',
    id_detalle_ficha : '',
    armado : '',
    pedido : '',
    recepcion: '',
    entrega: '',
    cancelacion: '',
    alerta: '',
    estado: '',
    id_rangos_fechas: '',
    updated_at: '',
    id_empresa: ''
  }
];

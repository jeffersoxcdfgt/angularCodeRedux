import { Frecuencia } from '../class/frecuencia';

export const FRECUENCIA: Frecuencia[] = [
  {
    id: '',
    descripcion: ''
  }
];

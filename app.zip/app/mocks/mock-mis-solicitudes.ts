import { MisSolicitudes } from '../class/mis-solicitudes';

export const MISSOLICITUDES: MisSolicitudes[] = [
  {
    ID_SOLICITUD:'',
    ID_CLIENTE:'',
    OT:'',
    ID_TIPO_SOLICITUD:'',
    ID_ESTADO_SOLICITUD:'',
    RETRASO:'',
    ID_USUARIO_SOLIC:'',
    ID_USUARIO_DES:'',
    FECHA_SOLICITUD:'',
    ID_PROCESO:'',
    CREATED_AT:'',
    UPDATED_AT:'',
    ID_USUARIO_CREA:'',
    ID_USURIO_MODIFICA:'',
    ID_EMPRESA:'',
    ID_PADRE:'',
    ID:'',
    DESCRIPCION_TIPO_SOLICITUD:'',
    DESCRIPCION_ESTADO_SOLICITUD:'',
    ID_COTIZACION :'',
    USUARIO_SOLICITAR:'',
    USUARIO_DESTINATARIO:'',
    USUARIO_CREADOR:''
   }
];

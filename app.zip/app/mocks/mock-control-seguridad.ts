import { ControlesSeguridad } from '../class/controles_seguridad';

export const CONTROLESEGURIDAD: ControlesSeguridad[] = [
  {
    id: '',
    descripcion: '',
    id_menu: '',
    estado: '',
    id_empresa: '',
    id_usuario_crea: '',
    id_usuario_modifica: ''
   }
];

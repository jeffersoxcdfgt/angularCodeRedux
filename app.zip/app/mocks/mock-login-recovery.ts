import { Loginrecovery } from '../class/login-recovery';

export const LOGINRECOVERY: Loginrecovery[] = [
  { emailname: '',mensaje:'', mensajeError: '' }
];

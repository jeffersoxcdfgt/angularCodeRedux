import { Portafoliogeneral } from '../class/portafolio-general';

export const PORTAFOLIOGENERAL: Portafoliogeneral[] = [
{
    id_articulo: '',
    rn: '',
    grupo: '',
    descripcion_categoria:'',
    subgrupo:'',
    id_segmento_3: '',
    id_oracle: '',
    id_actividad_adam:'',
    des_art_oracle: '',
    precio_global: '',
    est_id_oracle: '',
    categoria_inv:'',
    tipo: '',
    sexo: '',
    talla: '',
    descripcion_corta: '',
    cuenta_costo_ext: '',
    cuenta_costo_efi: '',
    cuenta_costo_eym: '',
    cuenta_costo_eze:'',
    color: '',
    fecha_creacion: '',
    fecha_actualizacion: '',
    precio_venta:'',
    imagen:'',
    tiempo:'',
    porcentaje_iva:''
}
];

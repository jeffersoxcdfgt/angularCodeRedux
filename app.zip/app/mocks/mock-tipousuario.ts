import { Tipousuario } from '../class/tipo-usuario';

export const TIPOUSUARIO: Tipousuario[] = [
  {
    id: '',
    nombre: ''
  }
];

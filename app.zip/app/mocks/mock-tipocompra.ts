import { Tipocompra } from '../class/tipocompra';

export const FIRST:number =0;
export const TIPOCOMPRA: Tipocompra[] = [
  {
    id:'',
    descripcion: '',
    id_usuario_modifica :'',
    estado:'',
  }
];

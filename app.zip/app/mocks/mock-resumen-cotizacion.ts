import { ResumenCotizacion , DetalleResumenCotizacion } from '../class/resumen-cotizacion';
import {Observable} from "rxjs/Observable";
import "rxjs/add/observable/interval";
import "rxjs/add/operator/take";
import "rxjs/add/operator/map";
import "rxjs/add/operator/bufferCount"

export const FIRST:number =0;
export const RESUMENCOTIZACION: ResumenCotizacion[] = [{

      id: '',
      nombre: '',
      id_usuario_crea: '',
      id_usuario_aprueba: '',
      estado: '',
      id_prioridad: '',
      subtotal_venta: '',
      usurio_crea_cotizacion: '',
      id_cliente: '',
      id_cliente_env: '',
      ot: '',
      ID_COTIZACION_COT: '',
      SUBTOTAL_VENTA_COT:'',
      TOTAL_COSTO:'',
      TOTAL_VENTA:'',
      BASE_GRAVABLE:'',
      BASE_EXCENTA:'',
      IVA:'',
      ciudadesxcargo: new Array<any>(),
      OT_FICHA:[],
      id_ot: [],
      destinatario_aprobador:[],
      detalle:[],
      productos:new Array<DetalleResumenCotizacion>()
}
];

import { FechasType , ParametrizacionFechas } from '../class/parametrizacion-fechas';
import { ListFicha } from '../class/listficha';
export const FIRSTPARAMETRIZACION:number =0;

export const PARAMETRIZACIONFECHAS: ParametrizacionFechas [] = [
{
    id:'',
    ot: '',
    categoria: '',
    cargo: '',
    frecuencia: '',
    dias_habiles: '',
    dias_armado: '',
    dias_pedido: '',
    dias_recepcion: '',
    fecha_entrega: '',
    cancelacion: '',
    alerta_fecha: '',
    alerta_correo: '',
    mensaje: '',
    fechas: new Array<FechasType>(),
    fichas: new Array<ListFicha>(),
    cliente: [],
  }
];

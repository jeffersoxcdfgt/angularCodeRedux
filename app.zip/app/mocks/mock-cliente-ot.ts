import { ClienteOt } from '../class/cliente-ot';

export const CLIENTEOT: ClienteOt[] = [
  {
    cedula_coordinador_nacional: '',
    cedula_coordinador_negocio: '',
    cliente_adam: '',
    cliente_desc: '',
    cliente_nit: '',
    cliente_ot: '',
    customer_id: '',
    empresa: '',
    empresa_adam: '',
    empresa_desc: '',
    empresa_nit: '',
    estado: '',
    fact_serv_th_solo_contratados: '',
    linea_servicio: '',
    linea_servicio_desc: '',
    negocio: '',
    negocio_payroll: '',
    nombre_coordinador_nacional: '',
    nombre_coordinador_negocio: '',
    ot: '',
    porcentaje_admon: '',
    regional_facturacion: '',
    regional_facturacion_desc:'',
    regional_negocio: '',
    regional_negocio_desc: '',
    registro_fiscal: '',
    tipo_facturacion: ''
  }
];

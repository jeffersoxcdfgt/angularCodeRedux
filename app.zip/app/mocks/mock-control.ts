import { Control } from '../class/control';

export const CONTROL: Control[] = [
  {
    id: '',
    descripcion:'',
    nombre:'',
    id_menu: '',
    estado: '',
    id_empresa: '',
    id_usuario_crea: '',
    id_usuario_modifica: ''
  }
];

import { Cliente } from '../class/cliente';

export const CLIENTE: Cliente[] = [
  {
    id: '',
    nombre: '',
    nit:'',
    direccion:'',
    estado:'',
    mensaje:'',
    jgzz_fiscal_code:''
  }
];

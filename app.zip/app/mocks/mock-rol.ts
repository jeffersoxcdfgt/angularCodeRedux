import { Rol } from '../class/rol';

export const ROLES: Rol[] = [
  {
    id: '',
    nombre: ''
   }
];

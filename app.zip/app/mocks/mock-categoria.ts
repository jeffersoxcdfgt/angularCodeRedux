import { Categoria } from '../class/categoria';

export const CATEGORIA: Categoria[] = [
  {
    id:'',
    description: '',
    id_usuario_modifica :'',
    estado:'',
  }
];

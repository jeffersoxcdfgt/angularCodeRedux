import { ListFicha } from '../class/listficha';

export const LISTFICHA: ListFicha[] = [
  {
    id:'',
    id_cliente:'',
    id_categoria:'',
    ot:'',
    id_cargo:'',
    id_frecuencia:'',
    armado_pedido:'',
    pedido_proveedor:'',
    recepcion_bodega:'',
    fecha_entrega:'',
    cancelacion:'',
    alerta_fecha:'',
    estado:'',
    mensaje:'',
    procesado:''
  }
];

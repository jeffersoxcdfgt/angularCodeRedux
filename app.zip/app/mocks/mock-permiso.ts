import { Permiso } from '../class/permiso';

export const PERMISOS: Permiso[] = [{
  id: '', nombre: ''
}
];

import { MenuSave , Saveperfil } from '../class/save_perfil';
export const FIRSTSAVE:number =0;

export const SAVEPERFIL: Saveperfil [] = [
{
    id:'',
    nombre:  '',
    id_empresa: '',
    id_usuario_modifica: '',
    menus:[],
    mensaje:''
  }
];

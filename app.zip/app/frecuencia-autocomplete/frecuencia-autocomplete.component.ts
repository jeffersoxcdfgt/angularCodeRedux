import { Component, OnInit ,ViewEncapsulation , Directive} from '@angular/core';
import { NgSelectModule } from '@ng-select/ng-select';
import { FormControl ,FormGroup, FormBuilder, Validators,FormsModule  } from '@angular/forms';
import { FrecuenciaAutocompleteService } from '../service/frecuencia-autocomplete/frecuencia-autocomplete.service';
import { Validation } from '../validation/validation';
import { ValidationService } from '../service/validation/validation.service';
import { Frecuencia } from '../class/frecuencia';
import { FRECUENCIA } from '../mocks/mock-frecuencia';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/map';

@Component({
  selector: 'app-frecuencia-autocomplete',
  templateUrl: './frecuencia-autocomplete.component.html',
  styleUrls: ['./frecuencia-autocomplete.component.css']
})
export class FrecuenciaAutocompleteComponent implements OnInit {

  frecuencias: Frecuencia[];
  selectedFrecuencias:Frecuencia[];

  constructor(private frecuenciaAutocompleteService: FrecuenciaAutocompleteService ,
              private validationService :ValidationService) { }

  ngOnInit() {
    this.getFrecuencias();
  }

  /*Metodo consumidor trae las frecuencias*/
  getFrecuencias(): void {
      this.frecuenciaAutocompleteService.getFrecuencias()
      .subscribe(frecuencias => {
         this.frecuencias = frecuencias;
       });
  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FrecuenciaAutocompleteComponent } from './frecuencia-autocomplete.component';

describe('FrecuenciaAutocompleteComponent', () => {
  let component: FrecuenciaAutocompleteComponent;
  let fixture: ComponentFixture<FrecuenciaAutocompleteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FrecuenciaAutocompleteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FrecuenciaAutocompleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

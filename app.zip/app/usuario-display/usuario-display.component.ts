import { Component, OnInit } from '@angular/core';
import { UsuarioDisplayService } from '../service/usuario-display/usuario-display.service';

@Component({
  selector: 'app-usuario-display',
  templateUrl: './usuario-display.component.html',
  styleUrls: [
    './usuario-display.component.css'],
  providers: [UsuarioDisplayService],
})
export class UsuarioDisplayComponent implements OnInit {

  public usuario;

  constructor(private usuarioDisplayService:UsuarioDisplayService) { }

  ngOnInit() {

      this.getUsuarioDisplay();

  }

   /* GET Se invoca el servicio para traer los datos del usuario logueado*/
   getUsuarioDisplay():void{
    this.usuarioDisplayService.getUsuarioDisplay()
        .subscribe(
            usuario => {
              this.usuario = usuario;
            });
  }

}

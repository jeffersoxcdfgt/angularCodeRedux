import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CtrOtComponent } from './ctr-ot.component';

describe('CtrOtComponent', () => {
  let component: CtrOtComponent;
  let fixture: ComponentFixture<CtrOtComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CtrOtComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CtrOtComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

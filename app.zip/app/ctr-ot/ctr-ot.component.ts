import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { OtAutocompleteService } from '../service/ot-autocomplete/ot-autocomplete.service';

@Component({
  selector: 'app-ctr-ot',
  templateUrl: './ctr-ot.component.html',
  styleUrls: ['./ctr-ot.component.css']
})
export class CtrOtComponent implements OnInit {

  ots: any[];
  selectedOts: any[];
  @Output() emitEvent:EventEmitter<any> = new EventEmitter<any>();
  @Output() emitEventRows:EventEmitter<any[]> = new EventEmitter<any[]>();

  constructor(private otAutocompleteService: OtAutocompleteService) { }

  ngOnInit() {
    this.getOtAutoComplete();
  }

  /*Metodo consumidor para traer clientes*/
  getOtAutoComplete(): void {
    this.otAutocompleteService.getOts()
        .subscribe(ots => {
          this.ots = ots;
          this.emitEventRows.emit(this.ots);
    });
  }

  getOt(): void{
    this.emitEvent.emit(this.selectedOts);
  }

  get ot():any[]{
    return this.ots;
  }

  set ot(ots:any[]){
    this.ots = ots;
  }

}

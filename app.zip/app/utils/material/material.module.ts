import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatAutocompleteModule, MatInputModule ,  MatSelectModule, MatDialogModule, MatButtonModule, MatButtonToggleModule, MatProgressSpinnerModule } from '@angular/material';


@NgModule({
  exports: [
    CommonModule,
    MatAutocompleteModule,
    MatSelectModule,
    MatInputModule,
    MatDialogModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatProgressSpinnerModule
  ],
  declarations: []
})
export class MaterialModule { }

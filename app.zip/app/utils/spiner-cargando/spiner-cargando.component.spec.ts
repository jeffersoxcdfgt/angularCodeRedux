import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SpinerCargandoComponent } from './spiner-cargando.component';

describe('SpinerCargandoComponent', () => {
  let component: SpinerCargandoComponent;
  let fixture: ComponentFixture<SpinerCargandoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SpinerCargandoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SpinerCargandoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

@Component({
  selector: 'app-spiner-cargando',
  templateUrl: './spiner-cargando.component.html',
  styleUrls: ['./spiner-cargando.component.css']
})
export class SpinerCargandoComponent implements OnInit {

  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<SpinerCargandoComponent>
  ) {

  }

  close(): void {
    this.dialogRef.close();
  }

  ngOnInit() {
  }

}

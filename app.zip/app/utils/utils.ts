import { Router,NavigationExtras, UrlTree , UrlSegment ,UrlSegmentGroup , PRIMARY_OUTLET  } from '@angular/router';

// utils.ts
function getPathToSend(x) {
    const tree: UrlTree =x ;
    const g: UrlSegmentGroup = tree.root.children[PRIMARY_OUTLET];
    const s: UrlSegment[] = g.segments;
    s[0].path;
    s[0].parameters;
    return "/"+s[0].path
}
export {getPathToSend};


function getOperations(x) {
    const tree: UrlTree =x ;
    let resul ="";
    const g: UrlSegmentGroup = tree.root.children[PRIMARY_OUTLET];
    const s: UrlSegment[] = g.segments;

    if(s.length == 1){
        resul ="add";
    }
    else if(s.length >=3){
        resul ="edit";
    }

    return resul;

}
export {getOperations};

import { Component, OnInit, Inject, EventEmitter, Output } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

@Component({
  selector: 'app-alerts',
  templateUrl: './alerts.component.html',
  styleUrls: ['./alerts.component.css']
})
export class AlertsComponent implements OnInit {

  titulo: string;
  mensaje: string;
  etiquetaConfirmacion: string;
  accion?: string;
  verCancelar?: boolean;

  @Output() confirmacionCallback = new EventEmitter();

  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
    public dialogRef: MatDialogRef<AlertsComponent>
  ) {
    this.titulo = data.titulo;
    this.mensaje = data.mensaje;
    this.etiquetaConfirmacion = data.etiquetaConfirmacion;
    this.accion = data.accion;
    this.verCancelar = data.verCancelar ? true : false;
  }

  ngOnInit() {
  }

  close(): void {
    this.dialogRef.close();
}

confirmacion() {
    this.confirmacionCallback.emit(this.data);
}


}

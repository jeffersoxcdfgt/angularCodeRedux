import { Component, OnInit , ViewEncapsulation } from '@angular/core';
import { FormControl } from '@angular/forms';
import { TipousuarioAutocompleteService } from '../service/tipousuario-autocomplete/tipousuario-autocomplete.service';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/map';

@Component({
  selector: 'app-tipousuario-autocomplete',
  templateUrl: './tipousuario-autocomplete.component.html',
  styleUrls: ['../../assets/css/bootstrap.min.css',
              '../../assets/css/bootstrap-theme.min.css',
              '../../assets/css/main.css',
              './tipousuario-autocomplete.component.css'],
   providers: [TipousuarioAutocompleteService],
})
export class TipousuarioAutocompleteComponent implements OnInit {

  searchTerm : FormControl = new FormControl();
  searchResult = [];

  constructor(private tipousuarioAutocompleteService: TipousuarioAutocompleteService) { }

  ngOnInit() {
    this.getTipoUsuariosAutoComplete();
  }

   /* GET Se invoca el servicio para consumir los tipos de usuarios*/
  getTipoUsuariosAutoComplete(){
    this.searchTerm.valueChanges
        .debounceTime(400)
        .subscribe(data => {
            this.tipousuarioAutocompleteService.search_word(data).subscribe(response =>{
                this.searchResult = response
            })
        })
  }

}

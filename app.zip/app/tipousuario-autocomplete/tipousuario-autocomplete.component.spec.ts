import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TipousuarioAutocompleteComponent } from './tipousuario-autocomplete.component';

describe('TipousuarioAutocompleteComponent', () => {
  let component: TipousuarioAutocompleteComponent;
  let fixture: ComponentFixture<TipousuarioAutocompleteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TipousuarioAutocompleteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TipousuarioAutocompleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

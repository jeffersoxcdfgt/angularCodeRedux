import { Component, OnInit } from '@angular/core';
import { MessageService } from '../service/message/message.service';

@Component({
  selector: 'app-messages',
  templateUrl: './messages.component.html',
  styleUrls: ['../../assets/css/bootstrap.min.css',
            '../../assets/css/bootstrap-theme.min.css',
           './messages.component.css']
})

export class MessagesComponent implements OnInit {

  constructor(public messageService: MessageService) {}

  ngOnInit() {
  }

}

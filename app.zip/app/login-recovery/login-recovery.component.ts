import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators ,FormControl} from '@angular/forms';
import { LOGINRECOVERY } from '../mocks/mock-login-recovery';
import { Loginrecovery } from '../class/login-recovery';
import { LoginRecoveryService } from '../service/login-recovery/login-recovery.service';
import { Validation } from '../validation/validation';
import { ValidationService } from '../service/validation/validation.service';
import * as $ from 'jquery';

@Component({
  selector: 'app-login-recovery',
  templateUrl: './login-recovery.component.html',
  styleUrls: ['../../assets/css/bootstrap.min.css',
              '../../assets/css/bootstrap-theme.min.css',
              '../../assets/css/main.css',
              '../../assets/css/style.css',
              './login-recovery.component.css']
})

export class LoginRecoveryComponent implements OnInit {
  loginrecoverys: Loginrecovery[];
  form: FormGroup;
  mensaje:string;
  mensajeError: string;

  constructor(private formBuilder: FormBuilder,
              private loginRecoveryService: LoginRecoveryService,
              private validationService :ValidationService) { }

  ngOnInit() {
    this.getLoginRecovery();
    this.form = this.formBuilder.group({
      email: [null, [Validators.required, Validators.email]]
    });
  }
  /*Metodo que retorna la estructura del obervable*/
  getLoginRecovery(): void {
    this.loginRecoveryService.getLoginRecovery()
        .subscribe(loginrecoverys => this.loginrecoverys = loginrecoverys);
  }

  /*Metod invocado  para la recuperacion del mail*/
  onClickRecovery(emailname: string): void {
    /*Validate funcitions*/
    if(!this.validationService.isNullOrEmpty(emailname)){
      return;
    }

    if(!this.validationService.validateEmail(emailname)){
      return;
    }
    /*Fin validate functions*/

    /*Subscribe el metodo para el consumo del servicio**/
    this.loginRecoveryService.addLoginRecovery({ emailname } as Loginrecovery)
      .subscribe(loginrecoverys => {
        this.mensaje = loginrecoverys.mensaje;
        this.mensajeError = loginrecoverys.mensajeError;
        this.loginrecoverys.push(loginrecoverys);
    })
  }

  /*Se inician metodos de validacion*/
  isFieldValid(field: string) {
  return !this.form.get(field).valid && this.form.get(field).touched;
  }

  /**Envia datos de usuarios*/
  displayFieldCss(field: string) {
  return {
    'has-error': this.isFieldValid(field),
    'has-feedback': this.isFieldValid(field)
   };
  }

  /*Envia datos*/
  onSubmit(email :string) {
    if (this.form.valid) {
      this.onClickRecovery(email);
    } else {
      this.validateAllFormFields(this.form);
    }
  }

  /*Valida campos de formulario*/
  validateAllFormFields(formGroup: FormGroup) {
  Object.keys(formGroup.controls).forEach(field => {
    console.log(field);
    const control = formGroup.get(field);
    if (control instanceof FormControl) {
      control.markAsTouched({ onlySelf: true });
    } else if (control instanceof FormGroup) {
      this.validateAllFormFields(control);
    }
  });
  }
  /*Limpia formulario*/
  reset() {
    this.form.reset();
  }

  ngAfterViewInit(){
    $(document).ready(function(){
          $("#navmainmenu").hide();
     });
  }

}

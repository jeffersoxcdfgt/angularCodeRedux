import { Component, OnInit, ViewChild, AfterViewInit , Pipe, PipeTransform} from '@angular/core';
import { NgSelectModule } from '@ng-select/ng-select';
import { FormGroup, FormBuilder, Validators ,FormControl , FormsModule } from '@angular/forms';
import { PrioridadAutocompleteService } from '../service/prioridad-autocomplete/prioridad-autocomplete.service';
import { Validation } from '../validation/validation';
import { ValidationService } from '../service/validation/validation.service';
import { ResumenCotizacion } from '../class/resumen-cotizacion';
import { RESUMENCOTIZACION , FIRST } from '../mocks/mock-resumen-cotizacion';
import { prioridad_ot } from '../class/prioridad_ot';

@Component({
  selector: 'app-prioridad-autocomplete',
  templateUrl: './prioridad-autocomplete.component.html',
  styleUrls: ['./prioridad-autocomplete.component.css']
})
export class PrioridadAutocompleteComponent implements OnInit {

  prioridades: any[];
  selectedPrioridades:prioridad_ot;

  constructor(private formBuilder: FormBuilder,
              private prioridadAutocompleteService: PrioridadAutocompleteService,
              private validationService :ValidationService) { }

  ngOnInit() {
    this.getPrioridades();
  }

  setPrioridad(){
    RESUMENCOTIZACION[FIRST].id_prioridad = this.selectedPrioridades.id;
  }

  /*Metodo consumidor para traer prioridades*/
  getPrioridades(): void {
    this.prioridadAutocompleteService.getPrioridades()
        .subscribe(prioridades => {
          this.prioridades = prioridades
        });
  }

}

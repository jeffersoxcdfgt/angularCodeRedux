import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrioridadAutocompleteComponent } from './prioridad-autocomplete.component';

describe('PrioridadAutocompleteComponent', () => {
  let component: PrioridadAutocompleteComponent;
  let fixture: ComponentFixture<PrioridadAutocompleteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PrioridadAutocompleteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrioridadAutocompleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

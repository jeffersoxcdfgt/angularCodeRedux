import { Component, OnInit , Input  } from '@angular/core';
import { FormGroup, FormBuilder, Validators ,FormControl} from '@angular/forms';
import { Router,NavigationExtras } from '@angular/router';
import { Location } from '@angular/common';
import { LOGIN } from '../mocks/mock-login';
import { Login } from '../class/login';
import { LoginService } from '../service/login/login.service';
import { AuthService }  from '../service/auth/auth.service';
import * as $ from 'jquery';
import { MenuEstadoService } from '../service/menu-estado/menu-estado.service';
import { RESUMENCOTIZACION , FIRST } from '../mocks/mock-resumen-cotizacion';
import { SpinerCargandoComponent } from '../utils/spiner-cargando/spiner-cargando.component';
import { MatDialog } from '@angular/material';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['../../assets/css/bootstrap.min.css',
              '../../assets/css/bootstrap-theme.min.css',
              '../../assets/css/main.css',
              './login.component.css']
})
export class LoginComponent implements OnInit {
  logins: Login[];
  form: FormGroup;
  message: string;
  mensaje:string;
  path = '';

  constructor(private formBuilder: FormBuilder,
              private router: Router,
              private loginService: LoginService,
              private authService: AuthService,
              private location: Location,
              private menuEstadoService: MenuEstadoService,
              public dialog: MatDialog
            ) {

  this.router.events.subscribe((val) => {
                  this.path = this.location.path();
  });
  this.setMessage();
  }

  setMessage() {
    this.message = 'Logged ' + (this.authService.isLoggedIn ? 'in' : 'out');
  }


  ngOnInit() {
     this.getLogins();
     this.form = this.formBuilder.group({
      usuario: [null, Validators.required],
      password: [null,Validators.required]
    });
  }

  getLogins(): void {
    this.loginService.getLogins()
        .subscribe(logins => this.logins = logins);
  }

  login(usuario: string , password :string , mensaje='') {
    const loading = this.lanzarLoading();
    this.message = 'Trying to log in ...';

      this.authService.login().subscribe(
        login => {
        this.setMessage();
      if (this.authService.isLoggedIn) {
        this.loginService.validateLogin({usuario,password,mensaje} as Login )
          .subscribe(login => {
               this.cleanData();
               if(login.mensaje.length ==0){
                 localStorage.setItem('token', login.token);
                 let redirect = this.authService.redirectUrl ? this.authService.redirectUrl : '/Home-inicio';
                 let navigationExtras: NavigationExtras = {
                   queryParamsHandling: 'preserve',
                   preserveFragment: true
                 };
                 loading.close();
                 this.router.navigate([redirect], navigationExtras);
               }
               else{
                loading.close();
                 this.authService.isLoggedIn =false;
                 this.mensaje =  login.mensaje;
                 console.log('Mensaje de error es '+this.mensaje );
               }

        });
      }
    });
  }

  //Clean data
  cleanData():void{
    RESUMENCOTIZACION[FIRST].id='';
    RESUMENCOTIZACION[FIRST].nombre='';
    RESUMENCOTIZACION[FIRST].id_usuario_crea='';
    RESUMENCOTIZACION[FIRST].id_usuario_aprueba='';
    RESUMENCOTIZACION[FIRST].estado='';
    RESUMENCOTIZACION[FIRST].id_cliente= '';
    RESUMENCOTIZACION[FIRST].id_ot=[];
    RESUMENCOTIZACION[FIRST].id_prioridad='';
    RESUMENCOTIZACION[FIRST].SUBTOTAL_VENTA_COT='';
    RESUMENCOTIZACION[FIRST].BASE_EXCENTA='';
    RESUMENCOTIZACION[FIRST].BASE_GRAVABLE='';
    RESUMENCOTIZACION[FIRST].IVA='';
    RESUMENCOTIZACION[FIRST].TOTAL_VENTA='';
    RESUMENCOTIZACION[FIRST].TOTAL_COSTO='';
    RESUMENCOTIZACION[FIRST].usurio_crea_cotizacion='';
    RESUMENCOTIZACION[FIRST].destinatario_aprobador=[];
    RESUMENCOTIZACION[FIRST].detalle=[];
  }

  public logout() {
    this.authService.logout();
    this.menuEstadoService.setMenuEstado(false);
    this.setMessage();
  }

  /*Se inician metodos de validacion*/
  isFieldValid(field: string) {
  return !this.form.get(field).valid && this.form.get(field).touched;
  }

  /**Envia datos de usuarios*/
  displayFieldCss(field: string) {
  return {
    'has-error': this.isFieldValid(field),
    'has-feedback': this.isFieldValid(field)
   };
  }

  /*Envia datos*/
  onSubmit() {
    console.log(this.form);
    if (this.form.valid) {
      console.log('form submitted');
    } else {
      this.validateAllFormFields(this.form);
    }
  }

  /*Valida campos de formulario*/
  validateAllFormFields(formGroup: FormGroup) {
  Object.keys(formGroup.controls).forEach(field => {
    console.log(field);
    const control = formGroup.get(field);
    if (control instanceof FormControl) {
      control.markAsTouched({ onlySelf: true });
    } else if (control instanceof FormGroup) {
      this.validateAllFormFields(control);
    }
  });
  }
  /*Limpia formulario*/
  reset() {
    this.form.reset();
  }

  ngAfterViewInit(){
    $(document).ready(function(){
          $("#navmainmenu").hide();
     });
  }

  lanzarLoading(){
    return this.dialog.open(SpinerCargandoComponent,{data: [], disableClose: true});
  }

}

import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';

@Component({
  selector: 'app-side-bar2',
  templateUrl: './side-bar2.component.html',
  styleUrls: ['../../assets/css/simple-sidebar.css',
              './side-bar2.component.css']
})
export class SideBar2Component implements OnInit {

  constructor() { }

  ngOnInit() {
      $("#menu-toggle").click(function(e) {
          e.preventDefault();
          $("#wrapper").toggleClass("toggled");
      });
  }

}

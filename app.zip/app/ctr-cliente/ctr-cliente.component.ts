import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { ClientesAutocompleteService } from '../service/clientes-autocomplete/clientes-autocomplete.service';

@Component({
  selector: 'app-ctr-cliente',
  templateUrl: './ctr-cliente.component.html',
  styleUrls: ['./ctr-cliente.component.css']
})
export class CtrClienteComponent implements OnInit {

  selectedClientes: any[];
  @Output() emitEvent:EventEmitter<any> = new EventEmitter<any>();
  @Output() emitEventRows:EventEmitter<any[]> = new EventEmitter<any[]>();
  clientes: any[];

  constructor(private clientesAutocompleteService: ClientesAutocompleteService) { }

  ngOnInit() {
    this.getClientesAutoComplete();
  }

  /*Metodo consumidor para traer clientes*/
  getClientesAutoComplete(): void {
    this.clientesAutocompleteService.getClientes()
        .subscribe(clientes => {
          this.clientes = clientes;
          this.emitEventRows.emit(this.clientes);
        });
  }

  getClienteSelected(): void{
    this.emitEvent.emit(this.selectedClientes);
  }

  get customers():any[]{
    return this.clientes;
  }

  set customers(clientes:any[]){
    this.clientes = clientes;
  }
}

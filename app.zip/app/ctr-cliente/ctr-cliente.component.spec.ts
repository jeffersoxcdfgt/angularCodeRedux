import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CtrClienteComponent } from './ctr-cliente.component';

describe('CtrClienteComponent', () => {
  let component: CtrClienteComponent;
  let fixture: ComponentFixture<CtrClienteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CtrClienteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CtrClienteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

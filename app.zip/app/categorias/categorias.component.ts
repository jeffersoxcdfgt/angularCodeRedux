import { Component, OnInit ,ViewEncapsulation, Input, Output, EventEmitter  } from '@angular/core';
import { NgSelectModule } from '@ng-select/ng-select';
import { FormControl ,FormGroup, FormBuilder, Validators,FormsModule  } from '@angular/forms';
import { CategoriasService } from '../service/categorias/categorias.service';
import { Validation } from '../validation/validation';
import { ValidationService } from '../service/validation/validation.service';
import { Tipocompra } from '../class/tipocompra';
import { TIPOCOMPRA  } from '../mocks/mock-tipocompra';
import { Categoria } from '../class/categoria';
import { CATEGORIA  } from '../mocks/mock-categoria';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/map';
import { DataCategoriasService } from '../service/data-categorias/data-categorias.service';
import { Filtroportafolio } from '../class/filtro-portafolio';
import { FILTROPORTAFOLIO , FIRST } from '../mocks/mock-filtro';

@Component({
  selector: 'app-categorias',
  templateUrl: './categorias.component.html',
  styleUrls: ['./categorias.component.css']
})
export class CategoriasComponent implements OnInit {

  categorias: Categoria[];
  selectedCategorias: any;
  @Output() emitEvent:EventEmitter<any> = new EventEmitter<any>();
  @Output() emitEventRows:EventEmitter<any[]> = new EventEmitter<any[]>();
  message:string;

  constructor(private formBuilder: FormBuilder,
              private categoriasService: CategoriasService ,
              private validationService :ValidationService,
              private data: DataCategoriasService) { }

  ngOnInit() {
    this.getCategorias();
  }

  /**Selcciones categorias*/
  getCategoriaSelected(): void{
    this.emitEvent.emit(this.selectedCategorias);
  }

  /**Selcciones categorias*/
  setCategorias(){
      if(this.selectedCategorias!=null){
         FILTROPORTAFOLIO[FIRST].id_categoria = this.selectedCategorias.grupo;
      }
      this.data.setCategoria(this.selectedCategorias);
      this.getCategoriaSelected();
  }

  /*Metodo consumidor trae las categorias*/
  getCategorias(): void {
     this.categoriasService.getCategorias()
     .subscribe(categorias => {
       this.categorias = categorias;
       this.emitEventRows.emit(this.categorias);
     });
  }

  get customers():any[]{
    return this.categorias;
  }

  set customers(categorias:any[]){
    this.categorias = categorias;
  }

}

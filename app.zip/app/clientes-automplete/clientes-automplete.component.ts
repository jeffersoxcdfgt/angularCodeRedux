import { Component, OnInit ,ViewEncapsulation } from '@angular/core';
import { NgSelectModule } from '@ng-select/ng-select';
import { FormControl ,FormGroup, FormBuilder, Validators,FormsModule  } from '@angular/forms';
import { ClientesAutocompleteService } from '../service/clientes-autocomplete/clientes-autocomplete.service';
import { Validation } from '../validation/validation';
import { ValidationService } from '../service/validation/validation.service';
import { ResumenCotizacion } from '../class/resumen-cotizacion';
import { RESUMENCOTIZACION , FIRST } from '../mocks/mock-resumen-cotizacion';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/map';
import { AutoCompleteModule } from 'ng5-auto-complete';
import { Cliente } from '../class/cliente';

@Component({
  selector: 'app-clientes-automplete',
  templateUrl: './clientes-automplete.component.html',
  styleUrls: ['./clientes-automplete.component.css'],
  providers: [ClientesAutocompleteService],
})
export class ClientesAutompleteComponent implements OnInit {
  searchTerm : FormControl = new FormControl();
  searchResult = [];
  clientes: any[];
  selectedClientes:Cliente;

  constructor(private formBuilder: FormBuilder,
              private clientesAutocompleteService: ClientesAutocompleteService ,
              private validationService :ValidationService) { }

  ngOnInit() {
    this.getClientesAutoComplete();
  }

  setCliente(){
      //RESUMENCOTIZACION[FIRST].id_cliente = this.selectedClientes.id;
  }

  /*Metodo consumidor para traer clientes*/
  getClientesAutoComplete(): void {
    this.clientesAutocompleteService.getClientes()
        .subscribe(clientes => {
          this.clientes = clientes
        });
  }

}

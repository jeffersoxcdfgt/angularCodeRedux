import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientesAutompleteComponent } from './clientes-automplete.component';

describe('ClientesAutompleteComponent', () => {
  let component: ClientesAutompleteComponent;
  let fixture: ComponentFixture<ClientesAutompleteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClientesAutompleteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientesAutompleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

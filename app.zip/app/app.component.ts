import { Component } from '@angular/core';
import { Title } from '@angular/platform-browser';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  /*styleUrls: ['./app.component.css']*/
  styleUrls: ["../assets/css/bootstrap.min.css",
              "../assets/css/bootstrap-theme.min.css",
              "./app.component.css"]

})
export class AppComponent {

  public booEstadoMenu : boolean = false;

   public constructor(private titleService: Title) {
      this.setTitle('Eficacia portal de compras');
  }

   public setTitle( newTitle: string) {
      this.titleService.setTitle( newTitle );
   }

   ngAfterViewInit(){
   }

}

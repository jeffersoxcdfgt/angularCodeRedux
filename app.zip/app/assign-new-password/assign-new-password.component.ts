import { Component, OnInit , Input  } from '@angular/core';
import { FormGroup,FormBuilder,Validators, FormControl ,AbstractControl} from '@angular/forms';
import {Location, LocationStrategy, PathLocationStrategy} from '@angular/common';
import { Router  ,UrlTree } from '@angular/router';
import { NEWPASSWORD } from '../mocks/mock-assign-new-password';
import { Newpassword } from '../class/newpassword';
import { AssignNewPasswordService } from '../service/assign-new-password/assign-new-password.service';
import { Validation } from '../validation/validation';
import { ValidationService } from '../service/validation/validation.service';
import * as $ from 'jquery';


@Component({
  selector: 'app-assign-new-password',
  providers: [Location, {provide: LocationStrategy, useClass: PathLocationStrategy}],
  templateUrl: './assign-new-password.component.html',
  styleUrls: ['../../assets/css/bootstrap.min.css',
            '../../assets/css/bootstrap-theme.min.css',
            './assign-new-password.component.css']
})

export class AssignNewPasswordComponent implements OnInit {
   @Input()  token :string;
   assignNewpasword: Newpassword[];
   form: FormGroup;
   mensaje:string;
   mensajeError: string;

  constructor(private formBuilder: FormBuilder,
      private assignNewService: AssignNewPasswordService,
      private validationService :ValidationService,
      private location: Location,
      private router: Router
  ) {
      /*Se obtiene el token desde la url*/
      this.token =router.parseUrl(location.path()).queryParams['token'];
      this.form = this.formBuilder.group({
          password: [null, Validators.required],
          conpassword: [null,Validators.required],
          token : [null]
      });
    }

    ngOnInit() {
        this.getAssignNewPassword();
    }

    /*Metodo usado para retornar el Mock de los datos de la estrusctura observable */
    getAssignNewPassword(): void {
        this.assignNewService.getNewPssword()
          .subscribe(assignNewpasword =>{
             this.assignNewpasword = assignNewpasword
           });
    }
    /*
    * Metodo que se ejecuta cuando se quiere cambiar el passwpord
    * @param password -password enviado
    * @param conpassword - confirmacion password
    * @param token generacion de token
    */
    onClickNewPassword(password: string , conpassword :string , token : string): void {
    password = password.trim();
    conpassword = conpassword.trim();
    token =this.token;

    /*Metodo para subscribir la lllamda al servicio*/
    this.assignNewService.addNewPassword({ password , conpassword,  token} as Newpassword)
      .subscribe(assignNewpasword => {
        this.mensaje = assignNewpasword.mensaje;
        this.mensajeError = assignNewpasword.mensajeError;
        this.assignNewpasword.push(assignNewpasword);
    });
    }

    /*Valida si los password son iguales*/
    isFieldsEqual(password: string ,conpassword: string ) {
      if(password != conpassword) return true;
      return false;
    }

    /*Se inician metodos de validacion*/
    isFieldValid(field: string) {
    return !this.form.get(field).valid && this.form.get(field).touched;
    }

    /**Envia datos de usuarios*/
    displayFieldCss(field: string) {
    return {
      'has-error': this.isFieldValid(field),
      'has-feedback': this.isFieldValid(field)
     };
    }

    /*Envia datos*/
    onSubmit(password:string ,conpassword:string ,token:string) {
      if (this.form.valid) {
        this.onClickNewPassword(password,conpassword,token);
      } else {
        this.validateAllFormFields(this.form);
      }
    }

    /*Valida campos de formulario*/
    validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      console.log(field);
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
    }
    /*Limpia formulario*/
    reset() {
      this.form.reset();
    }

    ngAfterViewInit(){
      $(document).ready(function(){
            $("#navmainmenu").hide();
       });
    }

}

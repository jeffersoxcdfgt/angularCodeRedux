import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignNewPasswordComponent } from './assign-new-password.component';

describe('AssignNewPasswordComponent', () => {
  let component: AssignNewPasswordComponent;
  let fixture: ComponentFixture<AssignNewPasswordComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssignNewPasswordComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignNewPasswordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

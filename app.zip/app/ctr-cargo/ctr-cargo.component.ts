import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Cargo } from '../class/cargo';
import { CargoService } from '../service/cargo/cargo.service';

@Component({
  selector: 'app-ctr-cargo',
  templateUrl: './ctr-cargo.component.html',
  styleUrls: ['./ctr-cargo.component.css']
})
export class CtrCargoComponent implements OnInit {
  cargo: Cargo[];
  selectCargo: any[];
  @Output() emitEvent:EventEmitter<any> = new EventEmitter<any>();
  @Output() emitEventRows:EventEmitter<any[]> = new EventEmitter<any[]>();
  constructor(private cargoService: CargoService) { }

  ngOnInit() {
    this.getCargos();
  }

  getCargos(){
    this.cargoService.getCargos()
      .subscribe(cargos => {
        this.cargo = cargos;
        this.emitEventRows.emit(this.cargo);
      });
  }

  getCargoSelected(): void{
    this.emitEvent.emit(this.selectCargo);
  }

  get cargos():any[]{
    return this.cargo;
  }

  set cargos(cargo:any[]){
    this.cargo = cargo;
  }

}

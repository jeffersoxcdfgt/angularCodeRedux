import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CtrCargoComponent } from './ctr-cargo.component';

describe('CtrCargoComponent', () => {
  let component: CtrCargoComponent;
  let fixture: ComponentFixture<CtrCargoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CtrCargoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CtrCargoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UsuarioAutocompleteComboboxComponent } from './usuario-autocomplete-combobox.component';

describe('UsuarioAutocompleteComboboxComponent', () => {
  let component: UsuarioAutocompleteComboboxComponent;
  let fixture: ComponentFixture<UsuarioAutocompleteComboboxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UsuarioAutocompleteComboboxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UsuarioAutocompleteComboboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

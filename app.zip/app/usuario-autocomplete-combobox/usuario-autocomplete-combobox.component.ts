import { Component, OnInit, Input } from '@angular/core';
import { FormControl } from '@angular/forms';
import { USUARIO } from '../mocks/mock-usuario';
import { Usuario } from '../class/usuario';
import { UsuarioService } from '../service/usuario/usuario.service';
import { Validation } from '../validation/validation';
import { ValidationService } from '../service/validation/validation.service';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/map';

@Component({
  selector: 'app-usuario-autocomplete-combobox',
  templateUrl: './usuario-autocomplete-combobox.component.html',
  styleUrls: ['../../assets/css/bootstrap.min.css',
              '../../assets/css/bootstrap-theme.min.css',
              '../../assets/css/main.css',
              './usuario-autocomplete-combobox.component.css'],
  providers: [UsuarioService]
})
export class UsuarioAutocompleteComboboxComponent implements OnInit {
  usuarios: Usuario[];
  userChoosen:string;

  constructor(private usuarioService: UsuarioService,
              private validationService :ValidationService) { }

    ngOnInit() {
      this.getUsuarios();
    }

    getUsuarios(): void {
      this.usuarioService.getUsuarios()
      .subscribe(usuarios => this.usuarios = usuarios);
    }

    select() :void{ }

    getUserChoosen() {
        return this.userChoosen;
    }

}

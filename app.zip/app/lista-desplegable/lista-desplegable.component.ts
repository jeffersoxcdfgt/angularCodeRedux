import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-lista-desplegable',
  templateUrl: './lista-desplegable.component.html',
  styleUrls: ['./lista-desplegable.component.css']
})
export class ListaDesplegableComponent implements OnInit {
  @Input() lista:any[];
  @Input() multiple: boolean = false;
  @Input() closeSelect: boolean = true;
  @Input() description: string;
  @Input() placeholder: string = "Seleccione un registro";
  @Input() disabled: boolean = false;
  @Input() loadingList: boolean = false;

  //@Input() selectedItem: any;
  selectedItem = [];

  @Output() emitEvent:EventEmitter<any> = new EventEmitter<any>();

  constructor() { }

  ngOnInit() {

  }

  changeItem(){
    this.emitEvent.emit(this.selectedItem);
  }

  get items():any[]{
    return this.lista;
  }

  set items(_lista:any[]){
    this.lista = _lista;
  }

}

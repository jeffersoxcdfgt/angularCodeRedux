import { Component, OnInit   } from '@angular/core';
import {
  createEntityAdapter,
  createSlice,
  configureStore
} from '@reduxjs/toolkit'

type Book = { bookId: string; title: string }

// Since we don't provide `selectId`, it defaults to assuming `entity.id` is the right field
const booksAdapter = createEntityAdapter<Book>({
  // Assume IDs are stored in a field other than `book.id`
  selectId: book => book.bookId,
  // Keep the "all IDs" array sorted based on book titles
  sortComparer: (a, b) => a.title.localeCompare(b.title)
})
const booksSlice = createSlice({
  name: 'books',
  initialState: booksAdapter.getInitialState({
    loading: 'idle'
  }),
  reducers: {
    // Can pass adapter functions directly as case reducers.  Because we're passing this
    // as a value, `createSlice` will auto-generate the `bookAdded` action type / creator
    bookAdded: booksAdapter.addOne,
    booksLoading(state, action) {
      if (state.loading === 'idle') {
        state.loading = 'pending'
      }
    },
    booksReceived(state, action) {
      if (state.loading === 'pending') {
        // Or, call them as "mutating" helpers in a case reducer
        booksAdapter.setAll(state, action.payload)
        state.loading = 'idle'
      }
    },
    bookUpdated: booksAdapter.updateOne
  }
})


const {
  bookAdded,
  booksLoading,
  booksReceived,
  bookUpdated
} = booksSlice.actions

const store = configureStore({
  reducer: {
    books: booksSlice.reducer
  }
})
type RootState = ReturnType<typeof store.getState>

// Can create a set of memoized selectors based on the location of this entity state
const booksSelectors = booksAdapter.getSelectors<RootState>(
  state => state.books
)


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
    title = 'my-app';

    constructor(){
      // Check the initial state:
      console.log(store.getState().books)
      // {ids: [], entities: {}, loading: 'idle' }


      store.dispatch(bookAdded({ bookId: 'a', title: 'First' }))
      console.log(store.getState().books)
      // {ids: ["a"], entities: {a: {id: "a", title: "First"}}, loading: 'idle' }

      store.dispatch(bookUpdated({ id: 'a', changes: { title: 'First (altered)' } }))
      store.dispatch(booksLoading(store.getState()))
      console.log(store.getState().books)
      // {ids: ["a"], entities: {a: {id: "a", title: "First (altered)"}}, loading: 'pending' }

      store.dispatch(
      booksReceived([
        { bookId: 'b', title: 'Book 3' },
        { bookId: 'c', title: 'Book 2' }
      ])
      )

      console.log(booksSelectors.selectIds(store.getState()))
      // "a" was removed due to the `setAll()` call
      // Since they're sorted by title, "Book 2" comes before "Book 3"
      // ["c", "b"]

      console.log(booksSelectors.selectAll(store.getState()))
      // All book entries in sorted order
      // [{id: "c", title: "Book 2"}, {id: "b", title: "Book 3"}]

    }


}

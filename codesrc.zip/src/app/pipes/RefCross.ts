/*import { Component, OnInit , Pipe, PipeTransform  } from '@angular/core';
import { listCollege , listCountry ,listTeam , listPosition } from '../players/shared/list';


@Pipe({name: 'textCountry'})
export class crossCountryValuePipe implements PipeTransform {
  transform(value: number): string {
    let res=listCountry.find(val => val.id == value)
    return res ?  res.value : ``;
  }
}

@Pipe({name: 'textCollege'})
export class crossCollegeValuePipe implements PipeTransform {
  transform(value: number): string {
    let res=listCollege.find(val => val.id == value)
    return res ?  res.value : ``;
  }
}

@Pipe({name: 'textPosition'})
export class crossPositionValuePipe implements PipeTransform {
  transform(value: number): string {
    let res=listPosition.find(val => val.id == value)
    return res ?  res.value : ``;
  }
}

@Pipe({name: 'textTeam'})
export class crossTeamValuePipe implements PipeTransform {
  transform(value: number): string {
    let res=listTeam.find(val => val.id == value)
    return res ?  res.value : ``;
  }
}*/

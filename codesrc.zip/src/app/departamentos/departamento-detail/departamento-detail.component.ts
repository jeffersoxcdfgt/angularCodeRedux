import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-departamento-detail',
  templateUrl: './departamento-detail.component.html',
  styleUrls: ['./departamento-detail.component.css']
})
export class DepartamentoDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

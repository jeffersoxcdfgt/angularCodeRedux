export class Departamento {
  depDepartamento: number;
  depDescripcion: string;
  paPais: number;
  ciudadMunicipios:string;
}

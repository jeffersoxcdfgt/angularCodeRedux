import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-departamento-edit',
  templateUrl: './departamento-edit.component.html',
  styleUrls: ['./departamento-edit.component.css']
})
export class DepartamentoEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

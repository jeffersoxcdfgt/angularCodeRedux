import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-departamento-create',
  templateUrl: './departamento-create.component.html',
  styleUrls: ['./departamento-create.component.css']
})
export class DepartamentoCreateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

export class DataList {
  id: number;
  value: string;
};
export const listZonas: DataList[] = [
{ id: 1, value: 'Bogota'},
{ id: 50 , value:'Barranquilla'}
];

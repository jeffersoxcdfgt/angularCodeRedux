import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sector-detail',
  templateUrl: './sector-detail.component.html',
  styleUrls: ['./sector-detail.component.css']
})
export class SectorDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

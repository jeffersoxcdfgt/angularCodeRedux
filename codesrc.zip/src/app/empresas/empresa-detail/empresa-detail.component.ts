import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-empresa-detail',
  templateUrl: './empresa-detail.component.html',
  styleUrls: ['./empresa-detail.component.css']
})
export class EmpresaDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

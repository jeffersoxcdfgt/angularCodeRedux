export class Empresa {
  emprId?:number;
  emprNit:string;
  emprNombre:string;
  emprDireccion:string;
  emprEmail:string;
  emprTelefono:string;
  emprFechaInicio:string;
  emprCiudad:string;
  departamento?:string;
  idEmprCiudad?:number;
  idDepartamento?:number;
  persona?: string;
  emprTelefax?:string;
  emprRegistradopor?:string;
  emprFechaCreacion?:string;
  emprEstado?:boolean;
  cimuId?:number;
}

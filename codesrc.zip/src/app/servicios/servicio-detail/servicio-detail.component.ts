import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-servicio-detail',
  templateUrl: './servicio-detail.component.html',
  styleUrls: ['./servicio-detail.component.css']
})
export class ServicioDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

export class Iva {
  ivaId?: number;
  ivaNombre:string;
  ivaDescripcion:string;
  ivaRegistradopor:string;
  ivaFechaCreacion:string;
  ivaValor:number;
  producto?:any[];
  ivaActivo:boolean;
}

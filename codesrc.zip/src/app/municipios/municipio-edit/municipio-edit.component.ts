import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-municipio-edit',
  templateUrl: './municipio-edit.component.html',
  styleUrls: ['./municipio-edit.component.css']
})
export class MunicipioEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

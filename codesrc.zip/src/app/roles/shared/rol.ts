export class Rol {
  rolId?:number;
  rolNombre?:string;
  rolDescripcion?:string;
  rolEstado?:boolean;
  rolRegistradopor?:string;
  rolFechaCreacion?: string;
  funcionalidadRol?:any[]
  personaRol?: any[]
}

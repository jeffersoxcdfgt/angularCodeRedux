export class Persona {
  persId?: string;
  esciId?:number;
  persNumDocumento?:string;
  persIscontribuyente?: boolean;
  persNombre?:string;
  persApellido?:string;
  persFechanacimiento?:string;
  persSexo?:string;
  sexId?:number;
  persDireccion?:string;
  persTelefono?:string;
  persCelular?:string;
  persEmail?: string;
  esciNombre?:string;
  tipeId?:number;
  tipoPersona?:string;
  tidoId?:number;
  tipodocumento?:string;
  empresa?:string;
  zona?:string;
  rol?:string;
  rolNombre?:string;
  persLogin?:string;
  persPassword?:string;
  persRegistradopor?: string;
  persFechaCreacion?: string;
  persActivo?: boolean;
  clclId?:number;
  personaRol?:[]
}

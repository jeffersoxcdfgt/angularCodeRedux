import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-persona-detail',
  templateUrl: './persona-detail.component.html',
  styleUrls: ['./persona-detail.component.css']
})
export class PersonaDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

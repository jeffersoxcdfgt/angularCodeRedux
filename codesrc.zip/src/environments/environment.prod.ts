export const environment = {
  production: true,
  urlzonas:"https://bfy0w85d4k.execute-api.us-east-1.amazonaws.com/Dev/api/Zonas",
  urlroles:"https://bfy0w85d4k.execute-api.us-east-1.amazonaws.com/Dev/api/Roles",
  urlivas:"https://bfy0w85d4k.execute-api.us-east-1.amazonaws.com/Dev/api/Ivas",
  urlsectores:"https://bfy0w85d4k.execute-api.us-east-1.amazonaws.com/Dev/api/Sectores",
  urlempresas:"https://bfy0w85d4k.execute-api.us-east-1.amazonaws.com/Dev/api/Empresas",
  urlpersonas:"https://bfy0w85d4k.execute-api.us-east-1.amazonaws.com/Dev/api/Personas",
  urlservicios:"https://bfy0w85d4k.execute-api.us-east-1.amazonaws.com/Dev/api/Servicios",
  urlContratos:"https://bfy0w85d4k.execute-api.us-east-1.amazonaws.com/Dev/api/Contratos",
  urlDepartamentos:"https://bfy0w85d4k.execute-api.us-east-1.amazonaws.com/Dev/api/Departamentos",
  urlMunicipios:"https://bfy0w85d4k.execute-api.us-east-1.amazonaws.com/Dev/api/CiudadMunicipios"
};

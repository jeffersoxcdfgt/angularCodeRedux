export class Servicio {
  serId?:number;
  serNombre:string;
  serDescripcion:string;
  serCodigo:number;
  serValor:number;
  emprId:number;
  serFechaCreacion?:string;
  serRegistradopor?:string;
  serActivo?:boolean;
}

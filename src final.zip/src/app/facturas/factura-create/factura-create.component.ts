import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-factura-create',
  templateUrl: './factura-create.component.html',
  styleUrls: ['./factura-create.component.css']
})
export class FacturaCreateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

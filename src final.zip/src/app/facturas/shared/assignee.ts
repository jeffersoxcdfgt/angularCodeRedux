export class Assignee {
  id: string;
  value: string;
};
export const listAssigne: Assignee[] = [
{ id: 'Jefferson Medina', value: 'Jefferson Medina' },
{ id: 'Manuela Cedeño', value: 'Manuela Cedeño' },
{ id: 'Diego Medina', value: 'Diego Medina' },
{ id: 'Johan Medina', value: 'Johan Medina' }
];

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-factura-edit',
  templateUrl: './factura-edit.component.html',
  styleUrls: ['./factura-edit.component.css']
})
export class FacturaEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-factura-delete',
  templateUrl: './factura-delete.component.html',
  styleUrls: ['./factura-delete.component.css']
})
export class FacturaDeleteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

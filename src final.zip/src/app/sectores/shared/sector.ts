export class Sector {
  sectId?: number;
  sectAbreviatura?:string;
  sectNombre?:string;
  sectDescripcion?:string;
  sectRecargo?:number;
  zonaId?:number;
  sectRegistradopor?: string;
  sectFechaCreacion?: string;
  sectActivo?: boolean;
}

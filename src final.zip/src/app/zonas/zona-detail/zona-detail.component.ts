import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-zona-detail',
  templateUrl: './zona-detail.component.html',
  styleUrls: ['./zona-detail.component.css']
})
export class ZonaDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

export class DataList {
  id: number;
  value: string;
};
export const listCollege: DataList[] = [
{ id: 1, value: 'San Luis'},
{ id: 2 , value:'Santa Librada'}
];

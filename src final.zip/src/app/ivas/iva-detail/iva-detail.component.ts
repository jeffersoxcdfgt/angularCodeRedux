import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-iva-detail',
  templateUrl: './iva-detail.component.html',
  styleUrls: ['./iva-detail.component.css']
})
export class IvaDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

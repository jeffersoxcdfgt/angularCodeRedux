export class Municipio {
  cimuId: number;
  cimuDescripcion:string;
  depDepartamento:number;
}

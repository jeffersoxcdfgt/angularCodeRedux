import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-municipio-create',
  templateUrl: './municipio-create.component.html',
  styleUrls: ['./municipio-create.component.css']
})
export class MunicipioCreateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

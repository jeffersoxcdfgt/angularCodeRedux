import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-municipio-detail',
  templateUrl: './municipio-detail.component.html',
  styleUrls: ['./municipio-detail.component.css']
})
export class MunicipioDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
